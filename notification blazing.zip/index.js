const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();
const messaging = admin.messaging();

// ── Helper: envoyer une notification à tous les tokens ──
async function sendToAll(title, body, data = {}) {
  try {
    const snap = await db.collection("fcm_tokens").get();
    const tokens = snap.docs.map(d => d.data().token).filter(Boolean);
    if (tokens.length === 0) return;

    const chunks = [];
    for (let i = 0; i < tokens.length; i += 500) {
      chunks.push(tokens.slice(i, i + 500));
    }

    for (const chunk of chunks) {
      await messaging.sendEachForMulticast({
        tokens: chunk,
        notification: { title, body },
        webpush: {
          notification: {
            title,
            body,
            icon: "https://blazing-dinasty-1fad9.web.app/icon-192.png",
            badge: "https://blazing-dinasty-1fad9.web.app/icon-192.png",
            vibrate: [200, 100, 200],
          },
          fcmOptions: {
            link: "https://blazing-dinasty-1fad9.web.app",
          },
        },
        data,
      });
    }
  } catch (err) {
    console.error("sendToAll error:", err);
  }
}

// ── 1. Rappel tâches du jour — chaque jour à 20h30 (heure Paris) ──
exports.rappelTachesJour = functions.pubsub
  .schedule("30 18 * * *") // 18h30 UTC = 20h30 Paris (été) / 19h30 (hiver)
  .timeZone("Europe/Paris")
  .onRun(async () => {
    await sendToAll(
      "🔥 Blazing Dynasty — Rappel du soir",
      "Tu as coché tes 5 actions du jour ? Il reste encore du temps ! 💪",
      { type: "taches_jour" }
    );
    return null;
  });

// ── 2. Nouvelle annonce Melissa ──
// Déclenché quand un post de type "annonce" est créé dans Firestore
exports.nouvelleAnnonce = functions.firestore
  .document("communaute/posts")
  .onWrite(async (change, context) => {
    const after = change.after.data();
    const before = change.before.data();
    if (!after) return null;

    // Trouver les nouvelles annonces
    const afterPosts = Object.values(after);
    const beforeIds = before ? Object.keys(before) : [];
    const newAnnonces = afterPosts.filter(
      p => p.type === "annonce" && !beforeIds.includes(p.id)
    );

    for (const annonce of newAnnonces) {
      await sendToAll(
        "📢 Nouvelle annonce de Melissa",
        annonce.text.substring(0, 100) + (annonce.text.length > 100 ? "..." : ""),
        { type: "annonce", postId: annonce.id }
      );
    }
    return null;
  });

// ── 3. Rappels clients (J+7 et J+21) — chaque jour à 8h00 ──
exports.rappelsClients = functions.pubsub
  .schedule("0 8 * * *")
  .timeZone("Europe/Paris")
  .onRun(async () => {
    const usersSnap = await db.collection("users").get();
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (const userDoc of usersSnap.docs) {
      const data = userDoc.data();
      if (!data["db-clients"]) continue;

      let clients;
      try { clients = JSON.parse(data["db-clients"]); } catch { continue; }

      const tokenDoc = await db.collection("fcm_tokens").doc(userDoc.id).get();
      if (!tokenDoc.exists) continue;
      const token = tokenDoc.data().token;

      for (const client of clients) {
        if (!client.commandes) continue;
        for (const cmd of client.commandes) {
          const cmdDate = new Date(cmd.date);
          const diff = Math.floor((today - cmdDate) / (1000 * 60 * 60 * 24));

          if (diff === 7 && !cmd.suivi7) {
            await messaging.send({
              token,
              notification: {
                title: "🛍️ Suivi client J+7",
                body: `${client.prenom} ${client.nom} — Prise de nouvelles après sa commande`,
              },
              webpush: { fcmOptions: { link: "https://blazing-dinasty-1fad9.web.app" } },
            });
          }
          if (diff === 21 && !cmd.suivi21) {
            await messaging.send({
              token,
              notification: {
                title: "🛍️ Suivi client J+21",
                body: `${client.prenom} ${client.nom} — Moment de proposer la prochaine commande`,
              },
              webpush: { fcmOptions: { link: "https://blazing-dinasty-1fad9.web.app" } },
            });
          }
        }

        // Rappels personnalisés
        if (client.rappels) {
          const todayStr = today.toISOString().slice(0, 10);
          for (const r of client.rappels) {
            if (r.date === todayStr && !r.fait) {
              await messaging.send({
                token,
                notification: {
                  title: "🔔 Rappel client",
                  body: `${client.prenom} ${client.nom} — ${r.texte}`,
                },
                webpush: { fcmOptions: { link: "https://blazing-dinasty-1fad9.web.app" } },
              });
            }
          }
        }
      }
    }
    return null;
  });

// ── 4. Début de nouvelle période Mihi ──
exports.debutPeriode = functions.pubsub
  .schedule("0 9 * * 3") // Chaque mercredi à 9h00
  .timeZone("Europe/Paris")
  .onRun(async () => {
    await sendToAll(
      "🎯 Nouvelle période Mihi !",
      "C'est parti pour 21 jours. Définis tes objectifs maintenant dans l'appli 🔥",
      { type: "nouvelle_periode" }
    );
    return null;
  });
