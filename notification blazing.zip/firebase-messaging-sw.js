// Service Worker Firebase Messaging — Blazing Dynasty
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyBhsxeZe7JvliHh3kBRgRKSKA2XSiAUg9k",
  authDomain: "blazing-dinasty-1fad9.firebaseapp.com",
  projectId: "blazing-dinasty-1fad9",
  storageBucket: "blazing-dinasty-1fad9.firebasestorage.app",
  messagingSenderId: "499869328828",
  appId: "1:499869328828:web:28900482512a07ca3a77b9",
});

const messaging = firebase.messaging();

// Afficher la notification quand l'appli est en arrière-plan
messaging.onBackgroundMessage((payload) => {
  const { title, body, icon } = payload.notification;
  self.registration.showNotification(title, {
    body,
    icon: icon || '/icon-192.png',
    badge: '/icon-192.png',
    vibrate: [200, 100, 200],
    data: payload.data,
  });
});

// Clic sur la notification → ouvrir l'appli
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.openWindow('https://blazing-dinasty-1fad9.web.app')
  );
});
