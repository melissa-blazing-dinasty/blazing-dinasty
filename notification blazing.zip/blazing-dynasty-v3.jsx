import { useState, useCallback, useEffect } from "react";
import { initializeApp } from "firebase/app";
import { getFirestore, doc, getDoc, setDoc } from "firebase/firestore";
import { getMessaging, getToken, onMessage } from "firebase/messaging";

// ── FIREBASE ──────────────────────────────────────────────────────────────────
const firebaseConfig = {
  apiKey: "AIzaSyBhsxeZe7JvliHh3kBRgRKSKA2XSiAUg9k",
  authDomain: "blazing-dinasty-1fad9.firebaseapp.com",
  projectId: "blazing-dinasty-1fad9",
  storageBucket: "blazing-dinasty-1fad9.firebasestorage.app",
  messagingSenderId: "499869328828",
  appId: "1:499869328828:web:28900482512a07ca3a77b9",
};
const fbApp = initializeApp(firebaseConfig);
const db = getFirestore(fbApp);

// ── FCM — Notifications push ──────────────────────────────────────────────────
let messaging = null;
try { messaging = getMessaging(fbApp); } catch {}

async function saveFCMToken(uid) {
  if (!messaging) return;
  try {
    const permission = await Notification.requestPermission();
    if (permission !== "granted") return;
    const token = await getToken(messaging, {
      vapidKey: "BFI7Uodh64p0EnejAc9xQ6y0hOS0w4CVA2QO-3mCxFmcm13orUtX7mYDwSRuaS8iDs8ovcClbKj2j2JzMi47sRE"
    });
    if (token) {
      await setDoc(doc(db, "fcm_tokens", uid), { token, uid, updatedAt: Date.now() });
    }
  } catch {}
}
const fbApp = initializeApp(firebaseConfig);
const db = getFirestore(fbApp);

// ── STORAGE (Firebase Firestore) ──────────────────────────────────────────────
async function sg(uid, k) {
  try {
    const ref = doc(db, "users", uid);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      const data = snap.data();
      return data[k] !== undefined ? data[k] : null;
    }
    return null;
  } catch { return null; }
}

async function ss(uid, k, v) {
  try {
    const ref = doc(db, "users", uid);
    await setDoc(ref, { [k]: v }, { merge: true });
  } catch {}
}

// Charge toutes les données d'un utilisateur en une seule requête
async function sgAll(uid) {
  try {
    const ref = doc(db, "users", uid);
    const snap = await getDoc(ref);
    return snap.exists() ? snap.data() : {};
  } catch { return {}; }
}

// ── PALETTE ───────────────────────────────────────────────────────────────────
const C={brun:"#3D1F0E",brun2:"#5C3020",rose:"#C49A8A",pale:"#E8D5CC",lilas:"#A89BB5",or:"#C4A882",creme:"#F7F2EE",blanc:"#FDFAF7",texte:"#2E1F17",gris:"#8A7A74",vert:"#7FAF8A"};

// ── HELPERS ───────────────────────────────────────────────────────────────────
function Btn({href,label,color=C.brun,icon="🔗"}){
  return <a href={href} target="_blank" rel="noopener noreferrer" style={{display:"flex",alignItems:"center",gap:".55rem",background:color,borderRadius:9,padding:".6rem .9rem",textDecoration:"none",marginBottom:".45rem"}}>
    <span style={{fontSize:".85rem",flexShrink:0}}>{icon}</span>
    <span style={{fontSize:".75rem",fontWeight:600,color:C.blanc,lineHeight:1.3}}>{label}</span>
    <span style={{marginLeft:"auto",color:C.pale,fontSize:".65rem",opacity:.7,flexShrink:0}}>→</span>
  </a>;
}
function YTBtn({href,label}){return <Btn href={href} label={label} color="#8B1A1A" icon="▶"/>;}
function DriveBtn({href,label}){return <Btn href={href} label={label} color={C.brun2} icon="📄"/>;}
function DocBtn({href,label}){return <Btn href={href} label={label} color="#1a4a8b" icon="📝"/>;}

function Card({title,sub,icon,color=C.rose,children,defaultOpen=false}){
  const[open,setOpen]=useState(defaultOpen);
  return <div style={{background:C.blanc,border:`1px solid ${open?color:C.pale}`,borderRadius:14,marginBottom:".75rem",overflow:"hidden",transition:"border-color .2s"}}>
    <div onClick={()=>setOpen(p=>!p)} style={{padding:".82rem 1rem",display:"flex",alignItems:"center",gap:".6rem",cursor:"pointer",userSelect:"none"}}>
      <div style={{width:32,height:32,borderRadius:"50%",background:color+"22",display:"flex",alignItems:"center",justifyContent:"center",fontSize:".9rem",flexShrink:0}}>{icon}</div>
      <div style={{flex:1,minWidth:0}}>
        <div style={{fontFamily:"Georgia,serif",fontSize:".92rem",fontWeight:600,color:C.brun,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{title}</div>
        {sub&&<div style={{fontSize:".62rem",color:C.gris,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{sub}</div>}
      </div>
      <div style={{color:C.rose,fontSize:".68rem",transform:open?"rotate(180deg)":"none",transition:"transform .2s",flexShrink:0}}>▼</div>
    </div>
    {open&&<div style={{borderTop:`1px solid ${C.pale}`,padding:".85rem 1rem 1rem"}}>{children}</div>}
  </div>;
}

function Info({children,color=C.rose}){
  return <div style={{background:color+"15",border:`1px solid ${color}40`,borderRadius:9,padding:".7rem .9rem",fontSize:".75rem",color:C.texte,lineHeight:1.65,marginBottom:".75rem"}}>{children}</div>;
}

function Tag({label,bg,col}){
  return <span style={{background:bg,color:col,fontSize:".52rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",padding:".13rem .42rem",borderRadius:20,flexShrink:0,display:"inline-block"}}>{label}</span>;
}

function SecTitle({title,em,desc}){
  return <>
    <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
      {title} <em style={{fontStyle:"italic",color:C.rose}}>{em}</em>
    </div>
    {desc&&<p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>{desc}</p>}
  </>;
}

function CopyBtn({text}){
  const[c,setC]=useState(false);
  return <button onClick={()=>{navigator.clipboard.writeText(text);setC(true);setTimeout(()=>setC(false),2000);}}
    style={{fontSize:".55rem",padding:".15rem .45rem",border:`1px solid ${c?C.vert:C.pale}`,borderRadius:5,background:"none",color:c?C.vert:C.gris,cursor:"pointer",fontFamily:"inherit",flexShrink:0}}>{c?"✓":"Copier"}</button>;
}

// ── POST IDEAS DATA ───────────────────────────────────────────────────────────
const POST_IDEAS = [
  {theme:"💄 Make-up & Beauté", color:C.rose, posts:[
    {id:"p1",hook:"On m'a encore demandé \"c'est quoi ton parfum ?\"",caption:"Plot twist → moins de 20€ et on me fait des compliments NON-STOP. Tu veux savoir lequel ? Écris PARFUM en commentaire 😏"},
    {id:"p2",hook:"Makeup du jour : rapide, naturel, pas besoin de 15 produits",caption:"J'utilise une mini routine makeup que je recommande souvent aux mamans pressées. Tu veux la liste des produits exacts ? Commente MAKEUP 💄"},
    {id:"p3",hook:"Toi aussi tu adores les rouges à lèvres pigmentés qui tiennent longtemps ?",caption:"Alors je pense que comme moi tu vas adorer ces petites pépites !! Tape PÉPITES je te réserve une belle surprise ❤️"},
    {id:"p4",hook:"⏰ 5 minutes. C'est le temps que je mets pour ma routine (vraiment).",caption:"Skincare + touche de makeup + parfum. Tu veux ma routine express et les produits exacts ? Écris 5MIN 💕"},
    {id:"p5",hook:"Makeup qui tient toute la journée même avec un masque ?",caption:"Oui ça existe 😂 Je vous montre ma technique en story ce soir. Restez connectées 👀"},
  ]},
  {theme:"🌿 Skincare & Soin", color:C.lilas, posts:[
    {id:"p6",hook:"💭 On parle souvent de skincare hors de prix… J'ai une routine visage SIMPLE à moins de 25€",caption:"Rien de compliqué. Rien de gadget. Juste ce qu'il faut pour une peau propre, nette et confortable. Tu veux la liste exacte ? Dis-le moi en commentaire 👇"},
    {id:"p7",hook:"On pense souvent que pour que ça marche… il faut que ce soit cher. Faux.",caption:"J'utilise des produits beaucoup plus accessibles et les résultats sont là. Tu veux voir ce que j'utilise vraiment ? Écris LISTE en commentaire."},
    {id:"p8",hook:"Prendre soin de soi ≠ se ruiner.",caption:"J'ai construit une routine complète soin + bien-être, accessible et rapide. Tu veux la liste détaillée ? Dis MOI 👇"},
    {id:"p9",hook:"Le problème ce n'est pas toi. C'est juste que ta peau n'a pas la bonne routine.",caption:"Même peau, même personne. La seule différence ? Une routine adaptée à 25€. Résultat : teint unifié, peau hydratée. Tu veux la routine ? Écris ROUTINE 👇"},
  ]},
  {theme:"💆 Bien-être & Énergie", color:C.or, posts:[
    {id:"p10",hook:"Non, je ne prends pas 12 compléments par jour.",caption:"J'ai une routine ultra simple pour l'énergie, le bien-être, me sentir mieux au quotidien. Tu veux savoir ce que je prends exactement ? Écris ROUTINE en commentaire."},
    {id:"p11",hook:"Tu te lèves fatiguée même après 8h de sommeil ?",caption:"J'étais pareille. Un truc m'a changé la vie et c'est pas du café 😂 Écris ÉNERGIE je t'explique tout 👇"},
    {id:"p12",hook:"Ventre gonflé, digestion difficile, fatigue chronique…",caption:"C'est pas une fatalité. J'ai trouvé une solution naturelle et ça m'a transformée. Qui veut en savoir plus ? 👋"},
  ]},
  {theme:"💰 Opportunité & Liberté", color:C.brun, posts:[
    {id:"p13",hook:"Je ne cherchais pas un 2ème emploi. Je cherchais quelque chose qui s'adapte à ma vie.",caption:"Aujourd'hui je travaille depuis mon canapé pendant que mes enfants dorment. Et je ne l'ai jamais regretté. Tu veux savoir comment ? Écris LIBERTÉ en commentaire 🖤"},
    {id:"p14",hook:"Mardi 15h. Je récupère mon enfant à l'école.",caption:"Pas de congés posés. Pas de permission demandée. Juste... ma vie. C'est ça que j'ai construit avec Blazing Dynasty 🖤"},
    {id:"p15",hook:"Belle journée qui commence ☀️ Appel équipe dans 1h.",caption:"J'adore ce que je fais parce que ça me ressemble. Tu es curieuse de savoir comment ? Réponds à ce message 🙂"},
    {id:"p16",hook:"La semaine a été productive 🖤",caption:"Je vous explique bientôt ce qu'il se passe dans les coulisses... Restez connectées 👀"},
    {id:"p17",hook:"On m'a demandé aujourd'hui combien je gagnais avec \"ça\".",caption:"J'ai répondu : assez pour ne plus avoir à demander de congés. Qui veut en savoir plus ? Écris ÉQUIPE en commentaire 🔥"},
  ]},
  {theme:"🌸 Storytelling & Vie perso", color:C.rose, posts:[
    {id:"p18",hook:"Il y a [X mois], j'ai pris une décision qui m'a fait peur.",caption:"Aujourd'hui je ne l'ai pas regrettée une seule fois. [Continue ton histoire authentiquement. Partage tes doutes, ta décision, où tu en es aujourd'hui.]"},
    {id:"p19",hook:"Ce que personne ne voit derrière mes posts.",caption:"Les galères, les doutes, les jours où j'avais envie d'arrêter. Je vous raconte tout parce que vous méritez la vérité, pas juste les moments parfaits."},
    {id:"p20",hook:"J'aurais aimé que quelqu'un me dise ça quand j'ai commencé.",caption:"[Partage un conseil clé que tu aurais aimé avoir. Ton expérience terrain est ton meilleur contenu.]"},
  ]},
  {theme:"🔑 Recrutement détourné", color:C.lilas, posts:[
    {id:"p21",hook:"Tu cherches un complément de revenu sans sacrifier ta famille ?",caption:"Je construis une équipe de femmes ambitieuses. Pas de stock, pas de porte-à-porte. Juste du sérieux et une vraie méthode. Écris ÉQUIPE si tu veux en savoir plus 🖤"},
    {id:"p22",hook:"3 choses que j'aurais voulu savoir avant de commencer.",caption:"1. C'est du vrai travail. 2. Ça vaut vraiment le coup. 3. Tu n'es pas seule. C'est ça Blazing Dynasty. Curiosité ? Réponds à ce message 🙂"},
    {id:"p23",hook:"Ce mois-ci j'ai gagné [montant] en travaillant depuis chez moi.",caption:"Sans boss. Sans horaires fixes. Sans sacrifier ma famille. Si tu veux comprendre comment — écris MOI en commentaire."},
  ]},
  {theme:"✨ Face Architect", color:"#9B7FA8", posts:[
    {id:"p24",hook:"Mes rides ont l'air de disparaître... et non c'est pas du filtre 😮",caption:"Le sérum que j'utilise fait vraiment la différence. C'est la gamme Face Architect de Mihi. Tu veux que je t'explique comment ça marche ? Commente VISAGE 👇"},
    {id:"p25",hook:"47 ans et on me donne 35. Mon secret en 3 produits.",caption:"Crème ExoLifting + sérum Spicule + soin contour des yeux. Moins de 80€ les 3. Tu veux les détails ? Écris ANTIAGE en commentaire ✨"},
  ]},
  {theme:"💇 Hair Architect", color:C.or, posts:[
    {id:"p26",hook:"Tes cheveux font la tête ? Secs, cassants ou carrément ternes ?",caption:"Et si je te disais qu'avec seulement 25€, tu peux leur redonner vie et brillance comme en sortant de chez le coiffeur ? Commente CHEVEUX en dessous ! 👇"},
    {id:"p27",hook:"J'ai arrêté de dépenser une fortune chez le coiffeur.",caption:"J'ai trouvé une routine capillaire qui coûte moins de 30€ et mes cheveux n'ont jamais été aussi beaux. Tu veux le nom des produits ? Écris CHEVEUX 💛"},
  ]},
];

// ── SPRINT DATA ───────────────────────────────────────────────────────────────
const SPRINT=[
  {day:1,title:"Préparer le terrain",goal:"Profil optimisé + liste des 20",focus:"rs",tasks:[
    {id:"s1a",label:"Optimiser ta bio (photo + description + lien)"},
    {id:"s1b",label:"Poster une story d'énergie — pas de pitch"},
    {id:"s1c",label:"Écrire et classer ta liste des 20 contacts"},
    {id:"s1d",label:"Liker 10 publications de ta cible",script:'"Cette semaine je me fixe un défi. Je vous tiens au courant 🔥"'},
  ]},
  {day:2,title:"Premiers contacts chauds",goal:"3 messages + 1 conversation",focus:"bao",tasks:[
    {id:"s2a",label:'3 messages WhatsApp personnels aux contacts "Chauds"',script:'"Coucou [Prénom], je pense à toi. Je développe quelque chose qui te correspondrait peut-être. 3 min à regarder ? 🙂"'},
    {id:"s2b",label:"Story vie quotidienne sans pitch"},
    {id:"s2c",label:"Répondre à toutes les réactions en DM"},
  ]},
  {day:3,title:"Contenu d'attraction",goal:"1 Reel publié + réponses mot-clé",focus:"rs",tasks:[
    {id:"s3a",label:"Créer et publier un Reel avec CTA mot-clé",script:'"Je ne cherchais pas un 2ᵉ emploi. Je cherchais quelque chose qui s\'adapte à ma vie. Écris ÉQUIPE en commentaire 🖤"'},
    {id:"s3b",label:"DM à chaque personne qui répond avec le mot-clé"},
    {id:"s3c",label:'Relancer 1–2 personnes sans réponse hier',script:'"Coucou ! Pas de souci si tu es occupée — je te laisse regarder quand t\'as 5 min 🙂"'},
  ]},
  {day:4,title:"Présenter l'opportunité",goal:"1 présentation + 5 contacts relancés",focus:"mix",tasks:[
    {id:"s4a",label:"Faire 1 présentation complète (15–30 min)",script:'"J\'ai commencé parce que j\'avais besoin de quelque chose qui s\'adapte à ma vie. Ce n\'est pas un schéma miracle — c\'est du travail qui a du sens."'},
    {id:"s4b",label:"3 nouveaux messages aux contacts Tièdes"},
    {id:"s4c",label:'Story "résultat flou" — sans tout dévoiler'},
  ]},
  {day:5,title:"Amplifier la portée",goal:"2 recommandations + 1 témoignage",focus:"mix",tasks:[
    {id:"s5a",label:"Demander à 2–3 amies de partager ta publication"},
    {id:"s5b",label:'À celles qui ont décliné : "Tu connais quelqu\'un ?"',script:'"Pas de souci ! Est-ce que tu aurais quelqu\'un dans ton entourage qui cherche un revenu complémentaire ? 🙂"'},
    {id:"s5c",label:"Post témoignage produit authentique"},
  ]},
  {day:6,title:"Café ou Zoom découverte",goal:"Événement réalisé + suivi envoyé",focus:"bao",tasks:[
    {id:"s6a",label:"Organiser un café ou Zoom 30–45 min avec 3–5 personnes"},
    {id:"s6b",label:"Présenter ton histoire + les 3 façons d'entrer"},
    {id:"s6c",label:"Suivi individuel à chaque participante dans les 2h",script:'"Merci d\'avoir pris le temps ce soir 🧡 Je suis là si tu as des questions. Pas de pression."'},
  ]},
  {day:7,title:"Bilan & relances",goal:"Bilan chiffré + plan semaine 2",focus:"mix",tasks:[
    {id:"s7a",label:"Compter : contacts · réponses · présentations · recrues"},
    {id:"s7b",label:'Relancer les personnes "en réflexion"',script:'"Coucou ! Je voulais prendre des nouvelles 🙂 Pas de pression — je suis là si tu veux avancer."'},
    {id:"s7c",label:"Story de bilan + planifier la semaine 2"},
  ]},
];

// ── MAIN APP ──────────────────────────────────────────────────────────────────
export default function App(){
  const[screen,setScreen]=useState("login");
  const[loginStep,setLoginStep]=useState(1); // 1=identité, 2=chef équipe
  const[userId,setUserId]=useState("");
  const[name,setName]=useState("");
  const[nameInput,setNameInput]=useState("");
  const[prenomInput,setPrenomInput]=useState("");
  const[nomInput,setNomInput]=useState("");
  const[codeInput,setCodeInput]=useState("");
  const[loginError,setLoginError]=useState("");
  const[loginLoading,setLoginLoading]=useState(false);
  const[chefs,setChefs]=useState([]);
  const[chefChoisi,setChefChoisi]=useState("");
  const[pendingUid,setPendingUid]=useState("");
  const[pendingName,setPendingName]=useState("");
  const[pendingIsMelissa,setPendingIsMelissa]=useState(false);

  const SECRET_CODE="BD-2026-FIRE";

  // ── AUTO-LOGIN depuis localStorage ──
  useEffect(()=>{
    try{
      const saved=localStorage.getItem("bd-user");
      if(saved){
        const{uid,n,codeOk}=JSON.parse(saved);
        if(uid&&n&&codeOk===true){
          setUserId(uid);setName(n);
          setScreen("app");load(uid);
        } else {
          // Session invalide - effacer et forcer reconnexion
          localStorage.removeItem("bd-user");
        }
      }
    }catch{}
  },[]);

  const login=async()=>{
    if(!prenomInput.trim()||!nomInput.trim()||!codeInput.trim())return;
    if(codeInput.trim().toUpperCase()!==SECRET_CODE){
      setLoginError("❌ Code d'accès incorrect.");return;
    }
    setLoginLoading(true);setLoginError("");
    try{
      const ref=doc(db,"acces","membres");
      const snap=await getDoc(ref);
      const fullName=`${prenomInput.trim().toLowerCase()} ${nomInput.trim().toLowerCase()}`;
      const isMelissa=prenomInput.trim().toLowerCase()==="melissa";
      // Auto-ajouter Melissa comme chef d'équipe
      if(isMelissa){
        try{
          const accRef=doc(db,"acces","membres");
          const accSnap=await getDoc(accRef);
          const existing=accSnap.exists()?accSnap.data():{};
          const chefs=existing.chefs||[];
          const melissaId="melissa da silveira";
          if(!chefs.includes(melissaId)){
            await setDoc(accRef,{...existing,chefs:[...chefs,melissaId]},{merge:true});
          }
        }catch{}
      }
      if(!isMelissa){
        if(!snap.exists()){
          setLoginError("❌ Accès non autorisé. Contacte Melissa.");
          setLoginLoading(false);return;
        }
        const membres=snap.data().liste||[];
        const autorise=membres.some(m=>m.toLowerCase()===fullName);
        if(!autorise){
          setLoginError("❌ Prénom/Nom non reconnu. Contacte Melissa.");
          setLoginLoading(false);return;
        }
      }
      const uid=fullName.replace(/\s+/g,"-");
      const displayName=`${prenomInput.trim()} ${nomInput.trim()}`;

      // Vérifier si déjà un chef assigné
      const userSnap=await getDoc(doc(db,"users",uid));
      const alreadyHasChef=userSnap.exists()&&userSnap.data()["chef-equipe"];

      if(!isMelissa&&!alreadyHasChef){
        // Charger la liste des chefs
        const chefsSnap=await getDoc(doc(db,"acces","membres"));
        const liste=chefsSnap.exists()?chefsSnap.data().chefs||[]:[];
        setPendingUid(uid);setPendingName(displayName);setPendingIsMelissa(false);
        setChefs(liste);
        setLoginLoading(false);
        if(liste.length>0){setLoginStep(2);return;}
      }

      // Connexion directe
      try{localStorage.setItem("bd-user",JSON.stringify({uid,n:displayName,codeOk:true}));}catch{}
      setUserId(uid);setName(displayName);setScreen("app");load(uid);
      // Enregistrer token FCM pour les notifications
      saveFCMToken(uid);
    }catch{
      setLoginError("❌ Erreur de connexion. Réessaie.");
    }
    setLoginLoading(false);
  };

  const confirmerChef=async()=>{
    setLoginLoading(true);
    try{
      if(chefChoisi){
        const ref=doc(db,"users",pendingUid);
        await setDoc(ref,{"chef-equipe":chefChoisi},{ merge:true });
        // Ajouter dans l'équipe du chef
        const chefUid=chefChoisi.toLowerCase().replace(/\s+/g,"-");
        const chefRef=doc(db,"users",chefUid);
        const chefSnap=await getDoc(chefRef);
        const equipe=chefSnap.exists()&&chefSnap.data()["mon-equipe"]?JSON.parse(chefSnap.data()["mon-equipe"]):[];
        if(!equipe.includes(pendingUid)){
          await setDoc(chefRef,{"mon-equipe":JSON.stringify([...equipe,pendingUid])},{merge:true});
        }
      }
      try{localStorage.setItem("bd-user",JSON.stringify({uid:pendingUid,n:pendingName,codeOk:true}));}catch{}
      setUserId(pendingUid);setName(pendingName);setScreen("app");load(pendingUid);
    }catch{}
    setLoginLoading(false);
  };
  const[tab,setTab]=useState("home");
  const[showObjectifs,setShowObjectifs]=useState(false);
  const[checks,setChecks]=useState({});
  const[tasks,setTasks]=useState({});
  const[posts,setPosts]=useState({});
  const[kpis,setKpis]=useState({k1:"",k2:"",k3:"",k4:""});
  const[notes,setNotes]=useState("");
  const[loading,setLoading]=useState(false);
  const[openDays,setOpenDays]=useState({1:true});

  const load=useCallback(async(uid)=>{
    setLoading(true);
    try{
      const data = await sgAll(uid);
      if(data.checks) setChecks(JSON.parse(data.checks));
      if(data.tasks)  setTasks(JSON.parse(data.tasks));
      if(data.posts)  setPosts(JSON.parse(data.posts));
      if(data.kpis)   setKpis(JSON.parse(data.kpis));
      if(data.notes)  setNotes(data.notes);
    }catch{}
    setLoading(false);
  },[]);

  const save=useCallback(async(uid,c,t,_s,p,k,n)=>{
    if(!uid)return;
    try{await Promise.all([
      ss(uid,"checks",JSON.stringify(c)),ss(uid,"tasks",JSON.stringify(t)),
      ss(uid,"posts",JSON.stringify(p)),
      ss(uid,"kpis",JSON.stringify(k)),ss(uid,"notes",n),
    ]);}catch{}
  },[]);

  const tog=(type,id)=>{
    const setters={checks:[checks,setChecks],tasks:[tasks,setTasks],posts:[posts,setPosts]};
    const[state,setter]=setters[type];
    if(!state)return;
    const next={...state,[id]:!state[id]};
    setter(next);
    if(type==="tasks")save(userId,checks,next,{},posts,kpis,notes);
    else if(type==="posts")save(userId,checks,tasks,{},next,kpis,notes);
    else save(userId,next,tasks,{},posts,kpis,notes);
  };
  const updKpi=(k,v)=>{const next={...kpis,[k]:v};setKpis(next);save(userId,checks,tasks,null,posts,next,notes);};
  const updNotes=(v)=>{setNotes(v);save(userId,checks,tasks,null,posts,kpis,v);};

  const allTask=SPRINT.flatMap(d=>d.tasks.map(t=>t.id));
  const allPosts=POST_IDEAS.flatMap(th=>th.posts.map(p=>p.id));
  const donePosts=allPosts.filter(id=>posts[id]).length;

  // ── Période et bannières ──
  const periodeInfoInit=getPeriodeInfo();
  const isDebutPeriodeInit=periodeInfoInit.pctElapsed<=10;
  const bannerKeyInit=`bd-banner-${periodeInfoInit.periodEnd.toISOString().slice(0,10)}`;
  const[showBanner,setShowBanner]=useState(()=>{try{return isDebutPeriodeInit&&!localStorage.getItem(bannerKeyInit);}catch{return false;}});
  const[dismissedPeriode,setDismissedPeriode]=useState(false);

  // ── Admin items ──
  const[adminItems,setAdminItems]=useState([]);
  useEffect(()=>{
    if(screen!=="app")return;
    (async()=>{
      try{
        const snap=await getDoc(doc(db,"admin","contenus"));
        if(snap.exists())setAdminItems((snap.data().items||[]).filter(i=>i.actif));
      }catch{}
    })();
  },[screen]);

  // ── Protection clavier ──
  useEffect(()=>{
    const block=(e)=>{
      if(e.key==="F12"||(e.ctrlKey&&["u","s","a","p"].includes(e.key.toLowerCase()))){
        e.preventDefault();e.stopPropagation();
      }
    };
    document.addEventListener("keydown",block);
    return()=>document.removeEventListener("keydown",block);
  },[]);

  const TABS=[
    {id:"home",label:"🏠"},
    {id:"dashboard",label:"📊 Tableau de bord"},
    {id:"calendrier",label:"📅 Calendrier"},
    {id:"communaute",label:"🌟 Communauté"},
    {id:"blazing",label:"🔥 BD"},
    {id:"mihi",label:"🏢 Mihi"},
    {id:"demarrage",label:"📚 Démarrage"},
    {id:"vente",label:"🎯 Vente"},
    {id:"recrutement",label:"👥 Recrut."},
    {id:"contenu",label:"📱 Contenu"},
    {id:"outils",label:"🛠️ Outils"},
    {id:"devperso",label:"🧠 Dév. Personnel"},
    {id:"formaproduits",label:"🧴 Formation Produits"},
    {id:"suivi",label:"📋 Suivi Recrues"},
    {id:"scripts",label:"📝 Scripts"},
  ];

  // ── LOGIN ────────────────────────────────────────────────────────────────────
  if(screen==="login")return(
    <div style={{minHeight:"100vh",background:C.brun,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"2rem 1.2rem",fontFamily:"'DM Sans',system-ui,sans-serif"}}>
      <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".25em",color:C.or,marginBottom:".5rem"}}>✦ BLAZING DYNASTY ✦</div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"clamp(1.8rem,5vw,2.6rem)",fontWeight:300,color:C.blanc,textAlign:"center",lineHeight:1.1}}>Espace Formation</div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"clamp(1.8rem,5vw,2.6rem)",fontStyle:"italic",color:C.pale,textAlign:"center",lineHeight:1.1,marginBottom:".3rem"}}>Privé</div>
      <div style={{width:48,height:1,background:C.or,margin:".85rem auto"}}/>
      <p style={{fontSize:".76rem",color:"rgba(232,213,204,.7)",textAlign:"center",marginBottom:"2rem",maxWidth:300}}>Formations · Stratégies · Outils · Suivi</p>

      <div style={{background:C.blanc,borderRadius:16,padding:"1.5rem 1.4rem",width:"100%",maxWidth:360,boxShadow:"0 8px 32px rgba(0,0,0,.25)"}}>

        {/* ÉTAPE 1 — Identité */}
        {loginStep===1&&<>
          <div style={{fontSize:".68rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".75rem",textAlign:"center"}}>🔐 Accès membres</div>
          <div style={{display:"flex",gap:".5rem",marginBottom:".45rem"}}>
            <input type="text" placeholder="Prénom" value={prenomInput} onChange={e=>{setPrenomInput(e.target.value);setLoginError("");}}
              style={{flex:1,border:`1px solid ${C.pale}`,borderRadius:10,padding:".6rem .9rem",fontSize:".85rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}} autoFocus/>
            <input type="text" placeholder="Nom" value={nomInput} onChange={e=>{setNomInput(e.target.value);setLoginError("");}}
              style={{flex:1,border:`1px solid ${C.pale}`,borderRadius:10,padding:".6rem .9rem",fontSize:".85rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}}/>
          </div>
          <input type="password" placeholder="Code d'accès" value={codeInput} onChange={e=>{setCodeInput(e.target.value);setLoginError("");}} onKeyDown={e=>e.key==="Enter"&&login()}
            style={{width:"100%",border:`1px solid ${loginError?C.rose:C.pale}`,borderRadius:10,padding:".6rem .9rem",fontSize:".85rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".5rem"}}/>
          {loginError&&<div style={{fontSize:".72rem",color:"#B04040",marginBottom:".5rem",textAlign:"center"}}>{loginError}</div>}
          <button onClick={login} disabled={!prenomInput.trim()||!nomInput.trim()||!codeInput.trim()||loginLoading}
            style={{width:"100%",background:(prenomInput.trim()&&nomInput.trim()&&codeInput.trim())?C.brun:C.pale,color:(prenomInput.trim()&&nomInput.trim()&&codeInput.trim())?C.blanc:C.gris,border:"none",borderRadius:10,padding:".7rem",fontSize:".85rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer",transition:"all .2s"}}>
            {loginLoading?"Vérification...":"Continuer →"}
          </button>
          <p style={{fontSize:".62rem",color:C.gris,textAlign:"center",marginTop:".7rem"}}>Espace réservé aux membres Blazing Dynasty.</p>
        </>}

        {/* ÉTAPE 2 — Choix chef d'équipe */}
        {loginStep===2&&<>
          <div style={{fontSize:".68rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".5rem",textAlign:"center"}}>👑 Ta chef d'équipe</div>
          <p style={{fontSize:".76rem",color:C.gris,textAlign:"center",marginBottom:"1rem",lineHeight:1.6}}>
            Bienvenue {pendingName.split(" ")[0]} ! 🎉<br/>Choisis ta chef d'équipe.
          </p>
          <select value={chefChoisi} onChange={e=>setChefChoisi(e.target.value)}
            style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:10,padding:".6rem .9rem",fontSize:".85rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:"1rem"}}>
            <option value="">— Sélectionne ta chef —</option>
            {chefs.map(c=><option key={c} value={c}>{c.split(" ").map(w=>w.charAt(0).toUpperCase()+w.slice(1)).join(" ")}</option>)}
          </select>
          <button onClick={confirmerChef} disabled={!chefChoisi||loginLoading}
            style={{width:"100%",background:chefChoisi?C.brun:C.pale,color:chefChoisi?C.blanc:C.gris,border:"none",borderRadius:10,padding:".7rem",fontSize:".85rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer",transition:"all .2s"}}>
            {loginLoading?"Sauvegarde...":"Accéder à mon espace →"}
          </button>
          <button onClick={confirmerChef} disabled={loginLoading}
            style={{width:"100%",background:"none",border:"none",color:C.gris,fontSize:".7rem",marginTop:".5rem",cursor:"pointer",fontFamily:"inherit",padding:".3rem"}}>
            Passer cette étape
          </button>
        </>}

      </div>
    </div>
  );


  // ── APP ──────────────────────────────────────────────────────────────────────
  const todayKey=new Date().toISOString().slice(0,10);
  const dailyActions=["a1","a2","a3","a4","a5"];
  const actionsToday=dailyActions.filter(id=>checks[`${todayKey}-${id}`]||checks[id]).length;
  const actionsIncomplete=actionsToday<5;
  const periodeInfo=getPeriodeInfo();
  const isDebutPeriode=periodeInfo.pctElapsed<=10;
  const bannerKey=`bd-banner-${periodeInfo.periodEnd.toISOString().slice(0,10)}`;
  const closeBanner=()=>{try{localStorage.setItem(bannerKey,"1");}catch{}setShowBanner(false);};
  const showPeriodeBanner=isDebutPeriode&&!dismissedPeriode;

  return(
    <div
      style={{minHeight:"100vh",background:C.creme,fontFamily:"'DM Sans',system-ui,sans-serif",color:C.texte,userSelect:"none"}}
      onContextMenu={e=>e.preventDefault()}
      onCopy={e=>e.preventDefault()}
      onCut={e=>e.preventDefault()}
    >

      {/* BANNIÈRE NOUVELLE PÉRIODE */}
      {showPeriodeBanner&&(
        <div style={{background:"linear-gradient(135deg,#C44B1A,#8B3010)",padding:".85rem 1rem",display:"flex",gap:".75rem",alignItems:"flex-start",position:"sticky",top:0,zIndex:150}}>
          <span style={{fontSize:"1.2rem",flexShrink:0}}>🎯</span>
          <div style={{flex:1}}>
            <div style={{fontSize:".78rem",fontWeight:700,color:"white",marginBottom:".2rem"}}>
              Nouvelle période — Fixe tes objectifs !
            </div>
            <div style={{fontSize:".7rem",color:"rgba(255,255,255,.85)",lineHeight:1.5}}>
              Une nouvelle période de 21 jours vient de commencer. Prends 2 minutes pour définir ton CA cible, ton palier et ton objectif de recrues.
            </div>
            <button onClick={()=>{setTab("dashboard");setDismissedPeriode(true);}}
              style={{marginTop:".5rem",background:"white",color:"#C44B1A",border:"none",borderRadius:8,padding:".3rem .75rem",fontSize:".72rem",fontWeight:700,fontFamily:"inherit",cursor:"pointer"}}>
              → Définir mes objectifs
            </button>
          </div>
          <button onClick={()=>setDismissedPeriode(true)}
            style={{background:"none",border:"none",color:"rgba(255,255,255,.6)",cursor:"pointer",fontSize:".9rem",padding:".1rem",flexShrink:0,fontFamily:"inherit"}}>
            ✕
          </button>
        </div>
      )}

      {/* HEADER */}
      <div style={{background:C.brun,padding:"1rem 1rem .85rem",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",inset:0,backgroundImage:"repeating-linear-gradient(45deg,transparent,transparent 20px,rgba(196,168,130,.04) 20px,rgba(196,168,130,.04) 21px)"}}/>
        <div style={{position:"relative",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <div style={{fontSize:".52rem",fontWeight:700,letterSpacing:".2em",color:C.or}}>✦ BLAZING DYNASTY</div>
            <div style={{fontFamily:"Georgia,serif",fontSize:"1.05rem",fontWeight:300,color:C.blanc,marginTop:".15rem"}}>
              Bonjour <strong style={{color:C.or,fontWeight:600}}>{name}</strong>
            </div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:".5rem"}}>
            {/* Notification actions du jour */}
            {actionsIncomplete&&(
              <button onClick={()=>setTab("dashboard")}
                style={{display:"flex",alignItems:"center",gap:".35rem",background:"rgba(196,154,138,.2)",border:`1px solid ${C.rose}`,borderRadius:20,padding:".25rem .6rem",cursor:"pointer",fontFamily:"inherit"}}>
                <span style={{width:16,height:16,borderRadius:"50%",background:C.rose,color:"white",fontSize:".52rem",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>{5-actionsToday}</span>
                <span style={{fontSize:".6rem",color:C.pale,fontWeight:600}}>actions restantes</span>
              </button>
            )}
            {!actionsIncomplete&&(
              <div style={{display:"flex",alignItems:"center",gap:".3rem",background:"rgba(127,175,138,.15)",border:`1px solid ${C.vert}`,borderRadius:20,padding:".25rem .6rem"}}>
                <span style={{fontSize:".7rem"}}>✅</span>
                <span style={{fontSize:".6rem",color:C.vert,fontWeight:600}}>Journée complète !</span>
              </div>
            )}
            <button onClick={()=>{try{localStorage.removeItem("bd-user");}catch{}setScreen("login");}} style={{padding:".25rem .6rem",fontSize:".6rem",color:C.gris,border:`1px solid rgba(196,168,130,.2)`,borderRadius:20,background:"none",cursor:"pointer",fontFamily:"inherit"}}>↩</button>
          </div>
        </div>
        <div style={{position:"relative",marginTop:".6rem",display:"flex",gap:".5rem"}}>
          <div style={{flex:1}}>
            <div style={{display:"flex",justifyContent:"space-between",fontSize:".55rem",color:C.pale,opacity:.7,marginBottom:".2rem"}}>
              <span>Posts cochés</span><span>{donePosts}/{allPosts.length}</span>
            </div>
            <div style={{height:3,background:"rgba(255,255,255,.1)",borderRadius:10,overflow:"hidden"}}>
              <div style={{height:"100%",background:C.rose,width:(allPosts.length?Math.round(donePosts/allPosts.length*100):0)+"%",borderRadius:10,transition:"width .4s"}}/>
            </div>
          </div>
        </div>
      </div>

      {/* NAV */}
      <div style={{background:C.blanc,borderBottom:`1px solid ${C.pale}`,display:"flex",overflowX:"auto",position:"sticky",top:0,zIndex:100,boxShadow:"0 1px 8px rgba(61,31,14,.06)"}}>
        {TABS.map(tb=>(
          <button key={tb.id} onClick={()=>setTab(tb.id)}
            style={{flex:"none",padding:".72rem .85rem",fontSize:".6rem",fontWeight:600,letterSpacing:".05em",textTransform:"uppercase",color:tab===tb.id?C.brun:C.gris,border:"none",borderBottom:`2px solid ${tab===tb.id?C.rose:"transparent"}`,background:"none",cursor:"pointer",whiteSpace:"nowrap",fontFamily:"inherit",transition:"all .2s"}}>
            {tb.label}
          </button>
        ))}
      </div>

      {/* BANNIÈRE DÉBUT DE PÉRIODE */}
      {showBanner&&(
        <div style={{background:"linear-gradient(135deg,#C44B1A,#8B3010)",padding:".85rem 1rem",position:"relative",zIndex:50}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:".75rem"}}>
            <div style={{flex:1}}>
              <div style={{fontSize:".65rem",fontWeight:700,letterSpacing:".12em",color:"rgba(255,220,180,.9)",marginBottom:".2rem"}}>🎯 NOUVELLE PÉRIODE MIHI</div>
              <div style={{fontFamily:"Georgia,serif",fontSize:".95rem",color:"white",fontWeight:300,lineHeight:1.3,marginBottom:".35rem"}}>
                C'est le moment de définir<br/><em style={{fontStyle:"italic",color:"#FFD9A0"}}>tes objectifs pour cette période</em>
              </div>
              <p style={{fontSize:".72rem",color:"rgba(255,220,180,.8)",lineHeight:1.5,margin:"0 0 .6rem"}}>
                CA visé · Palier à atteindre · Nombre de recrues — note-les maintenant pour suivre ta progression.
              </p>
              <div style={{display:"flex",gap:".5rem"}}>
                <button onClick={()=>{setTab("dashboard");closeBanner();}}
                  style={{background:"rgba(255,255,255,.2)",border:"1px solid rgba(255,255,255,.4)",borderRadius:8,padding:".35rem .75rem",fontSize:".72rem",fontWeight:700,color:"white",cursor:"pointer",fontFamily:"inherit"}}>
                  Définir mes objectifs →
                </button>
                <button onClick={closeBanner}
                  style={{background:"none",border:"1px solid rgba(255,255,255,.2)",borderRadius:8,padding:".35rem .65rem",fontSize:".72rem",color:"rgba(255,255,255,.6)",cursor:"pointer",fontFamily:"inherit"}}>
                  Plus tard
                </button>
              </div>
            </div>
            <button onClick={closeBanner}
              style={{background:"none",border:"none",color:"rgba(255,255,255,.5)",fontSize:".9rem",cursor:"pointer",padding:".2rem",flexShrink:0,fontFamily:"inherit"}}>
              ✕
            </button>
          </div>
        </div>
      )}

      {loading&&<div style={{textAlign:"center",padding:"2rem",color:C.gris,fontSize:".8rem"}}>Chargement...</div>}

      <div style={{maxWidth:680,margin:"0 auto",padding:"1.1rem 1rem 4rem"}}>

        {/* ── HOME ── */}
        {tab==="home"&&(
          <div>
            <div style={{background:C.brun,borderRadius:16,padding:"1.4rem",marginBottom:"1rem",position:"relative",overflow:"hidden"}}>
              <div style={{position:"absolute",top:-15,right:-15,width:90,height:90,borderRadius:"50%",background:"rgba(196,154,138,.08)"}}/>
              <div style={{fontSize:".58rem",fontWeight:700,letterSpacing:".18em",color:C.or,marginBottom:".4rem"}}>✦ ESPACE PRIVÉ</div>
              <div style={{fontFamily:"Georgia,serif",fontSize:"1.25rem",fontWeight:300,color:C.blanc,lineHeight:1.2,marginBottom:".4rem"}}>
                Ton hub de formation<br/><em style={{fontStyle:"italic",color:C.pale}}>Blazing Dynasty</em>
              </div>
              <p style={{fontSize:".73rem",color:C.pale,lineHeight:1.65,opacity:.85}}>
                Formations · Stratégies · Outils · Idées de posts · Suivi recrutement. Tout est ici.
              </p>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:".5rem",marginBottom:"1rem"}}>
              {[["8","parties démarrage",C.rose],["11","replays Zoom",C.or],[String(allPosts.length),"idées de posts",C.lilas]].map(([n,l,col])=>(
                <div key={l} style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:".7rem .5rem",textAlign:"center"}}>
                  <div style={{fontFamily:"Georgia,serif",fontSize:"1.6rem",fontWeight:600,color:col,lineHeight:1}}>{n}</div>
                  <div style={{fontSize:".58rem",color:C.gris,marginTop:".15rem",lineHeight:1.3}}>{l}</div>
                </div>
              ))}
            </div>
            {[
              {id:"blazing",icon:"🔥",col:C.rose,label:"Blazing Dynasty — La vision"},
              {id:"mihi",icon:"🏢",col:C.or,label:"Comprendre Mihi & gagner de l'argent"},
              {id:"demarrage",icon:"📚",col:C.rose,label:"Formation Démarrage Rapide — 8 parties"},
              {id:"vente",icon:"🎯",col:C.or,label:"Vente · Stratégies · Booster ses ventes"},
              {id:"recrutement",icon:"👥",col:C.rose,label:"Recrutement · Affiliation · Diagnostique"},
              {id:"contenu",icon:"📱",col:C.lilas,label:"Contenu · Posts · Storytelling · Cible"},
              {id:"devperso",icon:"🧠",col:C.lilas,label:"Développement Personnel"},
              {id:"outils",icon:"🛠️",col:C.or,label:"Outils — Canva · CapCut · Linktree"},
              {id:"sprint",icon:"⚡",col:C.rose,label:"Sprint Recrutement 7 jours"},
              {id:"suivi",icon:"📋",col:C.lilas,label:"Checklist Nouvelle Recrue"},
            ].map(s=>(
              <div key={s.id} onClick={()=>setTab(s.id)}
                style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:".7rem 1rem",marginBottom:".45rem",display:"flex",alignItems:"center",gap:".65rem",cursor:"pointer"}}>
                <div style={{width:30,height:30,borderRadius:"50%",background:s.col+"20",display:"flex",alignItems:"center",justifyContent:"center",fontSize:".85rem",flexShrink:0}}>{s.icon}</div>
                <div style={{fontFamily:"Georgia,serif",fontSize:".88rem",fontWeight:600,color:C.brun,flex:1}}>{s.label}</div>
                <div style={{color:C.rose,fontSize:".68rem"}}>→</div>
              </div>
            ))}
          </div>
        )}

        {/* ── BLAZING DYNASTY ── */}
        {tab==="blazing"&&(
          <div>
            <div style={{background:C.brun,borderRadius:16,padding:"2rem 1.4rem",marginBottom:"1rem",textAlign:"center",position:"relative",overflow:"hidden"}}>
              <div style={{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",width:200,height:200,borderRadius:"50%",background:"rgba(196,154,138,.05)"}}/>
              <div style={{position:"relative",fontSize:".58rem",fontWeight:700,letterSpacing:".25em",color:C.or,marginBottom:".5rem"}}>✦ NOTRE ÉQUIPE ✦</div>
              <div style={{position:"relative",fontFamily:"Georgia,serif",fontSize:"clamp(2rem,6vw,2.8rem)",fontWeight:300,color:C.blanc,lineHeight:1}}>Blazing</div>
              <div style={{position:"relative",fontFamily:"Georgia,serif",fontSize:"clamp(2rem,6vw,2.8rem)",fontStyle:"italic",color:C.pale,lineHeight:1.1}}>Dynasty</div>
              <div style={{width:48,height:1,background:C.or,margin:".9rem auto"}}/>
              <p style={{position:"relative",fontSize:".77rem",color:C.pale,opacity:.85,lineHeight:1.7,maxWidth:380,margin:"0 auto"}}>
                Une équipe de femmes ambitieuses, bienveillantes et déterminées. Pas juste un groupe — une famille qui avance ensemble vers la liberté financière.
              </p>
            </div>
            {[
              ["🌍","Une équipe internationale","Présente en France, au Portugal et au-delà. Nous grandissons ensemble, sans frontières."],
              ["💎","L'excellence comme standard","Pas pour être parfaite — pour être la meilleure version de soi. Chaque jour un peu plus."],
              ["🤝","L'entraide avant tout","Ici on ne laisse personne derrière. Si tu avances, tu tends la main à celles qui arrivent après toi."],
              ["🔥","L'ambition assumée","Nous ne nous excusons pas d'avoir des objectifs. Nous les partageons, nous nous y tenons, nous les atteignons."],
              ["👑","Des leaders, pas des vendeuses","Blazing Dynasty forme des entrepreneures et des leaders de réseau."],
            ].map(([icon,title,desc])=>(
              <div key={title} style={{display:"flex",gap:".65rem",marginBottom:".65rem",alignItems:"flex-start",background:C.blanc,borderRadius:12,padding:".75rem",border:`1px solid ${C.pale}`}}>
                <div style={{width:30,height:30,borderRadius:"50%",background:C.pale,display:"flex",alignItems:"center",justifyContent:"center",fontSize:".85rem",flexShrink:0}}>{icon}</div>
                <div><div style={{fontSize:".8rem",fontWeight:600,color:C.brun,marginBottom:".1rem"}}>{title}</div><div style={{fontSize:".72rem",color:C.gris,lineHeight:1.55}}>{desc}</div></div>
              </div>
            ))}
            <div style={{background:C.brun,borderRadius:14,padding:"1.2rem",marginBottom:".75rem"}}>
              <div style={{fontFamily:"Georgia,serif",fontSize:"1rem",fontWeight:600,color:C.or,marginBottom:".65rem"}}>✦ Nos valeurs</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".4rem"}}>
                {["Authenticité","Ambition","Bienveillance","Excellence","Liberté","Sororité"].map(v=>(
                  <div key={v} style={{background:"rgba(196,168,130,.12)",borderRadius:8,padding:".4rem .65rem",fontSize:".72rem",fontWeight:600,color:C.pale,textAlign:"center"}}>✦ {v}</div>
                ))}
              </div>
            </div>
            <div style={{background:`linear-gradient(135deg,rgba(196,154,138,.12),rgba(168,155,181,.08))`,border:`1px solid ${C.pale}`,borderRadius:14,padding:"1.1rem",textAlign:"center"}}>
              <div style={{fontFamily:"Georgia,serif",fontSize:"1.05rem",fontStyle:"italic",color:C.brun,lineHeight:1.65}}>"Seule on va plus vite. Ensemble on va plus loin."</div>
              <div style={{fontSize:".63rem",color:C.gris,marginTop:".4rem"}}>— Blazing Dynasty</div>
            </div>
          </div>
        )}

        {/* ── MIHI ── */}
        {tab==="mihi"&&(
          <div>
            <SecTitle title="Comprendre" em="Mihi" desc="L'essentiel sur la marque, les gammes et comment construire ton revenu."/>
            <Card title="Qui est Mihi ?" sub="Histoire · Valeurs · Forces" icon="🏢" color={C.or} defaultOpen>
              <Info color={C.or}>Mihi est une marque polonaise de bien-être, beauté et soins, portée par le laboratoire pharmaceutique <strong>ElfaPharm</strong>. Des produits avec de vraies études scientifiques derrière.</Info>
              {[
                ["🧬","Fondée par ElfaPharm","Un laboratoire pharmaceutique sérieux. Ce n'est pas du marketing — il y a une vraie R&D derrière les produits."],
                ["🌍","Présente dans 30+ pays","Une marque qui grandit vite, avec des produits testés et approuvés sur plusieurs marchés européens."],
                ["💎","Rapport qualité/prix","Des produits comparables aux grandes marques de pharmacie, à des prix distributeur compétitifs."],
                ["🔄","Modèle de vente directe","Tu distribues en direct, tes clientes commandent sur ta boutique personnelle. Pas de stock obligatoire."],
              ].map(([icon,title,desc])=>(
                <div key={title} style={{display:"flex",gap:".6rem",marginBottom:".55rem",alignItems:"flex-start"}}>
                  <div style={{width:28,height:28,borderRadius:"50%",background:C.pale,display:"flex",alignItems:"center",justifyContent:"center",fontSize:".8rem",flexShrink:0}}>{icon}</div>
                  <div><div style={{fontSize:".78rem",fontWeight:600,color:C.brun,marginBottom:".1rem"}}>{title}</div><div style={{fontSize:".71rem",color:C.gris,lineHeight:1.5}}>{desc}</div></div>
                </div>
              ))}
            </Card>

            <Card title="Les gammes Mihi" sub="Ce que tu peux vendre" icon="💄" color={C.lilas}>
              {[
                ["✨","Skincare — Soin visage","Crèmes anti-âge, sérums, contour des yeux, gommages visage, mousses nettoyantes. Des soins avec de vraies actifs à des prix accessibles."],
                ["💇","Soins cheveux","Shampoings réparateurs, baumes, soins capillaires. Résultats visibles rapidement. Argument fort : résultats comparables aux marques pro, prix bien inférieurs."],
                ["💄","Make-up","Mascara volume, fond de teint matifiant, rouge à lèvres longue tenue. Qualité professionnelle. Facile à démontrer, facile à vendre."],
                ["💊","Compléments alimentaires & Perte de poids","Détox, brûle-graisses, booster de métabolisme, ginkgo biloba, vitamines. Gamme très demandée. Les résultats créent de la fidélité."],
                ["🌸","Parfums","Des jus de qualité, comparables aux grandes marques, à moins de 20€. C'est l'argument qui surprend tout le monde et crée des ventes immédiates."],
                ["🧴","Soin corps","Gommages effet or, baumes satinés, enveloppements. Un rituel luxueux à prix accessible. Parfait pour les box surprises et cadeaux."],
              ].map(([icon,title,desc])=>(
                <div key={title} style={{display:"flex",gap:".6rem",marginBottom:".5rem",padding:".6rem .7rem",background:C.creme,borderRadius:9,border:`1px solid ${C.pale}`}}>
                  <span style={{fontSize:"1.1rem",flexShrink:0}}>{icon}</span>
                  <div><div style={{fontSize:".78rem",fontWeight:600,color:C.brun,marginBottom:".1rem"}}>{title}</div><div style={{fontSize:".7rem",color:C.gris,lineHeight:1.55}}>{desc}</div></div>
                </div>
              ))}
            </Card>

            <Card title="Comment gagner de l'argent avec Mihi" sub="Le plan de rémunération détaillé" icon="💰" color={C.or}>
              <Info color={C.or}>Il y a <strong>3 façons</strong> de gagner de l'argent avec Mihi, cumulables. Plus tu avances dans les deux, plus ton revenu est stable et croissant.</Info>

              <div style={{background:C.brun,borderRadius:10,padding:".85rem 1rem",marginBottom:".75rem"}}>
                <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".12em",textTransform:"uppercase",color:C.or,marginBottom:".6rem"}}>💰 Levier 1 — Vente directe</div>
                {[
                  ["Prix distributeur","Tu achètes les produits avec une remise de 20 à 30% sur le prix catalogue selon ton statut."],
                  ["Ta marge","Tu revends au prix catalogue. Ta marge = 20 à 30% du prix de vente. Ex : un produit à 40€ catalogue → tu l'achètes ~28-32€ → tu gagnes 8-12€ par vente."],
                  ["Pas de minimum","Pas de stock obligatoire, pas de commande minimum. Tu commandes ce que tes clientes ont commandé."],
                  ["Immédiat","Le bénéfice est direct, dès ta première vente. Pas de palier à atteindre."],
                ].map(([t,d])=>(
                  <div key={t} style={{display:"flex",gap:".5rem",marginBottom:".45rem"}}>
                    <span style={{color:C.or,flexShrink:0,fontSize:".75rem"}}>✦</span>
                    <div style={{fontSize:".73rem",color:C.pale,lineHeight:1.5}}><strong style={{color:C.or}}>{t} :</strong> {d}</div>
                  </div>
                ))}
              </div>

              <div style={{background:C.brun2,borderRadius:10,padding:".85rem 1rem",marginBottom:".75rem"}}>
                <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".12em",textTransform:"uppercase",color:C.or,marginBottom:".6rem"}}>👥 Levier 2 — Commissions équipe</div>
                {[
                  ["Comment ça marche","Tu recrutes des distributrices dans ton équipe. À chaque commande qu'elles passent, tu touches un pourcentage sur leur volume."],
                  ["Revenu passif","Même quand tu ne travailles pas, ton équipe génère du volume. C'est la base de la liberté financière."],
                  ["Duplication","Plus ton équipe recrute à son tour, plus ta structure grandit et plus tes commissions augmentent — sans que tu aies à faire plus de travail direct."],
                  ["Profondeur","Tu touches des commissions sur plusieurs niveaux de ton équipe selon ton statut de qualification."],
                ].map(([t,d])=>(
                  <div key={t} style={{display:"flex",gap:".5rem",marginBottom:".45rem"}}>
                    <span style={{color:C.or,flexShrink:0,fontSize:".75rem"}}>✦</span>
                    <div style={{fontSize:".73rem",color:C.pale,lineHeight:1.5}}><strong style={{color:C.or}}>{t} :</strong> {d}</div>
                  </div>
                ))}
              </div>

              <div style={{background:"rgba(196,168,130,.12)",border:`1px solid ${C.or}40`,borderRadius:10,padding:".85rem 1rem",marginBottom:".75rem"}}>
                <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".12em",textTransform:"uppercase",color:C.or,marginBottom:".6rem"}}>🏆 Levier 3 — Bonus et qualifications</div>
                {[
                  ["Bonus de démarrage","Quand tu démarres fort les 90 premiers jours, Mihi te verse des bonus supplémentaires sur ton volume personnel et équipe."],
                  ["Bonus mensuel","À chaque mois où tu atteins les objectifs de ton palier, tu touches un bonus en plus de tes commissions."],
                  ["Paliers de qualification","Distributrice → Senior → Directrice → Senior Directrice → Directrice Business. Chaque palier = plus de pourcentages et plus de bonus."],
                  ["Voyages & récompenses","Les meilleurs rangs ont accès à des voyages et événements offerts par Mihi."],
                ].map(([t,d])=>(
                  <div key={t} style={{display:"flex",gap:".5rem",marginBottom:".45rem"}}>
                    <span style={{color:C.or,flexShrink:0,fontSize:".75rem"}}>✦</span>
                    <div style={{fontSize:".73rem",color:C.texte,lineHeight:1.5}}><strong style={{color:C.brun}}>{t} :</strong> {d}</div>
                  </div>
                ))}
              </div>

              <div style={{background:C.brun,borderRadius:9,padding:".7rem .9rem",fontSize:".74rem",color:C.pale,lineHeight:1.65}}>
                💡 <strong style={{color:C.or}}>Exemple concret :</strong> Tu vends 500€ de produits ce mois → tu gardes ~125-150€ de marge. Ton équipe génère 2 000€ de volume → tu touches ~100-200€ de commissions en plus. Total : 225-350€ pour ce mois. Plus ton équipe grandit, plus le ratio s'inverse en ta faveur.
              </div>
            </Card>

            <Card title="Les programmes clients Mihi" sub="Tes arguments de vente — détails complets" icon="🎁" color={C.rose}>
              <Info>Ces programmes sont tes <strong>arguments de vente et de fidélisation</strong>. Connais-les par cœur — une cliente bien informée revient toujours.</Info>

              {[
                {icon:"🎁",title:"Welcome Bonus",tag:"1ʳᵉ commande",color:C.rose,details:[
                  "5 € offerts automatiquement sur le compte promo de chaque nouvelle cliente, dès l'inscription.",
                  "Un set de produits best-sellers disponible pour les débutants à prix réduit.",
                  "Des échantillons offerts pour toute commande passée dans les 24h après l'inscription.",
                  "👉 Comment l'utiliser : \"En t'inscrivant via mon lien aujourd'hui, tu reçois 5 € sur ta première commande. C'est automatique, pas de code promo.\"",
                ]},
                {icon:"♾️",title:"Infinity Bonus",tag:"Fidélité",color:C.lilas,details:[
                  "À partir de la 2ᵉ commande : dès 40 € de commande au prix catalogue, ta cliente choisit 1 produit du catalogue avec -70%.",
                  "Ce bonus est ILLIMITÉ — il se renouvelle à chaque période, tant qu'elle commande.",
                  "Si elle saute une période : elle doit recommander 2 périodes consécutives pour retrouver le droit.",
                  "Tous les produits sont éligibles sauf les sets et les produits \"Extra\".",
                  "👉 Comment l'utiliser : \"À chaque commande de 40 €, tu as le droit de choisir un produit à -70 %. Ça fait souvent une valeur de 20-30 € offerts.\"",
                ]},
                {icon:"🎟️",title:"Token Store",tag:"Ton outil de réachat",color:C.or,details:[
                  "Tu achètes des tokens avec ton compte promo ou ton Recruitment Bonus, et tu les envoies à tes clientes.",
                  "3 types de tokens : 5 € en cadeau (coûte 2 € pour toi) · Produit offert (2,50 €) · Remise -70% (0,50 €).",
                  "Le token est valable 24h après envoi. Si la cliente ne l'utilise pas → tu es remboursée automatiquement.",
                  "Fonctionne sur commande minimum de 40 €.",
                  "👉 Quand l'utiliser : pour relancer une cliente silencieuse, anniversaire, après une vente réussie, ou pour déclencher une 1ʳᵉ commande.",
                ]},
                {icon:"💰",title:"Recruitment Bonus",tag:"Pour toi en tant que distributrice",color:C.brun,details:[
                  "À chaque période où tu enregistres au moins 1 nouveau client avec une commande : 5 € crédités dans ton Token Store.",
                  "Ces 5 € servent directement à acheter des tokens pour tes clientes.",
                  "Non cumulatif sur plusieurs nouveaux clients — c'est 5 € fixe par période active.",
                  "👉 Utilité directe : recrute des clientes régulièrement pour alimenter ton Token Store sans bourse délier.",
                ]},
                {icon:"🛍️",title:"Smart Shopping Program",tag:"Automatique",color:C.lilas,details:[
                  "L'IA Mihi analyse les achats de chaque cliente et lui envoie automatiquement un SMS personnalisé.",
                  "L'offre : -50 % sur un produit de sa commande précédente, valable 24h.",
                  "En plus : une recommandation pop-up au moment du panier avec +5 % de remise sur un produit complémentaire.",
                  "Tu n'as rien à faire — mais informe tes clientes que ce programme existe pour qu'elles commandent à chaque période.",
                  "👉 Argument vente : \"Mihi t'envoie automatiquement des offres -50% sur tes produits préférés. Raison de plus de commander régulièrement.\"",
                ]},
                {icon:"👑",title:"Premium Club",tag:"Statut VIP",color:C.or,details:[
                  "Statut accessible aux clientes qui commandent régulièrement des volumes importants.",
                  "Avantages exclusifs : accès à des produits et sets réservés aux membres Premium, remises spéciales, privilèges.",
                  "👉 Comment le vendre : propose-le comme une récompense à tes meilleures clientes. \"Tu commandes souvent — tu mérites le statut Premium Club avec des avantages exclusifs.\"",
                ]},
              ].map(prog=>(
                <div key={prog.title} style={{background:C.creme,borderRadius:10,padding:".8rem",marginBottom:".65rem",border:`1px solid ${C.pale}`}}>
                  <div style={{display:"flex",gap:".5rem",alignItems:"center",marginBottom:".55rem"}}>
                    <span style={{fontSize:"1.1rem"}}>{prog.icon}</span>
                    <div style={{fontSize:".82rem",fontWeight:600,color:C.brun,flex:1}}>{prog.title}</div>
                    <span style={{background:prog.color+"22",color:prog.color===C.or?C.brun2:prog.color,fontSize:".55rem",fontWeight:700,letterSpacing:".08em",textTransform:"uppercase",padding:".13rem .4rem",borderRadius:20}}>{prog.tag}</span>
                  </div>
                  {prog.details.map((d,i)=>(
                    <div key={i} style={{fontSize:".72rem",color:d.startsWith("👉")?C.brun:C.gris,lineHeight:1.6,marginBottom:".28rem",fontWeight:d.startsWith("👉")?600:400,fontStyle:d.startsWith("👉")?"italic":"normal"}}>{d}</div>
                  ))}
                </div>
              ))}
            </Card>
          </div>
        )}

        {/* ── DÉMARRAGE RAPIDE ── */}
        {tab==="demarrage"&&(
          <div>
            <SecTitle title="Formation" em="Démarrage Rapide" desc="8 parties — étape par étape ce qu'il faut faire pour réussir. Court, efficace, actionnable."/>
            <Info>💡 Commence par la Partie 1 et avance dans l'ordre. Chaque partie a ses ressources et ses exercices.</Info>
            <AdminContentBlock onglet="demarrage" items={adminItems}/>

            {[
              {num:"1",title:"Les bases — Par où commencer",desc:"Comprendre l'environnement, les outils essentiels et poser les premières fondations.",links:[
                {type:"drive",label:"Vidéo — Les bases partie 1",url:"https://drive.google.com/file/d/1R0tOp4vVBULqHWE8W8vkUDIZ3g03vXYl/view"},
                {type:"drive",label:"Vidéo — Les bases partie 2",url:"https://drive.google.com/file/d/1lJN37k3pwtvz5h7Hx_9PLATq9t00__sn/view"},
                {type:"drive",label:"Vidéo — Les bases partie 3",url:"https://drive.google.com/file/d/1A3N676HlNI0WL07xzNLLnZTnJaxazEP6/view"},
              ],ex:["Configure ta boutique Mihi personnelle","Fais ta liste des 20 premiers contacts","Prends en main les outils de base"]},
              {num:"2",title:"Le post de lancement",desc:"Comment créer et publier ton premier post d'annonce — le moment clé de ton démarrage.",links:[
                {type:"drive",label:"Vidéo — Le post de lancement partie 1",url:"https://drive.google.com/file/d/1Y6HDL3sieUjISsmPCr45rUHSPgQlva4G/view"},
                {type:"drive",label:"Vidéo — Le post de lancement partie 2",url:"https://drive.google.com/file/d/1pGuFpiVhUaVwReo4iuZGJYSSJjepG1uA/view"},
              ],ex:["Rédige ton post de lancement (authentique, pas copié-collé)","Publie-le sur Instagram ET Facebook","Note les personnes qui interagissent — ce sont tes premiers prospects"]},
              {num:"3",title:"Ton profil et ta stratégie de contenu",desc:"Comment optimiser ton profil et structurer ton contenu pour attirer naturellement.",links:[
                {type:"drive",label:"Vidéo — Profil et contenu",url:"https://drive.google.com/file/d/1-KohFYBfAhXQwrGRYJ3RxOOoryONttOb/view"},
                {type:"doc",label:"Document — Stratégie contenu",url:"https://docs.google.com/document/d/16sNdKx-lE77hGHb8lPdGsN7gUwIScIHTPVXkBDj_FsA/edit"},
                {type:"drive",label:"Vidéo complémentaire",url:"https://drive.google.com/file/d/1xVrfvzzIyeqoUQjeBkJv5c2YnzOt0Wdw/view"},
              ],ex:["Optimise ta bio (photo pro + description + lien)",
"Planifie tes 3 premiers posts de la semaine","Mets en place ta routine de stories quotidiennes"]},
              {num:"4",title:"La prospection et le suivi",desc:"Comment approcher les gens, relancer sans être relou, et convertir les curieuses.",links:[
                {type:"drive",label:"Vidéo — Prospection partie 1",url:"https://drive.google.com/file/d/1Psoqrqxw9-xZKIcmLKCBwc7Jn3KD-Zys/view"},
                {type:"drive",label:"Vidéo — Prospection partie 2",url:"https://drive.google.com/file/d/1WA_42brh1YzCfnLM2p32NsiNOSlHDGLN/view"},
                {type:"doc",label:"Document — Scripts de prospection",url:"https://docs.google.com/document/d/12mT8rwV0q8L8hqEe27lsRyeMG-lO0P4fOzaZxwKsQlc/edit"},
              ],ex:["Envoie 3 messages personnels à tes contacts chauds","Utilise les scripts du document en les adaptant à ta voix","Note toutes tes conversations dans un tableau de suivi"]},
              {num:"5",title:"Les présentations et le closing",desc:"Comment présenter l'opportunité et les produits pour déclencher la décision.",links:[
                {type:"drive",label:"Vidéo — Présentation et closing 1",url:"https://drive.google.com/file/d/1dwWb4ti6DOo7wKj23baLnDgyOU4U4QYL/view"},
                {type:"drive",label:"Vidéo — Présentation et closing 2",url:"https://drive.google.com/file/d/1mgtSJqfTZv8_qJhyLRIF01SFqzyApA8-.view"},
              ],ex:["Pratique le pitch express (30 sec) jusqu'à ce que ce soit naturel","Prépare ta présentation complète de 15 min","Fais une présentation test avec une amie avant la vraie"]},
              {num:"6",title:"Les réseaux sociaux en profondeur",desc:"Algorithmes, stratégies de visibilité, ce qui marche vraiment en 2024/2025.",links:[
                {type:"drive",label:"Vidéo — Réseaux sociaux 1",url:"https://drive.google.com/file/d/1bQXLCCw3Ztz-JqEeYF2lPurC2XnfCjNp/view"},
                {type:"drive",label:"Vidéo — Réseaux sociaux 2",url:"https://drive.google.com/file/d/1yLaBkGy_Vu_nMjO54QgG7F2xRjZPXuf8/view"},
              ],ex:["Identifie 3 types de contenus qui fonctionnent sur ton profil","Mets en place ton planning editorial hebdomadaire","Teste un nouveau format cette semaine (Reel, carrousel, story sondage)"]},
              {num:"7",title:"Développer son équipe",desc:"Comment recruter, accueillir et dupliquer — construire une vraie organisation.",links:[
                {type:"drive",label:"Vidéo — Développement équipe 1",url:"https://drive.google.com/file/d/1X4IwW_9jLY0NjTAzKbu79q57KXw1Psqw/view"},
                {type:"drive",label:"Vidéo — Développement équipe 2",url:"https://drive.google.com/file/d/1khEwcug2I_oU4W29_ZIZ-p3uXYgme9J-.view"},
              ],ex:["Identifie 3 personnes dans ta liste pour qui l'opportunité Blazing Dynasty serait parfaite","Prépare ton message d'approche personnalisé pour chacune","Mets en place la checklist d'accueil pour ta première recrue"]},
              {num:"8",title:"Passer à la vitesse supérieure",desc:"Leadership, duplication, construire une organisation qui tourne même quand tu n'es pas là.",links:[
                {type:"drive",label:"Vidéo — Leadership et duplication 1",url:"https://drive.google.com/file/d/1Qyv57Lb6ogn-RPiptlfUnXAaOa8spdMf/view"},
                {type:"drive",label:"Vidéo — Leadership et duplication 2",url:"https://drive.google.com/file/d/1eKJCfgcQbDN5Tqqv9_skMzB3qYVo-lZj/view"},
              ],ex:["Forme ta première recrue en lui faisant suivre ce même parcours","Délègue une tâche à un membre de ton équipe cette semaine","Fixe ton objectif de qualification Mihi pour les 90 prochains jours"]},
            ].map(part=>{
              const checkId=`forma-part-${part.num}`;
              const done=checks[checkId];
              return(
              <Card key={part.num} title={`Partie ${part.num} — ${part.title}`} sub={part.desc} icon={done?"✅":part.num} color={done?C.vert:C.rose}>
                {/* Case à cocher formation validée */}
                <div onClick={()=>tog("checks",checkId)}
                  style={{display:"flex",alignItems:"center",gap:".6rem",background:done?C.vert+"15":C.creme,borderRadius:9,padding:".55rem .8rem",marginBottom:".75rem",cursor:"pointer",border:`1px solid ${done?C.vert:C.pale}`}}>
                  <div style={{width:20,height:20,borderRadius:5,border:`2px solid ${done?C.vert:C.gris}`,background:done?C.vert:"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,transition:"all .15s"}}>
                    {done&&<span style={{fontSize:".65rem",color:"white",fontWeight:700}}>✓</span>}
                  </div>
                  <span style={{fontSize:".75rem",fontWeight:600,color:done?C.vert:C.gris}}>{done?"✅ Formation validée !":"Cocher quand la formation est terminée"}</span>
                </div>
                <p style={{fontSize:".76rem",color:C.texte,lineHeight:1.65,marginBottom:".75rem"}}>{part.desc}</p>
                <div style={{marginBottom:".75rem"}}>
                  <div style={{fontSize:".58rem",fontWeight:700,letterSpacing:".12em",textTransform:"uppercase",color:C.rose,marginBottom:".4rem"}}>📹 Ressources</div>
                  {part.links.map(l=>l.type==="drive"?<DriveBtn key={l.url} href={l.url} label={l.label}/>:<DocBtn key={l.url} href={l.url} label={l.label}/>)}
                </div>
                <div style={{fontSize:".58rem",fontWeight:700,letterSpacing:".12em",textTransform:"uppercase",color:C.lilas,marginBottom:".4rem"}}>✦ Exercices</div>
                {part.ex.map((ex,i)=>(
                  <div key={i} style={{display:"flex",gap:".55rem",padding:".42rem 0",borderBottom:`1px solid rgba(232,213,204,.3)`}}>
                    <div style={{width:19,height:19,borderRadius:"50%",background:C.rose+"22",color:C.rose,fontSize:".58rem",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:1}}>{i+1}</div>
                    <div style={{fontSize:".75rem",color:C.texte,lineHeight:1.45,flex:1}}>{ex}</div>
                  </div>
                ))}
              </Card>
            );})}

            <Card title="Vidéos formation — À utiliser dans tes formations" sub="4 vidéos essentielles" icon="📹" color={C.or}>
              <Info color={C.or}>Ces vidéos complètent ta formation. Regarde-les dans l'ordre et applique immédiatement.</Info>
              <DriveBtn href="https://drive.google.com/file/d/1Qit_DVf9bNHqX7Kh188J6B0PYGda8w15/view" label="1 · Parler des produits pour vendre"/>
              <Btn href="https://us06web.zoom.us/rec/share/hnDWdngAPCK_SGVTYzVhgk70t_nqqfesUvZF7hme8CaEgL-CpszXoantB-d2MSPZ.Yl7wHQ7KV9pZJnCL" label="2 · Communiquer différemment pour passer au niveau supérieur" icon="▶" color={C.brun}/>
              <DriveBtn href="https://drive.google.com/file/d/1TOxUHEMeNXQepUGlYcaoAVaW7c4MdLfA/view" label="3 · Tips pour créer un Reel"/>
              <DriveBtn href="https://drive.google.com/file/d/1kBWsarJ0SDW8tc3UpLC0UBKRMUffO8p1/view" label="4 · Faire ses premières vidéos"/>
            </Card>
          </div>
        )}

        {/* ── VENTE ── */}
        {tab==="vente"&&(
          <div>
            <SecTitle title="Vente &" em="Stratégies" desc="Tout pour vendre plus, fidéliser tes clientes et booster ton activité."/>
            <AdminContentBlock onglet="vente" items={adminItems}/>

            <Card title="Replays Zoom Vente" sub="Les sessions de formation vente" icon="🎥" color={C.or} defaultOpen>
              <Btn href="https://us06web.zoom.us/rec/share/3i2Txz0KmPwoECQyE7ADbkCr_kDej-QYp_7vW2_YmzpWGSnkipRh5-v7t7oa6r2U.czfOEisyPOYCjYsG" label="Tips de vente + comprendre son pourquoi" icon="▶" color={C.brun}/>
              <Btn href="https://us06web.zoom.us/rec/share/IFStg6CC8vBngO3HPu9G5fh91zV9W6fuwaR3txBwRc96v7vO0-azbiea2eA-d1Hf.MgYK9kyFy7z2kIHB" label="Comment faire ses Lives + déclencher des ventes" icon="▶" color={C.brun}/>
              <Btn href="https://us06web.zoom.us/rec/share/RwAb_48QbKt_jrn_91SJbfXZ8Sf8shCOpxzixhX0HdElfb4xDOU9nBEq-OdNms2b.RRxzRJZ53fmbvprr" label="Les réunions à domicile" icon="▶" color={C.brun}/>
              <Btn href="https://us06web.zoom.us/rec/share/nMz-EPawKi9Iz7vnwqFELpJaK6kJH2aXLaE-evMxN9KiPzBuRIjbmrA77-e41RMv.wpFb79BqNh9yETMe" label="Comment parler des produits (exercice équipe)" icon="▶" color={C.brun}/>
            </Card>

            <Card title="Stratégies de vente" sub="Les méthodes qui marchent" icon="💡" color={C.or}>
              <div style={{fontSize:".58rem",fontWeight:700,letterSpacing:".12em",textTransform:"uppercase",color:C.or,marginBottom:".5rem"}}>📁 Documents stratégies</div>
              <DriveBtn href="https://drive.google.com/file/d/1Qit_DVf9bNHqX7Kh188J6B0PYGda8w15/view" label="Stratégie Enveloppe Mystère — Vidéo"/>
              <DocBtn href="https://docs.google.com/document/d/1BMF1FiXl7HTjQ-kIJYNl_cHh-J-K1Mk5irfunsN6s4c/edit" label="Stratégie Enveloppe Mystère — Document complet"/>
              <DriveBtn href="https://drive.google.com/file/d/1XkJRZMArmWqTy11xCTaJagR4s-vEOdtL/view" label="Stratégie Catalogue — Vidéo"/>
              <DocBtn href="https://docs.google.com/document/d/19wRJArnlDVpzBd1RFxefJCvNcTStFS_TeMNzBe6SUnc/edit" label="Stratégie Catalogue — Document complet"/>
              <DriveBtn href="https://drive.google.com/file/d/1S7IMHB9xUqY43JQRuqa8mtlqY7kabv8t/view" label="Stratégie Défi Live — Vidéo"/>
              <DocBtn href="https://docs.google.com/document/d/1B9b2O7W2crNlRSgTub1QQ1h_lSn87kgGf7Q8dng_nwo/edit" label="Stratégie Défi Live — Document complet"/>
              <DriveBtn href="https://drive.google.com/file/d/1KldVcCgrfLjirxVZjyXtFCpECinKevWs/view" label="Stratégie Liste — Vidéo"/>
              <DocBtn href="https://docs.google.com/document/d/1-GSGmYlH9eyIWn-QjUW8JdGDmN7-ZtA-CfWyMO8AF6s/edit" label="Stratégie C'est Interdit 🔥"/>
            </Card>

            <Card title="Idées pour booster ses ventes" sub="Méthodes créatives et efficaces" icon="🚀" color={C.rose}>
              {[
                ["📦","Box surprises","La cliente choisit un montant (ex: 30€, 50€, 80€). Tu crées une box surprise avec des produits adaptés. Avantage : tu décides de la marge, tu mets en valeur les produits, effet cadeau = émotion = réachat.","Comment vendre ça : \"Tu me donnes un budget, je te crée une box personnalisée avec ce que j'aurai choisi spécialement pour toi. Parfait pour s'offrir ou offrir.\""],
                ["🎰","Tombola produits","La tombola s'auto-finance : les billets paient le lot. Objectif : faire découvrir les produits à de nouvelles personnes. 1 billet = 1 produit Mihi à tester. Les gagnantes deviennent souvent des clientes.","Organisation : 10 billets à 3€ = 30€. Tu achètes le lot à prix distributeur (~15€). Bénéfice réel = 5 nouvelles personnes qui ont découvert les produits."],
                ["🎒","Palette voyageuse","Une trousse avec des échantillons, produits phares, le catalogue et un bon de commande. Tu la fais circuler dans ton entourage (famille, collègues, voisines). Chaque personne la garde 48h.","Résultat : des ventes sans sortir de chez toi. Les gens touchent, testent, commandent."],
                ["🧪","Offre testeurs","Tu recherches 5 personnes pour tester une nouvelle gamme à prix coûtant. Objectif : créer de la preuve sociale et fidéliser. En échange : un témoignage honnête.","Comment le pitcher : \"Je recherche 5 femmes pour tester la nouvelle gamme Face Architect à prix coûtant. En échange, juste ton retour honnête. Intéressée ?\""],
                ["🎮","Jeu concours","Un jeu simple sur tes stories (sondage, devinette, tirage au sort). Le lot = un produit Mihi. Objectif : engagement + visibilité + nouvelles personnes.","Règle d'or : le jeu doit être simple (une action max), le lot doit être désirable, et tu dois relancer les participantes en DM après."],
              ].map(([icon,title,desc,tip])=>(
                <div key={title} style={{background:C.creme,borderRadius:10,padding:".8rem",marginBottom:".65rem",border:`1px solid ${C.pale}`}}>
                  <div style={{display:"flex",gap:".5rem",alignItems:"flex-start",marginBottom:".4rem"}}>
                    <span style={{fontSize:"1rem",flexShrink:0}}>{icon}</span>
                    <div style={{fontSize:".8rem",fontWeight:600,color:C.brun}}>{title}</div>
                  </div>
                  <p style={{fontSize:".74rem",color:C.texte,lineHeight:1.6,marginBottom:".35rem"}}>{desc}</p>
                  <div style={{background:C.blanc,borderRadius:7,padding:".5rem .65rem",fontSize:".71rem",color:C.brun,lineHeight:1.6,fontStyle:"italic",borderLeft:`2px solid ${C.or}`}}>{tip}</div>
                </div>
              ))}
            </Card>

            <Card title="Groupe Messenger clientes" sub="Comment gérer ta communauté cliente" icon="💬" color={C.lilas}>
              <Info color={C.lilas}>Un groupe Messenger bien géré = des clientes engagées qui reviennent. Un groupe mal géré = désengagement et sorties silencieuses.</Info>
              <div style={{fontSize:".58rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.vert,marginBottom:".4rem"}}>✅ À faire</div>
              {["Présenter le groupe dès l'arrivée d'une nouvelle cliente (ton nom, ce que tu partages ici)","Partager des contenus utiles et valorisants (tips beauté, routine, offres en cours)","Annoncer les nouvelles gammes et les programmes clients Mihi","Créer de l'interaction (sondages, questions, avis produits)","Célébrer les résultats des clientes (avant/après, témoignages)","Partager les promotions Mihi (Infinity Bonus, Smart Shopping, tokens)"].map((item,i)=>(
                <div key={i} style={{display:"flex",gap:".5rem",marginBottom:".35rem",alignItems:"flex-start",fontSize:".75rem",color:C.texte}}>
                  <span style={{color:C.vert,flexShrink:0}}>✓</span>{item}
                </div>
              ))}
              <div style={{fontSize:".58rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:"#B04040",marginBottom:".4rem",marginTop:".7rem"}}>❌ À ne pas faire</div>
              {["Spammer avec des promotions tous les jours","Copier-coller des messages génériques Mihi sans personnalisation","Ignorer les questions ou mettre du temps à répondre","Partager des prix sans contexte (toujours montrer la valeur avant le prix)","Créer plusieurs groupes pour la même clientèle (confusion)"].map((item,i)=>(
                <div key={i} style={{display:"flex",gap:".5rem",marginBottom:".35rem",alignItems:"flex-start",fontSize:".75rem",color:C.texte}}>
                  <span style={{color:"#B04040",flexShrink:0}}>✗</span>{item}
                </div>
              ))}
            </Card>

            <Card title="Base du suivi client" sub="Ne plus jamais perdre une cliente" icon="📊" color={C.or}>
              <Info color={C.or}>Une cliente qui ne commande plus n'est pas perdue — elle est juste oubliée. Le suivi c'est ce qui fait la différence entre une activité qui stagne et une qui grandit.</Info>
              {[
                ["Après la 1ʳᵉ commande","Message de remerciement dans les 24h. Demande si tout s'est bien passé. Propose un conseil d'utilisation."],
                ["À J+7","Comment elle trouve les produits ? Elle a des questions ? C'est le moment de créer le lien."],
                ["À J+21","Avant la prochaine période : \"La nouvelle période Mihi arrive, tu veux que je te prévienne des offres en cours ?\""],
                ["Si silence +30j","Relance avec un token ou une offre personnalisée. \"J'ai pensé à toi pour cette offre — ça correspond à ce que tu avais aimé.\""],
                ["À chaque anniversaire","Un message personnel. Un token en cadeau si possible. Les petites attentions créent la fidélité à vie."],
              ].map(([moment,action],i)=>(
                <div key={i} style={{display:"flex",gap:".6rem",marginBottom:".55rem",alignItems:"flex-start"}}>
                  <div style={{width:22,height:22,borderRadius:"50%",background:C.or+"30",color:C.brun2,fontSize:".58rem",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:2}}>{i+1}</div>
                  <div><div style={{fontSize:".77rem",fontWeight:600,color:C.brun,marginBottom:".1rem"}}>{moment}</div><div style={{fontSize:".71rem",color:C.gris,lineHeight:1.5}}>{action}</div></div>
                </div>
              ))}
            </Card>

            <Card title="Les Lives — Guide complet" sub="Différentes idées, comment varier" icon="🎥" color={C.rose}>
              {[
                ["🌟","Live démo produit","Tu montres un produit en live, tu l'appliques sur toi, tu réponds aux questions. Le plus simple et le plus efficace.","Durée : 20-30 min. Annonce 24h avant. Commence même si peu de monde."],
                ["❓","Live FAQ","\"Je réponds à toutes vos questions sur [thème].\" Collect les questions avant en story.","Crée de la confiance et de l'expertise. Les spectatrices reviennent."],
                ["🎯","Live défi en direct","\"Ce soir on fait le défi [teint parfait / cheveux brillants] ensemble.\" Chacune montre son avant.","Engagement maximal. Les participantes deviennent des ambassadrices."],
                ["🛍️","Live vente flash","\"Ce soir seulement, offre spéciale sur [produit].\" Crée l'urgence.","Ne pas en abuser. Réserver aux occasions : nouvelle gamme, fin de période, anniversaire."],
                ["📖","Live storytelling","Tu racontes ton histoire : pourquoi tu as rejoint Mihi, tes galères, tes victoires.","C'est le live le plus puissant pour le recrutement. L'authenticité convertit."],
              ].map(([icon,title,desc,tip])=>(
                <div key={title} style={{background:C.creme,borderRadius:10,padding:".75rem",marginBottom:".6rem",border:`1px solid ${C.pale}`}}>
                  <div style={{display:"flex",gap:".5rem",marginBottom:".3rem"}}><span>{icon}</span><div style={{fontSize:".8rem",fontWeight:600,color:C.brun}}>{title}</div></div>
                  <p style={{fontSize:".73rem",color:C.texte,lineHeight:1.6,marginBottom:".3rem"}}>{desc}</p>
                  <div style={{fontSize:".7rem",color:C.gris,fontStyle:"italic",borderLeft:`2px solid ${C.rose}`,paddingLeft:".5rem"}}>{tip}</div>
                </div>
              ))}
            </Card>
          </div>
        )}

        {/* ── RECRUTEMENT ── */}
        {tab==="recrutement"&&(
          <div>
            <SecTitle title="Recrutement &" em="Affiliation" desc="Stratégies, diagnostique, affiliation — tout pour développer ton équipe."/>
            <AdminContentBlock onglet="recrutement" items={adminItems}/>

            <Card title="Replays Zoom Recrutement" sub="Les sessions formation recrutement" icon="🎥" color={C.rose} defaultOpen>
              <Btn href="https://us06web.zoom.us/rec/share/viyM_OY-wZkKDCyLj-qhIEbIiDv1Yl7j06l9WctzEbvdOS6YPyNJ8RbKKINR5wcO.m5X0v3XgsWBn0ymc" label="Outils de démarrage & recrutement" icon="▶" color={C.brun}/>
              <Btn href="https://us06web.zoom.us/rec/share/hnDWdngAPCK_SGVTYzVhgk70t_nqqfesUvZF7hme8CaEgL-CpszXoantB-d2MSPZ.Yl7wHQ7KV9pZJnCL" label="Communiquer différemment pour passer au niveau supérieur" icon="▶" color={C.brun}/>
              <Btn href="https://us06web.zoom.us/rec/share/Ifld2R1bAsLQ1bJKuj0mr80yNxPt5kPOKAapDNv5jJundkKNIXrdr7de0H0Cn_qR.Yqhq_7quf10A7wtw?startTime=1774984148000" label="Stratégie — Je ne dois pas te le dire mais... 🔥" icon="▶" color={C.brun}/>
            </Card>

            <Card title="Stratégies pour attirer" sub="Comment attirer les bonnes personnes naturellement" icon="🧲" color={C.or}>
              <Info color={C.or}>Attirer c'est mieux que convaincre. Ces stratégies créent un flux entrant de personnes intéressées — sans avoir à courir après.</Info>
              {[
                ["🪝","Le profil qui attire","Ton profil Instagram/Facebook doit répondre à une question en 3 secondes : qui est cette personne et pourquoi je devrais la suivre ? Photo pro + bio qui parle à ta cible + lien Linktree. Sans ça, tout le reste ne sert à rien."],
                ["📖","Le storytelling quotidien","Partage ton histoire — tes galères, tes doutes, tes victoires. Les gens ne s'identifient pas à la perfection. Ils s'identifient à l'authenticité. Une distributrice qui raconte sa transformation attire plus que dix publications produit."],
                ["🔥","Le contenu de preuve","Témoignages clientes, résultats visuels, before/after, messages reçus. La preuve sociale est le moteur n°1 du désir. Partage tout ce qui montre que ça marche — pas en te vantant, mais en partageant."],
                ["🎯","Les hooks qui interpellent","Ta 1ʳᵉ phrase sur chaque publication doit stopper le scroll. \"Je ne cherchais pas un 2ᵉ emploi.\" \"Il y a 6 mois je ne savais pas quoi faire.\" \"Ce que personne ne te dit sur le marketing relationnel.\" La curiosité attire."],
                ["💬","L'interaction stratégique","Commente des publications de ta cible avec de vrais commentaires — pas des emojis. Réponds à toutes les stories. Pose des questions en DM sans pitcher. Crée la relation avant la proposition."],
                ["⚡","Le mot-clé en commentaire","Sur chaque publication opportunité, ferme avec un mot-clé : \"Écris ÉQUIPE en commentaire\". Tu ne réponds qu'aux personnes qui ont montré de l'intérêt. Qualité > quantité."],
              ].map(([icon,title,desc])=>(
                <div key={title} style={{background:C.creme,borderRadius:9,padding:".7rem .85rem",marginBottom:".55rem",border:`1px solid ${C.pale}`}}>
                  <div style={{display:"flex",gap:".5rem",marginBottom:".3rem",alignItems:"flex-start"}}>
                    <span style={{fontSize:"1rem",flexShrink:0}}>{icon}</span>
                    <div style={{fontSize:".8rem",fontWeight:600,color:C.brun}}>{title}</div>
                  </div>
                  <div style={{fontSize:".72rem",color:C.gris,lineHeight:1.6}}>{desc}</div>
                </div>
              ))}
              <div style={{fontSize:".58rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.or,marginBottom:".4rem",marginTop:".5rem"}}>📹 Vidéos diagnostic à envoyer selon le profil</div>
              <DriveBtn href="https://drive.google.com/file/d/1oNIJBA9XKsZjB7idX_xV4oWxgzhHGST9/view" label="👉 Je veux m'affilier — vidéo à envoyer"/>
              <DriveBtn href="https://drive.google.com/file/d/18YRagfzUyTrlarrABNHJouqwUlzC948x/view" label="👉 Vidéo sur l'affiliation"/>
              <DriveBtn href="https://drive.google.com/file/d/1rm5kaTh90zhbd50dYjHxBVi10ud1wqqg/view" label="👉 Je ne veux pas m'affilier — vidéo à envoyer"/>
              <DriveBtn href="https://drive.google.com/file/d/1UvvOQuRetaJymObMLnuxRz6_RzvxOwBT/view" label="👉 Vidéo complémentaire"/>
            </Card>

            <Card title="Stratégies de recrutement" sub="Les méthodes avec documents complets" icon="📁" color={C.lilas}>
              <DriveBtn href="https://drive.google.com/file/d/1dLOGuCg-LkiOX-YUsW_Bce5pr3mwYPVN/view" label="Démarcher — Vidéo"/>
              <DocBtn href="https://docs.google.com/document/d/19GWloCMuOPG8Q_7UQTmTph6AyCMnPWNVTywqRIQPaLY/edit" label="Démarcher — Document complet"/>
              <DriveBtn href="https://drive.google.com/file/d/1WutnDp_no7zU-mmGEgWsiVq7cJ6j7LkA/view" label="Démarcher — Vidéo complémentaire"/>
            </Card>

            <Card title="Récap outils de l'équipe" sub="Tout ce que l'équipe utilise au quotidien" icon="📋" color={C.or}>
              <DocBtn href="https://docs.google.com/document/d/1BU0MH-AcaiWTn1eODBKppavTI8g_77jN833sasmfwU8/edit" label="📋 Récapitulatif complet des outils de l'équipe"/>
              <Info color={C.or}>Ce document contient la liste de tous les outils, liens et ressources utilisés par l'équipe Blazing Dynasty. Garde-le sous la main.</Info>
            </Card>
          </div>
        )}

        {/* ── CONTENU ── */}
        {tab==="contenu"&&(
          <div>
            <SecTitle title="Contenu &" em="Stratégie" desc="Personal branding, storytelling, mixing contenu — et ton tableau d'idées à cocher."/>
            <AdminContentBlock onglet="contenu" items={adminItems}/>

            <Card title="Formations vidéo Contenu" sub="YouTube · Les bases à connaître" icon="▶" color={C.lilas} defaultOpen>
              <YTBtn href="https://youtu.be/76SKVl4lHsw" label="📸 Comment se prendre en photo pour se mettre en valeur"/>
              <YTBtn href="https://youtu.be/j5EUiKmUSgM" label="👤 Le Personal Branding — Construire ton image"/>
              <YTBtn href="https://youtu.be/WxJFBnigjpw" label="🤝 Humaniser son contenu — Pourquoi et comment"/>
              <YTBtn href="https://youtu.be/dgylHebkai4" label="📖 Le Storytelling — Raconter pour vendre"/>
              <YTBtn href="https://youtu.be/JCgNdVywUME" label="📱 Comprendre les réseaux sociaux"/>
              <YTBtn href="https://youtu.be/6g0k-ET_lW8" label="🎯 Définir sa cible — Vente et recrutement"/>
            </Card>

            <Card title="Mixer ses publications" sub="La règle du mix pour ne pas lasser" icon="🔄" color={C.rose}>
              <Info>La règle de base : sur 10 publications, <strong>4 produits · 3 vie perso/storytelling · 2 opportunité · 1 divertissement/interaction</strong>. Ne jamais être mono-thème.</Info>
              {[
                ["💄","Contenu Produit (40%)","Démo, avant/après, routine, astuce d'utilisation, témoignage cliente, résultat concret. Toujours avec un CTA (mot-clé en commentaire, DM, lien)."],
                ["🌸","Storytelling & Vie perso (30%)","Ton histoire, tes doutes, tes victoires, ta famille, tes valeurs. Ce que les gens ne voient pas. L'authenticité crée la confiance."],
                ["🔥","Opportunité (20%)","Partager l'activité de manière détournée : liberté, moments de vie, résultats flous, témoignages d'équipe. Jamais de pitch direct en publication."],
                ["😄","Divertissement & Interaction (10%)","Sondage, quiz, question ouverte, contenu léger et fun. Ce qui fait réagir sans demander d'effort."],
              ].map(([icon,title,desc])=>(
                <div key={title} style={{display:"flex",gap:".6rem",marginBottom:".6rem",alignItems:"flex-start",background:C.creme,borderRadius:9,padding:".65rem"}}>
                  <span style={{fontSize:"1rem",flexShrink:0}}>{icon}</span>
                  <div><div style={{fontSize:".78rem",fontWeight:600,color:C.brun,marginBottom:".1rem"}}>{title}</div><div style={{fontSize:".71rem",color:C.gris,lineHeight:1.55}}>{desc}</div></div>
                </div>
              ))}
            </Card>

            <Card title="Idées de hooks par thème" sub="10 hooks par sujet — pour accrocher dès la 1ʳᵉ ligne" icon="🪝" color={C.or}>
              <Info color={C.or}>Un hook c'est ta 1ʳᵉ phrase — celle qui donne envie de lire la suite. Sans bon hook, même le meilleur contenu ne sera pas lu.</Info>
              {[
                ["💄 Make-up",[
                  "On m'a demandé combien ça m'avait coûté... ils ont pas cru la réponse 😂",
                  "Tu veux le même résultat sans y passer 1h ?",
                  "Le makeup qui tient 12h même avec un masque — oui ça existe.",
                  "3 produits. 5 minutes. Un résultat qui change tout.",
                  "J'ai arrêté le fond de teint hors de prix. Voilà ce que j'utilise maintenant.",
                  "Le mascara dont tout le monde me demande le nom.",
                  "Mes lèvres tiennent toute la journée sans retouche — secret ?",
                  "Je maquille mes clientes depuis X ans. Le produit que je recommande à TOUTES.",
                  "Makeup naturel en moins de 5 min pour les mamans pressées.",
                  "Elle pensait que ça coûtait 80€. En vrai c'est moins de 20€ 😏",
                ]],
                ["🌿 Skincare",[
                  "La vérité sur le skincare hors de prix que personne ne te dit.",
                  "J'ai testé ça pendant 30 jours. Ce que j'ai découvert m'a surprise.",
                  "Peau terne, boutons, imperfections — j'avais tout ça. Voilà ce qui a tout changé.",
                  "Routine visage complète à moins de 25€. Simple, efficace, sans gadget.",
                  "Mon dermato m'a demandé ce que j'utilisais. Il a été étonné.",
                  "Le serum que j'utilise depuis X semaines — mes rides ont l'air de disparaître.",
                  "Non, ce n'est pas un filtre. C'est juste ma routine soin.",
                  "J'ai 47 ans. On me donne 35. Mes 3 produits secrets.",
                  "Tu penses que les bons soins sont forcément chers. Voilà pourquoi tu as tort.",
                  "Peau sèche, déshydratée, qui tire ? J'ai trouvé LA solution à 18€.",
                ]],
                ["💆 Bien-être & Énergie",[
                  "Je me levais fatiguée chaque matin malgré 8h de sommeil. Puis j'ai changé UN truc.",
                  "Non, ce n'est pas du café. Et non, ce n'est pas de l'eau.",
                  "Tu ne devrais pas avoir à souffrir de ton corps chaque jour.",
                  "Mon ventre plat n'est pas dû à une diète. C'est ça mon secret.",
                  "Fatigue chronique, digestion difficile, ventre gonflé — ce que personne ne t'a dit.",
                  "J'ai perdu X kilos sans régime. Voilà ce qui a changé.",
                  "La routine bien-être que j'aurais aimé commencer 10 ans plus tôt.",
                  "3 compléments. Pas 12. Juste 3. Et ça a tout changé.",
                  "Mon énergie avant VS après. La différence est hallucinante.",
                  "Pour celles qui veulent se sentir mieux sans se ruiner ni se priver.",
                ]],
                ["💇 Cheveux",[
                  "Tes cheveux font la tête ? Secs, ternes, cassants — ça s'explique.",
                  "J'ai arrêté de dépenser 80€ chez le coiffeur. Voilà ce que je fais maintenant.",
                  "Ma routine capillaire à 25€ qui donne des cheveux de rêve.",
                  "Ce produit a sauvé mes cheveux après la grossesse.",
                  "Brillance, douceur, volume — sans alourdir. Le secret ?",
                  "On m'a demandé ce que j'utilisais dans les cheveux. Encore et encore.",
                  "Cheveux abîmés par la coloration ? Ce soin a tout réparé.",
                  "Ma coiffeuse voulait savoir ce que j'avais changé. Voilà la réponse.",
                  "Pour celles qui ont abandonné l'idée d'avoir de beaux cheveux.",
                  "En 2 semaines, la différence était visible. Sans aller chez le coiffeur.",
                ]],
                ["🌸 Parfums",[
                  "Petit jeu : devinez le prix de mon parfum. Réponse en commentaire 😏",
                  "On me fait des compliments sur mon parfum depuis 3 semaines. Il coûte 18€.",
                  "J'ai arrêté de me ruiner en parfum. Voilà pourquoi.",
                  "Mon parfum du quotidien à moins de 20€ — et il tient toute la journée.",
                  "\"C'est quoi ton parfum ?\" La question qu'on m'a posée encore aujourd'hui.",
                  "Qualité grande marque, prix accessible. Ça existe pour les parfums aussi.",
                  "J'utilise ça depuis X mois et je ne retournerai jamais en arrière.",
                  "Pour les amoureux des beaux parfums avec un petit budget.",
                  "Ils ont cru que ça coûtait au moins 80€. Plot twist ❌",
                  "Le parfum dont je suis accro depuis que je l'ai découvert.",
                ]],
                ["💰 Opportunité & Liberté",[
                  "Je ne cherchais pas un 2ème emploi. Je cherchais quelque chose qui s'adapte à ma vie.",
                  "Mardi 15h. Je récupère mon enfant à l'école. Pas de congés posés.",
                  "Il y a 6 mois je ne savais pas quoi faire. Aujourd'hui voilà où j'en suis.",
                  "On m'a demandé si c'était une arnaque. Voilà ma réponse honnête.",
                  "Ce que j'aurais aimé que quelqu'un me dise avant de commencer.",
                  "Je ne vends pas du rêve. Je partage ce qui marche vraiment pour moi.",
                  "La liberté financière ce n'est pas pour les autres. C'est pour toi aussi.",
                  "Ce mois-ci j'ai gagné [montant] en travaillant depuis mon canapé.",
                  "5 femmes dans mon équipe ont changé de vie cette année. Comment ?",
                  "La vraie question ce n'est pas \"est-ce que ça marche ?\" C'est \"est-ce que tu vas essayer ?\"",
                ]],
                ["🔑 Recrutement détourné",[
                  "Tu cherches un complément de revenu sans sacrifier ta famille ?",
                  "3 choses que j'aurais voulu savoir avant de commencer.",
                  "Ce que personne ne montre vraiment sur les réseaux dans ce business.",
                  "J'ai refusé 3 fois avant d'accepter. Voilà pourquoi j'ai eu tort.",
                  "Le business qu'on m'a présenté et que j'ai failli ignorer.",
                  "Pour les mamans qui veulent travailler sans tout sacrifier.",
                  "Travailler de chez soi c'est possible. Pas facile. Mais possible.",
                  "Mon équipe cherche 3 femmes sérieuses. Pas des milliers. Juste 3.",
                  "Ce n'est pas pour tout le monde. Mais peut-être que c'est pour toi.",
                  "Avant de juger, lis jusqu'au bout. Tu pourrais être surpris(e).",
                ]],
              ].map(([theme,hooks])=>(
                <div key={theme} style={{marginBottom:".85rem"}}>
                  <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".08em",textTransform:"uppercase",padding:".22rem .6rem",background:C.or+"20",color:C.brun2,borderRadius:20,display:"inline-block",marginBottom:".5rem"}}>{theme}</div>
                  {hooks.map((hook,i)=>(
                    <div key={i} style={{display:"flex",gap:".5rem",background:C.creme,borderRadius:8,padding:".45rem .65rem",marginBottom:".28rem",alignItems:"flex-start"}}>
                      <span style={{fontSize:".65rem",color:C.gris,flexShrink:0,marginTop:".1rem"}}>🪝</span>
                      <div style={{fontSize:".73rem",color:C.texte,lineHeight:1.5,flex:1,fontStyle:"italic"}}>{hook}</div>
                      <CopyBtn text={hook}/>
                    </div>
                  ))}
                </div>
              ))}
            </Card>

            <Card title="Tableau d'idées de posts à cocher" sub={`${donePosts}/${allPosts.length} posts utilisés`} icon="📋" color={C.rose}>
              <Info>Coche les posts que tu as déjà utilisés pour suivre ta diversité de contenu. Adapte toujours à ta voix et à ton vécu.</Info>
              <div style={{marginBottom:".35rem",display:"flex",gap:".5rem",flexWrap:"wrap"}}>
                <span style={{fontSize:".62rem",color:C.gris}}>{donePosts} utilisés · {allPosts.length-donePosts} restants</span>
              </div>
              {POST_IDEAS.map(theme=>(
                <div key={theme.theme} style={{marginBottom:"1rem"}}>
                  <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",padding:".25rem .6rem",background:theme.color+"20",color:theme.color===C.or?C.brun2:theme.color,borderRadius:20,display:"inline-block",marginBottom:".5rem"}}>{theme.theme}</div>
                  {theme.posts.map(post=>(
                    <div key={post.id} style={{background:posts[post.id]?C.pale+"80":C.creme,borderRadius:9,padding:".65rem .8rem",marginBottom:".35rem",border:`1px solid ${posts[post.id]?C.rose:C.pale}`,transition:"all .2s"}}>
                      <div style={{display:"flex",gap:".55rem",alignItems:"flex-start",marginBottom:posts[post.id]?0:".35rem"}}>
                        <div onClick={()=>tog("posts",post.id)} style={{width:18,height:18,borderRadius:4,border:`2px solid ${posts[post.id]?C.rose:C.pale}`,background:posts[post.id]?C.rose:"transparent",flexShrink:0,marginTop:2,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",transition:"all .15s"}}>
                          {posts[post.id]&&<span style={{fontSize:".55rem",color:"white",fontWeight:700}}>✓</span>}
                        </div>
                        <div style={{fontSize:".76rem",fontWeight:600,color:posts[post.id]?C.gris:C.brun,textDecoration:posts[post.id]?"line-through":"none",flex:1}}>{post.hook}</div>
                        <CopyBtn text={post.hook+"\n\n"+post.caption}/>
                      </div>
                      {!posts[post.id]&&<div style={{fontSize:".71rem",color:C.gris,lineHeight:1.55,marginLeft:"1.45rem"}}>{post.caption}</div>}
                    </div>
                  ))}
                </div>
              ))}
            </Card>

            <Card title="Ressources supplémentaires" sub="Documents stratégie contenu" icon="📄" color={C.lilas}>
              <DocBtn href="https://docs.google.com/document/d/19-pcqclkBvCHcAt6ONAGk_U8uDMmW0xg2UhOnO-l-fY/edit" label="Idées de publications — Document complet"/>
              <DocBtn href="https://docs.google.com/document/d/12tkS-4d0iLgZkpcnIgBZ0K4hIIXWgclC3IwnjkuyJ3s/edit" label="Stratégie contenu avancée"/>
              <YTBtn href="https://youtu.be/1m37A50VRN8" label="Formation Produit — Gestion perte de poids"/>
              <YTBtn href="https://youtu.be/r0MFA4bj1SY" label="Formation Produit — Ginkgo Biloba"/>
            </Card>
          </div>
        )}

        {/* ── OUTILS ── */}
        {tab==="devperso"&&(
          <div>
            <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
              Développement <em style={{fontStyle:"italic",color:C.rose}}>Personnel</em>
            </div>
            <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
              Mindset, leadership, objectifs — travaille sur toi pour franchir tes propres limites.
            </p>

            <div style={{background:"linear-gradient(135deg,rgba(196,154,138,.12),rgba(168,155,181,.08))",border:`1px solid ${C.pale}`,borderRadius:10,padding:".75rem 1rem",marginBottom:"1rem",fontSize:".76rem",color:C.texte,lineHeight:1.65}}>
              💡 <strong>6 formations disponibles.</strong> D'autres modules seront ajoutés progressivement par Melissa.
            </div>

            {[
              {icon:"🧠",title:"Dégommer son plafond de verre",desc:"Identifier les croyances limitantes qui t'empêchent d'avancer et les transformer en force.",video:"https://us06web.zoom.us/rec/share/XzuZHzXLLZdVOz2rQmBb-7nomO9qxTj92_xluvzizpzlSaYfxRdmTARqoDTdatzs.EHObmbNT1mpbo0Ad",tag:"dispo"},
              {icon:"🎯",title:"Fixer ses objectifs — méthode complète",desc:"Des objectifs qui fonctionnent vraiment. La méthode pour les poser et les tenir dans le temps.",video:"https://us06web.zoom.us/rec/share/E1JtWx4furUdNFt4wKKCJYcfD4ScYwhJZ3BfUnHZYOnbUzcRYLzdLq5WuoyJSjw.MsevJMjQXIrzr1rp?startTime=1771357741000",tag:"dispo"},
              {icon:"👑",title:"Développer son leadership",desc:"Comment inspirer, guider et faire grandir son équipe. La posture du leader que les autres veulent suivre.",video:"https://us06web.zoom.us/rec/share/hnDWdngAPCK_SGVTYzVhgk70t_nqqfesUvZF7hme8CaEgL-CpszXoantB-d2MSPZ.Yl7wHQ7KV9pZJnCL",tag:"dispo"},
              {icon:"📱",title:"Personal branding — Construire son image",desc:"Qui tu es en ligne = qui tu attires. Comment construire une image authentique et cohérente.",video:"https://youtu.be/j5EUiKmUSgM",tag:"dispo"},
              {icon:"🤝",title:"Humaniser son contenu",desc:"Pourquoi les gens achètent à des personnes, pas à des marques. Comment montrer ta vraie personnalité.",video:"https://youtu.be/WxJFBnigjpw",tag:"dispo"},
              {icon:"📖",title:"Le storytelling",desc:"Raconter pour vendre, pour convaincre, pour recruter. La puissance de l'histoire vraie.",video:"https://youtu.be/dgylHebkai4",tag:"dispo"},
            ].map(item=>(
              <div key={item.title} style={{background:C.blanc,border:`1px solid ${item.tag==="dispo"?C.pale:C.pale}`,borderRadius:12,padding:".85rem 1rem",marginBottom:".6rem",opacity:item.tag==="soon"?.65:1}}>
                <div style={{display:"flex",gap:".6rem",alignItems:"flex-start",marginBottom:item.video?".6rem":0}}>
                  <span style={{fontSize:"1.1rem",flexShrink:0}}>{item.icon}</span>
                  <div style={{flex:1}}>
                    <div style={{display:"flex",gap:".5rem",alignItems:"center",marginBottom:".15rem"}}>
                      <div style={{fontFamily:"Georgia,serif",fontSize:".9rem",fontWeight:600,color:C.brun}}>{item.title}</div>
                      <span style={{background:item.tag==="dispo"?C.vert+"25":C.pale,color:item.tag==="dispo"?C.vert:C.gris,fontSize:".52rem",fontWeight:700,letterSpacing:".08em",textTransform:"uppercase",padding:".12rem .4rem",borderRadius:20,flexShrink:0}}>
                        {item.tag==="dispo"?"Disponible":"Bientôt"}
                      </span>
                    </div>
                    <div style={{fontSize:".72rem",color:C.gris,lineHeight:1.55}}>{item.desc}</div>
                  </div>
                </div>
                {item.video&&<YTBtn href={item.video} label="▶ Voir la formation"/>}
              </div>
            ))}
          </div>
        )}

        {tab==="outils"&&(
          <div>
            <SecTitle title="Outils" em="indispensables" desc="Les bases de Canva, CapCut et Linktree — ce qu'il faut savoir et pas plus."/>

            <Card title="Canva — Créer ses visuels" sub="Les bases pour des posts professionnels" icon="🎨" color={C.rose} defaultOpen>
              <Info>Canva c'est l'outil n°1 pour créer tes visuels sans être graphiste. Gratuit, sur mobile et desktop.</Info>
              <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".45rem"}}>Les 5 choses à maîtriser</div>
              {[
                ["1","Les formats","Story = 1080x1920px · Post carré = 1080x1080px · Reel = 1080x1920px. Toujours commencer par choisir le bon format."],
                ["2","Les templates","Cherche \"Instagram story beauté\" ou \"post cosmétique\" dans la barre de recherche. Choisis un template, adapte les couleurs à ton branding (brun + rose + or pour Blazing Dynasty)."],
                ["3","Cohérence visuelle","Utilise toujours les mêmes 3 couleurs, les mêmes 2 polices, le même style de photos. Ton profil doit être reconnaissable au 1ᵉʳ coup d'œil."],
                ["4","Les éléments graphiques","Stickers, formes, lignes — utilise-les avec parcimonie. Moins c'est souvent plus. Un visuel épuré convertit mieux qu'un visuel surchargé."],
                ["5","Exporter et partager","Télécharge en PNG pour les images, MP4 pour les vidéos animées. Active \"Partager le lien\" pour collaborer avec ton équipe."],
              ].map(([n,title,desc])=>(
                <div key={n} style={{display:"flex",gap:".55rem",marginBottom:".55rem",alignItems:"flex-start"}}>
                  <div style={{width:22,height:22,borderRadius:"50%",background:C.rose,color:"white",fontSize:".62rem",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:1}}>{n}</div>
                  <div><div style={{fontSize:".77rem",fontWeight:600,color:C.brun,marginBottom:".1rem"}}>{title}</div><div style={{fontSize:".71rem",color:C.gris,lineHeight:1.5}}>{desc}</div></div>
                </div>
              ))}
              <Btn href="https://www.canva.com" label="Ouvrir Canva" color={C.rose} icon="🎨"/>
            </Card>

            <Card title="CapCut — Monter ses vidéos" sub="Les bases pour des Reels et stories vidéo" icon="🎬" color={C.lilas}>
              <Info color={C.lilas}>CapCut c'est l'appli de montage vidéo la plus simple et la plus puissante pour créer des Reels. Gratuite sur mobile.</Info>
              {[
                ["1","Importer et couper","Importe ta vidéo, utilise l'outil \"Séparer\" pour couper les silences et les parties ratées. Garde les moments naturels — l'authenticité convertit."],
                ["2","Les sous-titres automatiques","Outils → Auto-sous-titres. CapCut génère automatiquement les sous-titres. Édite les erreurs. 85% des vidéos sont regardées sans le son."],
                ["3","La musique et les tendances","Bibliothèque → Sons tendances. Utilise une musique tendance pour augmenter ta portée. Vérifie qu'elle est autorisée pour Instagram/TikTok."],
                ["4","Les templates","Onglet \"Templates\" → cherche un format de Reel tendance. Tu remplaces juste les vidéos — le montage est déjà fait."],
                ["5","Exporter","Toujours exporter en 1080p. Désactive le filigrane CapCut si possible (ça nuit à la portée sur Instagram)."],
              ].map(([n,title,desc])=>(
                <div key={n} style={{display:"flex",gap:".55rem",marginBottom:".55rem",alignItems:"flex-start"}}>
                  <div style={{width:22,height:22,borderRadius:"50%",background:C.lilas,color:"white",fontSize:".62rem",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:1}}>{n}</div>
                  <div><div style={{fontSize:".77rem",fontWeight:600,color:C.brun,marginBottom:".1rem"}}>{title}</div><div style={{fontSize:".71rem",color:C.gris,lineHeight:1.5}}>{desc}</div></div>
                </div>
              ))}
            </Card>

            <Card title="Linktree — Ton lien unique" sub="Un seul lien, toutes tes ressources" icon="🔗" color={C.or}>
              <Info color={C.or}>Linktree c'est la page qui réunit tous tes liens importants. Tu mets UN seul lien dans ta bio Instagram, et les gens y trouvent tout.</Info>
              {[
                ["1","Créer ton compte","Va sur linktree.com, inscris-toi gratuitement avec ton adresse email."],
                ["2","Ajouter tes liens","Clique \"+Ajouter lien\" pour chaque ressource : ta boutique Mihi, ton groupe Facebook, ton Telegram, ton WhatsApp, ton profil Instagram."],
                ["3","Les liens essentiels à mettre","Ma boutique Mihi · Rejoindre mon équipe · Me contacter sur WhatsApp · Mon Instagram · Mon groupe clientes."],
                ["4","Personnaliser l'apparence","Choisis un fond sombre (cohérent avec tes couleurs Blazing Dynasty). Mets ta photo de profil. Ajoute ton nom et une courte description."],
                ["5","Mettre à jour ta bio","Copie ton lien Linktree (ex: linktr.ee/tonprenom). Colle-le dans ta bio Instagram, Facebook et TikTok. Un seul lien pour tout."],
              ].map(([n,title,desc])=>(
                <div key={n} style={{display:"flex",gap:".55rem",marginBottom:".55rem",alignItems:"flex-start"}}>
                  <div style={{width:22,height:22,borderRadius:"50%",background:C.or,color:C.brun,fontSize:".62rem",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:1}}>{n}</div>
                  <div><div style={{fontSize:".77rem",fontWeight:600,color:C.brun,marginBottom:".1rem"}}>{title}</div><div style={{fontSize:".71rem",color:C.gris,lineHeight:1.5}}>{desc}</div></div>
                </div>
              ))}
              <Btn href="https://linktr.ee" label="Créer mon Linktree" color={C.or} icon="🔗"/>
            </Card>

            <Card title="Récap outils de l'équipe" sub="Document officiel Blazing Dynasty" icon="📋" color={C.brun}>
              <DocBtn href="https://docs.google.com/document/d/1BU0MH-AcaiWTn1eODBKppavTI8g_77jN833sasmfwU8/edit" label="📋 Récapitulatif complet des outils de l'équipe"/>
            </Card>
          </div>
        )}

        {/* ── FORMATION PRODUITS ── */}
        {tab==="formaproduits"&&(
          <div>
            <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
              Formation <em style={{fontStyle:"italic",color:C.rose}}>Produits</em>
            </div>
            <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
              Tout savoir sur les produits Mihi pour mieux les vendre et les recommander.
            </p>
            <div style={{background:C.brun,borderRadius:14,padding:"1.4rem",marginBottom:"1rem",textAlign:"center"}}>
              <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".2em",color:C.or,marginBottom:".5rem"}}>✦ EN CONSTRUCTION ✦</div>
              <div style={{fontFamily:"Georgia,serif",fontSize:"1.1rem",color:C.blanc,fontWeight:300,lineHeight:1.4,marginBottom:".5rem"}}>
                Les formations produits<br/><em style={{fontStyle:"italic",color:C.pale}}>arrivent bientôt</em>
              </div>
              <p style={{fontSize:".74rem",color:C.pale,opacity:.85,lineHeight:1.65,maxWidth:320,margin:"0 auto"}}>
                Skincare · Soins cheveux · Make-up · Compléments · Parfums · Soin corps.<br/>
                Melissa ajoutera les formations produit par produit.
              </p>
            </div>
            {[
              {icon:"✨",title:"Skincare — Face Architect",tag:"soon"},
              {icon:"💇",title:"Soins cheveux — Hair Architect",tag:"soon"},
              {icon:"💄",title:"Make-up",tag:"soon"},
              {icon:"💊",title:"Compléments alimentaires & Perte de poids",video:"https://youtu.be/1m37A50VRN8",tag:"dispo"},
              {icon:"🌿",title:"Ginkgo Biloba",video:"https://youtu.be/r0MFA4bj1SY",tag:"dispo"},
              {icon:"🌸",title:"Parfums",tag:"soon"},
              {icon:"🧴",title:"Soin corps",tag:"soon"},
            ].map(item=>(
              <div key={item.title} style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:".85rem 1rem",marginBottom:".6rem",opacity:item.tag==="soon"?.65:1}}>
                <div style={{display:"flex",gap:".6rem",alignItems:"flex-start",marginBottom:item.video?".5rem":0}}>
                  <span style={{fontSize:"1.1rem",flexShrink:0}}>{item.icon}</span>
                  <div style={{flex:1}}>
                    <div style={{display:"flex",gap:".5rem",alignItems:"center"}}>
                      <div style={{fontFamily:"Georgia,serif",fontSize:".9rem",fontWeight:600,color:C.brun}}>{item.title}</div>
                      <span style={{background:item.tag==="dispo"?C.vert+"25":C.pale,color:item.tag==="dispo"?C.vert:C.gris,fontSize:".52rem",fontWeight:700,letterSpacing:".08em",textTransform:"uppercase",padding:".12rem .4rem",borderRadius:20,flexShrink:0}}>
                        {item.tag==="dispo"?"Disponible":"Bientôt"}
                      </span>
                    </div>
                  </div>
                </div>
                {item.video&&<YTBtn href={item.video} label="▶ Voir la formation"/>}
              </div>
            ))}
            <AdminContentBlock onglet="formaproduits" items={adminItems}/>
          </div>
        )}

        {/* ── SPRINT / ACCÉLÈRE ── */}
        {tab==="sprint"&&(
          <div>
            <SecTitle title="Prends" em="de la vitesse" desc="7 actions quotidiennes pour passer à l'action. Chaque jour compte — coche et avance."/>
            <div style={{background:C.brun,borderRadius:10,padding:".7rem 1rem",marginBottom:"1rem",fontSize:".74rem",color:C.pale,lineHeight:1.6}}>
              🚀 Chaque conversation déclenchée est une graine. Les graines d'aujourd'hui = les recrues de demain.
            </div>
            <div style={{marginBottom:"1rem"}}>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:".62rem",color:C.gris,marginBottom:".22rem"}}>
                <span>Progression sprint</span><span>{SPRINT.flatMap(d=>d.tasks).filter(t=>tasks[t.id]).length}/{allTask.length}</span>
              </div>
              <div style={{height:4,background:C.pale,borderRadius:10,overflow:"hidden"}}>
                <div style={{height:"100%",background:C.rose,width:(allTask.length?Math.round(SPRINT.flatMap(d=>d.tasks).filter(t=>tasks[t.id]).length/allTask.length*100):0)+"%",borderRadius:10,transition:"width .3s"}}/>
              </div>
            </div>
            {SPRINT.map(day=>{
              const isOpen=openDays[day.day];
              const dayDone=day.tasks.filter(t=>tasks[t.id]).length;
              const dayPct=Math.round(dayDone/day.tasks.length*100);
              const allDone=dayPct===100;
              const fc={rs:C.lilas,bao:C.or,mix:C.rose}[day.focus];
              const fl={rs:"Réseaux",bao:"Terrain",mix:"Mixte"}[day.focus];
              return(
                <div key={day.day} style={{background:C.blanc,border:`1px solid ${isOpen?C.rose:C.pale}`,borderRadius:14,marginBottom:".75rem",overflow:"hidden",transition:"all .2s"}}>
                  <div onClick={()=>setOpenDays(p=>({...p,[day.day]:!p[day.day]}))}
                    style={{padding:".82rem 1rem",display:"flex",alignItems:"center",gap:".6rem",cursor:"pointer",userSelect:"none"}}>
                    <div style={{width:34,height:34,borderRadius:"50%",background:allDone?C.vert:C.brun,color:allDone?"white":C.or,fontFamily:"Georgia,serif",fontSize:"1rem",fontWeight:600,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                      {allDone?"✓":day.day}
                    </div>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontFamily:"Georgia,serif",fontSize:".92rem",fontWeight:600,color:C.brun}}>{day.title}</div>
                      <div style={{fontSize:".6rem",color:C.gris}}>{day.goal}</div>
                    </div>
                    <span style={{background:fc+"22",color:fc===C.or?C.brun2:fc,fontSize:".55rem",fontWeight:700,textTransform:"uppercase",padding:".15rem .45rem",borderRadius:20,flexShrink:0}}>{fl}</span>
                    <div style={{color:C.rose,fontSize:".68rem",transform:isOpen?"rotate(180deg)":"none",transition:"transform .2s",flexShrink:0}}>▼</div>
                  </div>
                  {isOpen&&(
                    <div style={{borderTop:`1px solid ${C.pale}`}}>
                      <div style={{padding:".5rem 1rem .3rem"}}>
                        <div style={{display:"flex",justifyContent:"space-between",fontSize:".6rem",color:C.gris,marginBottom:".22rem"}}>
                          <span>{dayDone}/{day.tasks.length}</span><span>{dayPct}%</span>
                        </div>
                        <div style={{height:4,background:C.pale,borderRadius:10,overflow:"hidden"}}>
                          <div style={{height:"100%",background:C.rose,width:dayPct+"%",transition:"width .3s",borderRadius:10}}/>
                        </div>
                      </div>
                      <div style={{padding:".5rem 1rem .85rem"}}>
                        {day.tasks.map(task=>(
                          <div key={task.id}>
                            <div onClick={()=>tog("tasks",task.id)} style={{display:"flex",alignItems:"flex-start",gap:".55rem",padding:".45rem 0",borderBottom:`1px solid rgba(232,213,204,.3)`,cursor:"pointer"}}>
                              <div style={{width:18,height:18,borderRadius:4,border:`2px solid ${C.rose}`,background:tasks[task.id]?C.rose:"transparent",flexShrink:0,marginTop:2,display:"flex",alignItems:"center",justifyContent:"center",transition:"all .15s"}}>
                                {tasks[task.id]&&<span style={{fontSize:".55rem",color:"white",fontWeight:700}}>✓</span>}
                              </div>
                              <div style={{fontSize:".76rem",color:tasks[task.id]?C.gris:C.texte,textDecoration:tasks[task.id]?"line-through":"none",lineHeight:1.45,flex:1}}>{task.label}</div>
                            </div>
                            {task.script&&(
                              <div style={{background:C.creme,borderLeft:`3px solid ${C.lilas}`,borderRadius:"0 8px 8px 0",padding:".5rem .75rem",fontSize:".72rem",fontStyle:"italic",color:C.texte,lineHeight:1.7,margin:".3rem 0 .4rem",display:"flex",gap:".5rem",alignItems:"flex-start"}}>
                                <span style={{flex:1}}>{task.script}</span>
                                <CopyBtn text={task.script}/>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
            <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:14,padding:"1.1rem"}}>
              <div style={{fontFamily:"Georgia,serif",fontSize:"1rem",fontWeight:600,color:C.brun,marginBottom:".75rem"}}>📊 Mes chiffres</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".5rem",marginBottom:".75rem"}}>
                {[["k1","Messages envoyés"],["k2","Réponses reçues"],["k3","Présentations"],["k4","Nouvelles recrues"]].map(([k,l])=>(
                  <div key={k} style={{background:C.creme,border:`1px solid ${C.pale}`,borderRadius:10,padding:".6rem",textAlign:"center"}}>
                    <input type="number" min="0" value={kpis[k]||""} placeholder="0" onChange={e=>updKpi(k,e.target.value)}
                      style={{width:52,fontFamily:"Georgia,serif",fontSize:"1.6rem",fontWeight:600,color:C.brun,border:"none",background:"none",textAlign:"center",outline:"none"}}/>
                    <div style={{fontSize:".58rem",color:C.gris,marginTop:".12rem"}}>{l}</div>
                  </div>
                ))}
              </div>
              <textarea value={notes} onChange={e=>updNotes(e.target.value)} placeholder="Notes, blocages, questions..."
                style={{width:"100%",minHeight:80,border:`1px solid ${C.pale}`,borderRadius:8,padding:".6rem",fontFamily:"inherit",fontSize:".76rem",color:C.texte,background:C.creme,resize:"vertical",outline:"none",lineHeight:1.6}}/>
            </div>
          </div>
        )}

        {/* ── SUIVI RECRUES ── */}
        {tab==="suivi"&&<SuiviRecruTab uid={userId}/>}

        {/* ── TABLEAU DE BORD ── */}
        {tab==="dashboard"&&<DashboardTab uid={userId}/>}
        {tab==="communaute"&&<CommunauteTab uid={userId} userName={name}/>}
        {tab==="scripts"&&<ScriptsTab/>}
        {tab==="objectifs"&&<ObjectifsTab uid={userId} userName={name} isMelissa={name.toLowerCase().startsWith("melissa")}/>}
        {tab==="calendrier"&&<CalendrierTab uid={userId} userName={name} isMelissa={name.toLowerCase().startsWith("melissa")}/>}
        {tab==="admin"&&userId==="melissa"||userId==="melissa-da-silveira"&&<AdminTab/>}

      </div>

      {/* WATERMARK invisible — prénom de la personne connectée */}
      <div style={{position:"fixed",top:0,left:0,width:"100%",height:"100%",pointerEvents:"none",zIndex:9999,overflow:"hidden",opacity:.03}}>
        {Array.from({length:20}).map((_,i)=>(
          <div key={i} style={{position:"absolute",top:`${(i*11)%100}%`,left:`${(i*17)%100}%`,fontSize:"1.2rem",fontWeight:700,color:C.brun,transform:"rotate(-30deg)",whiteSpace:"nowrap",letterSpacing:".15em"}}>
            {name.toUpperCase()} · BLAZING DYNASTY
          </div>
        ))}
      </div>

      <div style={{textAlign:"center",padding:"1.1rem",fontSize:".6rem",color:C.gris,borderTop:`1px solid ${C.pale}`}}>
        <strong style={{color:C.rose}}>Blazing Dynasty</strong> · Espace Formation Privé
      </div>

      {/* ── BOUTON FLOTTANT OBJECTIFS ── */}
      <button onClick={()=>setShowObjectifs(p=>!p)}
        style={{position:"fixed",bottom:"5rem",right:"1.2rem",width:56,height:56,borderRadius:"50%",background:C.brun,border:`2px solid ${C.or}`,boxShadow:"0 4px 20px rgba(61,31,14,.4)",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,transition:"all .2s",padding:0,overflow:"hidden"}}>
        {showObjectifs
          ? <span style={{fontSize:"1rem",color:C.or,fontWeight:700}}>✕</span>
          : <span style={{fontSize:"1.4rem"}}>👑</span>
        }
      </button>

      {/* ── POPUP OBJECTIFS ── */}
      {showObjectifs&&(
        <div style={{position:"fixed",bottom:"8rem",right:"1.2rem",width:285,background:C.blanc,borderRadius:16,boxShadow:"0 8px 32px rgba(61,31,14,.25)",border:`1px solid ${C.pale}`,zIndex:199,overflow:"hidden"}}>
          <div style={{background:C.brun,padding:".85rem 1rem",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div style={{display:"flex",gap:".6rem",alignItems:"center"}}>
              <span style={{fontSize:"1.4rem"}}>👑</span>
              <div>
                <div style={{fontSize:".55rem",fontWeight:700,letterSpacing:".15em",color:C.or}}>✦ OBJECTIFS ÉQUIPE</div>
                <div style={{fontFamily:"Georgia,serif",fontSize:".9rem",color:C.blanc,fontWeight:300}}>Ce mois-ci</div>
              </div>
            </div>
          </div>
          <ObjectifsPopup uid={userId}/>
        </div>
      )}
    </div>
  );
}

// ── SUIVI RECRUES COMPONENT ───────────────────────────────────────────────────
const CHECKLIST_BLOCKS=[
  {day:"J+1",color:"#B04040",title:"Accueil immédiat",tasks:[
    {id:"c1",label:"Message de bienvenue vocal ou vidéo envoyé"},
    {id:"c2",label:"Accès Formation Démarrage Rapide transmis"},
    {id:"c3",label:"Date du call de suivi fixée"},
    {id:"c4",label:"Exercices expliqués (liste 20 / profil / story)"},
  ]},
  {day:"J+2",color:"#8B5E00",title:"Formation & exercices",tasks:[
    {id:"c5",label:"Formation terminée — vérifier avec elle"},
    {id:"c6",label:"Liste des 20 contacts réalisée"},
    {id:"c7",label:"Profil optimisé (photo + bio + lien)"},
    {id:"c8",label:"Première story publiée"},
    {id:"c9",label:"Call démarrage 30 min réalisé"},
  ]},
  {day:"J+3",color:"#4A4A9C",title:"Intégration équipe",tasks:[
    {id:"c10",label:"Ajoutée au groupe Facebook Blazing Dynasty"},
    {id:"c11",label:"Ajoutée au canal Telegram"},
    {id:"c12",label:"Accès site de formation transmis"},
    {id:"c13",label:"Présentée à la communauté"},
    {id:"c14",label:"Premier contact prospect approché"},
  ]},
  {day:"S1",color:"#5C8A60",title:"Semaine 1 — Premiers résultats",tasks:[
    {id:"c15",label:"1 story par jour (vie quotidienne)"},
    {id:"c16",label:"5+ personnes contactées en message personnel"},
    {id:"c17",label:"1 présentation de l'opportunité faite"},
    {id:"c18",label:"Première vente OU premier recrutement ✨"},
    {id:"c19",label:"Point de suivi hebdomadaire effectué"},
  ]},
  {day:"S2-4",color:"#6B5B8A",title:"Semaines 2-4 — Routine & croissance",tasks:[
    {id:"c20",label:"Contenu régulier publié (3x/semaine minimum)"},
    {id:"c21",label:"Sprint 7j complété dans l'appli"},
    {id:"c22",label:"Premier café ou Zoom découverte organisé"},
    {id:"c23",label:"2ᵉ vente ou 1ʳᵉ recrue dans son équipe"},
    {id:"c24",label:"Formation produits avancée suivie"},
    {id:"c25",label:"Bilan du mois réalisé avec distributrice"},
  ]},
];

const ALL_TASK_IDS=CHECKLIST_BLOCKS.flatMap(b=>b.tasks.map(t=>t.id));
const MAX_RECRUES=15;

function getProgress(r){
  const done=ALL_TASK_IDS.filter(id=>r.checks&&r.checks[id]).length;
  return{done,total:ALL_TASK_IDS.length,pct:Math.round(done/ALL_TASK_IDS.length*100)};
}

function phaseLabel(pct){
  if(pct===0)return{label:"Pas encore démarrée",col:C.gris};
  if(pct<30)return{label:"Démarrage J+1/J+2",col:"#B04040"};
  if(pct<60)return{label:"Intégration en cours",col:"#8B5E00"};
  if(pct<85)return{label:"Semaine 1 active",col:C.rose};
  if(pct<100)return{label:"En pleine progression",col:C.lilas};
  return{label:"Parcours complété 🎉",col:C.vert};
}

function RecrueFiche({recrue,onToggle,onRemove}){
  const[openBlocks,setOpenBlocks]=useState({"J+1":true});
  const[confirmDel,setConfirmDel]=useState(false);
  const{done,total,pct}=getProgress(recrue);
  const ph=phaseLabel(pct);

  return(
    <div>
      {/* Header */}
      <div style={{background:C.brun,borderRadius:14,padding:"1rem 1.1rem",marginBottom:"1rem",display:"flex",alignItems:"center",gap:".85rem"}}>
        <div style={{width:42,height:42,borderRadius:"50%",background:C.rose,color:"white",fontFamily:"Georgia,serif",fontSize:"1.1rem",fontWeight:600,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
          {recrue.name[0].toUpperCase()}
        </div>
        <div style={{flex:1}}>
          <div style={{fontFamily:"Georgia,serif",fontSize:"1rem",fontWeight:600,color:C.blanc}}>{recrue.name}</div>
          <div style={{fontSize:".62rem",color:C.pale,opacity:.75}}>Entrée le {recrue.date}</div>
          <div style={{fontSize:".65rem",fontWeight:700,color:ph.col,marginTop:".15rem"}}>{ph.label}</div>
        </div>
        <div style={{textAlign:"right",marginRight:".4rem"}}>
          <div style={{fontFamily:"Georgia,serif",fontSize:"1.4rem",fontWeight:600,color:pct===100?C.vert:C.or,lineHeight:1}}>{pct}%</div>
          <div style={{fontSize:".58rem",color:C.pale,opacity:.7}}>{done}/{total}</div>
        </div>
        {!confirmDel
          ? <button onClick={()=>setConfirmDel(true)} style={{background:"rgba(255,255,255,.1)",border:"none",borderRadius:6,padding:".3rem .5rem",color:C.pale,cursor:"pointer",fontSize:".7rem",fontFamily:"inherit",flexShrink:0}}>✕</button>
          : <div style={{display:"flex",gap:".3rem",flexShrink:0}}>
              <button onClick={()=>onRemove(recrue.id)} style={{background:"#B04040",border:"none",borderRadius:6,padding:".3rem .55rem",color:"white",cursor:"pointer",fontSize:".65rem",fontFamily:"inherit"}}>Supprimer</button>
              <button onClick={()=>setConfirmDel(false)} style={{background:"rgba(255,255,255,.15)",border:"none",borderRadius:6,padding:".3rem .55rem",color:C.pale,cursor:"pointer",fontSize:".65rem",fontFamily:"inherit"}}>Annuler</button>
            </div>
        }
      </div>

      {/* Barre globale */}
      <div style={{marginBottom:"1rem"}}>
        <div style={{height:6,background:C.pale,borderRadius:10,overflow:"hidden"}}>
          <div style={{height:"100%",background:pct===100?C.vert:C.rose,width:pct+"%",borderRadius:10,transition:"width .4s"}}/>
        </div>
      </div>

      <div style={{background:"linear-gradient(135deg,rgba(196,154,138,.1),rgba(168,155,181,.07))",border:`1px solid ${C.pale}`,borderRadius:10,padding:".75rem 1rem",marginBottom:"1rem",fontSize:".74rem",color:C.texte,lineHeight:1.65}}>
        🏆 Objectif : 1 première vente ou 1 premier recrutement dans les 7 premiers jours.
      </div>

      {/* Blocs checklist */}
      {CHECKLIST_BLOCKS.map(block=>{
        const isOpen=openBlocks[block.day];
        const blockDone=block.tasks.filter(t=>recrue.checks&&recrue.checks[t.id]).length;
        const blockPct=Math.round(blockDone/block.tasks.length*100);
        return(
          <div key={block.day} style={{background:C.blanc,border:`1px solid ${isOpen?C.rose:C.pale}`,borderRadius:14,marginBottom:".6rem",overflow:"hidden",transition:"all .2s"}}>
            <div onClick={()=>setOpenBlocks(p=>({...p,[block.day]:!p[block.day]}))}
              style={{padding:".75rem 1rem",display:"flex",alignItems:"center",gap:".6rem",cursor:"pointer",userSelect:"none"}}>
              <div style={{width:32,height:32,borderRadius:"50%",background:blockPct===100?C.vert:block.color,color:"white",fontSize:".65rem",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                {blockPct===100?"✓":block.day}
              </div>
              <div style={{flex:1}}>
                <div style={{fontFamily:"Georgia,serif",fontSize:".9rem",fontWeight:600,color:C.brun}}>{block.title}</div>
                <div style={{fontSize:".58rem",color:C.gris}}>{blockDone}/{block.tasks.length} · {blockPct}%</div>
              </div>
              <div style={{width:48,height:4,background:C.pale,borderRadius:10,overflow:"hidden",flexShrink:0}}>
                <div style={{height:"100%",background:blockPct===100?C.vert:block.color,width:blockPct+"%",borderRadius:10,transition:"width .3s"}}/>
              </div>
              <div style={{color:C.rose,fontSize:".65rem",transform:isOpen?"rotate(180deg)":"none",transition:"transform .2s",flexShrink:0}}>▼</div>
            </div>
            {isOpen&&(
              <div style={{borderTop:`1px solid ${C.pale}`,padding:".6rem 1rem .8rem"}}>
                {block.tasks.map(task=>{
                  const checked=recrue.checks&&recrue.checks[task.id];
                  return(
                    <div key={task.id} onClick={()=>onToggle(recrue.id,task.id)}
                      style={{display:"flex",alignItems:"flex-start",gap:".55rem",padding:".42rem 0",borderBottom:`1px solid rgba(232,213,204,.3)`,cursor:"pointer"}}>
                      <div style={{width:18,height:18,borderRadius:4,border:`2px solid ${checked?block.color:C.rose}`,background:checked?block.color:"transparent",flexShrink:0,marginTop:2,display:"flex",alignItems:"center",justifyContent:"center",transition:"all .15s"}}>
                        {checked&&<span style={{fontSize:".55rem",color:"white",fontWeight:700}}>✓</span>}
                      </div>
                      <div style={{fontSize:".75rem",color:checked?C.gris:C.texte,textDecoration:checked?"line-through":"none",lineHeight:1.45,flex:1}}>{task.label}</div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function SuiviRecruTab({uid}){
  const[recrues,setRecrues]=useState([]);
  const[activeId,setActiveId]=useState(null);
  const[newName,setNewName]=useState("");
  const[newDate,setNewDate]=useState("");
  const[loaded,setLoaded]=useState(false);

  useEffect(()=>{
    sgAll(uid).then(data=>{
      if(data["recrues"]){
        const d=JSON.parse(data["recrues"]);
        setRecrues(d);
        if(d.length>0)setActiveId(d[0].id);
      }
      setLoaded(true);
    });
  },[uid]);

  const saveRecrues=(r)=>{setRecrues(r);ss(uid,"recrues",JSON.stringify(r));};

  const addRecrue=()=>{
    if(!newName.trim()||recrues.length>=MAX_RECRUES)return;
    const r={id:Date.now(),name:newName.trim(),date:newDate||new Date().toLocaleDateString("fr-FR"),checks:{}};
    const next=[...recrues,r];
    saveRecrues(next);
    setActiveId(r.id);
    setNewName("");setNewDate("");
  };

  const toggleCheck=(rid,tid)=>{
    const next=recrues.map(r=>{
      if(r.id!==rid)return r;
      const checks={...r.checks,[tid]:!r.checks[tid]};
      return{...r,checks};
    });
    saveRecrues(next);
  };

  const removeRecrue=(rid)=>{
    const next=recrues.filter(r=>r.id!==rid);
    saveRecrues(next);
    setActiveId(next.length>0?next[0].id:null);
  };

  const active=recrues.find(r=>r.id===activeId)||null;

  if(!loaded)return <div style={{textAlign:"center",padding:"2rem",color:C.gris,fontSize:".8rem"}}>Chargement...</div>;

  return(
    <div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
        Suivi <em style={{fontStyle:"italic",color:C.rose}}>Recrues</em>
      </div>
      <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
        Jusqu'à {MAX_RECRUES} recrues simultanées. Sélectionne une recrue pour voir et cocher ses étapes.
      </p>

      {/* Ajouter */}
      {recrues.length<MAX_RECRUES&&(
        <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:"1rem"}}>
          <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".6rem"}}>
            ➕ Ajouter une recrue ({recrues.length}/{MAX_RECRUES})
          </div>
          <div style={{display:"flex",gap:".5rem",marginBottom:".5rem"}}>
            <input placeholder="Prénom" value={newName} onChange={e=>setNewName(e.target.value)}
              onKeyDown={e=>e.key==="Enter"&&addRecrue()}
              style={{flex:2,border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}}/>
            <input type="date" value={newDate} onChange={e=>setNewDate(e.target.value)}
              style={{flex:1,border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".75rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}}/>
          </div>
          <button onClick={addRecrue} disabled={!newName.trim()}
            style={{width:"100%",background:newName.trim()?C.brun:C.pale,color:newName.trim()?C.blanc:C.gris,border:"none",borderRadius:8,padding:".52rem",fontSize:".78rem",fontWeight:600,fontFamily:"inherit",cursor:newName.trim()?"pointer":"default",transition:"all .2s"}}>
            Ajouter
          </button>
        </div>
      )}
      {recrues.length>=MAX_RECRUES&&(
        <div style={{background:"rgba(196,154,138,.1)",border:`1px solid ${C.rose}`,borderRadius:10,padding:".65rem 1rem",marginBottom:"1rem",fontSize:".74rem",color:C.brun}}>
          ✨ 15 recrues suivies — maximum atteint. Supprime-en une pour en ajouter une nouvelle.
        </div>
      )}

      {/* Sélecteur recrues */}
      {recrues.length>0&&(
        <>
          <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.gris,marginBottom:".5rem"}}>
            Mes recrues ({recrues.length})
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:".4rem",marginBottom:"1rem"}}>
            {recrues.map(r=>{
              const{pct}=getProgress(r);
              const isActive=activeId===r.id;
              return(
                <div key={r.id} onClick={()=>setActiveId(r.id)}
                  style={{display:"flex",alignItems:"center",gap:".45rem",background:isActive?C.brun:C.blanc,border:`2px solid ${isActive?C.rose:C.pale}`,borderRadius:10,padding:".42rem .7rem",cursor:"pointer",transition:"all .2s",flexShrink:0}}>
                  <div style={{width:28,height:28,borderRadius:"50%",background:isActive?"rgba(255,255,255,.12)":C.creme,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,position:"relative"}}>
                    <svg width="28" height="28" style={{position:"absolute",top:0,left:0,transform:"rotate(-90deg)"}}>
                      <circle cx="14" cy="14" r="11" fill="none" stroke={isActive?"rgba(255,255,255,.18)":C.pale} strokeWidth="2.5"/>
                      <circle cx="14" cy="14" r="11" fill="none" stroke={pct===100?C.vert:C.rose} strokeWidth="2.5"
                        strokeDasharray={`${2*Math.PI*11*pct/100} ${2*Math.PI*11*(1-pct/100)}`} strokeLinecap="round"/>
                    </svg>
                    <span style={{fontSize:".55rem",fontWeight:700,color:isActive?C.blanc:C.brun,position:"relative",zIndex:1}}>{pct}%</span>
                  </div>
                  <div>
                    <div style={{fontSize:".77rem",fontWeight:600,color:isActive?C.blanc:C.brun}}>{r.name}</div>
                    <div style={{fontSize:".57rem",color:isActive?C.pale:C.gris}}>{r.date}</div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Fiche de la recrue active */}
          {active&&(
            <RecrueFiche
              recrue={active}
              onToggle={toggleCheck}
              onRemove={removeRecrue}
            />
          )}
        </>
      )}

      {recrues.length===0&&(
        <div style={{textAlign:"center",padding:"3rem 1rem",color:C.gris}}>
          <div style={{fontSize:"2rem",marginBottom:".75rem"}}>👥</div>
          <div style={{fontFamily:"Georgia,serif",fontSize:"1rem",color:C.brun,marginBottom:".4rem"}}>Aucune recrue pour l'instant</div>
          <div style={{fontSize:".75rem",lineHeight:1.6}}>Ajoute ta première recrue ci-dessus pour commencer à suivre son parcours.</div>
        </div>
      )}
    </div>
  );
}
function DashboardTab({uid}){
  const[dtab,setDtab]=useState("today");
  const[actions,setActions]=useState({});
  const[prospects,setProspects]=useState([]);
  const[newP,setNewP]=useState({name:"",statut:"Nouveau",note:""});
  const[posts,setPosts]=useState([]);
  const[newPost,setNewPost]=useState({type:"Post",sujet:"",fait:false});
  const[stats,setStats]=useState({messages:"",reponses:"",presentations:"",ventes:"",recrues:"",objectif:"2"});
  const[clients,setClients]=useState([]);
  const[distributeurs,setDistributeurs]=useState([]);
  const[objPerso,setObjPerso]=useState({ca:"",caObj:"",palier:"2%",recruesObj:"0"});
  const[isChefDash,setIsChefDash]=useState(false);
  const[loaded,setLoaded]=useState(false);

  useEffect(()=>{
    sgAll(uid).then(data=>{
      if(data["db-actions"])       setActions(JSON.parse(data["db-actions"]));
      if(data["db-prospects"])     setProspects(JSON.parse(data["db-prospects"]));
      if(data["db-posts"])         setPosts(JSON.parse(data["db-posts"]));
      if(data["db-stats"])         setStats(JSON.parse(data["db-stats"]));
      if(data["db-clients"])       setClients(JSON.parse(data["db-clients"]));
      if(data["db-distributeurs"]) setDistributeurs(JSON.parse(data["db-distributeurs"]));
      if(data["db-obj-perso"])     setObjPerso(JSON.parse(data["db-obj-perso"]));
      setLoaded(true);
    });
    // Vérifier si chef d'équipe
    (async()=>{
      try{
        const snap=await getDoc(doc(db,"acces","membres"));
        const chefs=snap.exists()?snap.data().chefs||[]:[];
        setIsChefDash(chefs.includes(uid.replace(/-/g," ")));
      }catch{}
    })();
  },[uid]);

  const saveActions=a=>{setActions(a);ss(uid,"db-actions",JSON.stringify(a));};
  const saveProspects=p=>{setProspects(p);ss(uid,"db-prospects",JSON.stringify(p));};
  const savePosts=p=>{setPosts(p);ss(uid,"db-posts",JSON.stringify(p));};
  const saveStats=s=>{setStats(s);ss(uid,"db-stats",JSON.stringify(s));};
  const saveClients=c=>{setClients(c);ss(uid,"db-clients",JSON.stringify(c));};
  const saveDistributeurs=d=>{setDistributeurs(d);ss(uid,"db-distributeurs",JSON.stringify(d));};
  const saveObjPerso=o=>{setObjPerso(o);ss(uid,"db-obj-perso",JSON.stringify(o));};

  const todayActions=[
    {id:"a1",icon:"📝",label:"Publier mon post du jour",sub:"1 contenu fort — photo, Reel ou carrousel"},
    {id:"a2",icon:"💬",label:"Envoyer 5 messages de suivi",sub:"Personnes qui ont liké, commenté ou vu mes stories"},
    {id:"a3",icon:"🤝",label:"Interagir avec 10 comptes ciblés",sub:"Femmes qui correspondent à ma cible — vrais commentaires"},
    {id:"a4",icon:"❓",label:'Story "question du jour"',sub:"Une question simple pour générer des réponses en DM"},
    {id:"a5",icon:"📋",label:"Mettre à jour mes prospects",sub:"Relances, nouveaux contacts, statuts à jour"},
  ];
  const doneCount=todayActions.filter(a=>actions[a.id]).length;

  const STATUTS=["Nouveau","Contact fait","🔥 Chaud","🌡️ Tiède","❄️ Froid","📅 Invité présentation","👀 En réflexion","✅ Converti","❌ Pas intéressé"];
  const statusColor={"Nouveau":C.gris,"Contact fait":C.lilas,"🔥 Chaud":"#C44B1A","🌡️ Tiède":C.or,"❄️ Froid":"#5B8DB8","📅 Invité présentation":C.rose,"👀 En réflexion":"#8B5E00","✅ Converti":C.vert,"❌ Pas intéressé":"#B04040"};

  const DTABS=[
    {id:"today",label:"⚡ Aujourd'hui"},
    {id:"objperso",label:"🎯 Mes objectifs"},
    {id:"clients",label:"🛍️ Clients"},
    {id:"distributeurs",label:"👑 Distributeurs"},
    {id:"prospects",label:"👥 Prospects"},
    {id:"posts",label:"📱 Posts"},
    {id:"stats",label:"📊 Stats"},
    ...(uid==="melissa"||uid==="melissa-da-silveira"||isChefDash?[{id:"membres",label:"⚙️ Accès équipe"}]:[]),
    ...(uid!=="melissa"&&uid!=="melissa-da-silveira"?[{id:"monequipe",label:"👥 Mon équipe"}]:[]),
  ];

  return(
    <div>
      <SecTitle title="Tableau" em="de bord" desc="Tes actions quotidiennes · Tes prospects · Tes publications · Tes stats."/>

      {/* Sub-nav */}
      <div style={{display:"flex",gap:".3rem",marginBottom:"1rem",overflowX:"auto",paddingBottom:".3rem"}}>
        {DTABS.map(t=>(
          <button key={t.id} onClick={()=>setDtab(t.id)}
            style={{flex:"none",padding:".5rem .9rem",fontSize:".68rem",fontWeight:600,borderRadius:20,border:`1px solid ${dtab===t.id?C.rose:C.pale}`,background:dtab===t.id?C.rose:C.blanc,color:dtab===t.id?C.blanc:C.gris,cursor:"pointer",fontFamily:"inherit",whiteSpace:"nowrap",transition:"all .2s"}}>
            {t.label}
          </button>
        ))}
      </div>

      {/* TODAY */}
      {dtab==="today"&&(
        <div>
          <div style={{background:C.brun,borderRadius:14,padding:"1.1rem",marginBottom:"1rem"}}>
            <div style={{fontSize:".58rem",fontWeight:700,letterSpacing:".15em",textTransform:"uppercase",color:C.or,marginBottom:".4rem"}}>⚡ MES 5 ACTIONS DU JOUR</div>
            <div style={{display:"flex",justifyContent:"space-between",fontSize:".62rem",color:C.pale,marginBottom:".35rem"}}>
              <span>Progression</span><span style={{fontWeight:700,color:doneCount===5?C.vert:C.or}}>{doneCount} / 5</span>
            </div>
            <div style={{height:5,background:"rgba(255,255,255,.1)",borderRadius:10,overflow:"hidden",marginBottom:".75rem"}}>
              <div style={{height:"100%",background:doneCount===5?C.vert:C.rose,width:(doneCount/5*100)+"%",borderRadius:10,transition:"width .3s"}}/>
            </div>
            {todayActions.map(a=>(
              <div key={a.id} onClick={()=>saveActions({...actions,[a.id]:!actions[a.id]})}
                style={{display:"flex",gap:".65rem",padding:".6rem 0",borderBottom:`1px solid rgba(196,154,138,.2)`,cursor:"pointer",alignItems:"flex-start"}}>
                <div style={{width:20,height:20,borderRadius:5,border:`2px solid ${actions[a.id]?C.rose:C.pale+"80"}`,background:actions[a.id]?C.rose:"transparent",flexShrink:0,marginTop:2,display:"flex",alignItems:"center",justifyContent:"center",transition:"all .15s"}}>
                  {actions[a.id]&&<span style={{fontSize:".55rem",color:"white",fontWeight:700}}>✓</span>}
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:".78rem",fontWeight:600,color:actions[a.id]?C.gris:C.blanc,textDecoration:actions[a.id]?"line-through":"none"}}>{a.icon} {a.label}</div>
                  <div style={{fontSize:".65rem",color:C.pale,opacity:.7,marginTop:".1rem"}}>{a.sub}</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:"1rem"}}>
            <div style={{fontSize:".58rem",fontWeight:700,letterSpacing:".12em",textTransform:"uppercase",color:C.rose,marginBottom:".5rem"}}>🔄 Réactivation base existante</div>
            <p style={{fontSize:".75rem",color:C.texte,lineHeight:1.65}}>Contacter 10 anciens silencieux cette semaine.</p>
            <div style={{background:C.creme,borderLeft:`3px solid ${C.lilas}`,borderRadius:"0 8px 8px 0",padding:".5rem .75rem",fontSize:".73rem",fontStyle:"italic",color:C.texte,lineHeight:1.7,marginTop:".5rem"}}>
              "Coucou, ça fait longtemps ! Comment tu vas ?"
              <CopyBtn text="Coucou, ça fait longtemps ! Comment tu vas ?"/>
            </div>
          </div>

          <div style={{background:`linear-gradient(135deg,rgba(196,154,138,.1),rgba(196,168,130,.08))`,border:`1px solid ${C.pale}`,borderRadius:12,padding:".85rem 1rem",textAlign:"center"}}>
            <div style={{fontSize:".75rem",color:C.brun,fontStyle:"italic",lineHeight:1.65}}>
              💡 <strong>"Posts = attirer. Actions quotidiennes = convertir.<br/>Les deux ensemble, c'est là que ça décolle."</strong>
            </div>
          </div>
        </div>
      )}

      {/* PROSPECTS */}
      {dtab==="prospects"&&(
        <div>
          <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:"1rem"}}>
            <div style={{fontSize:".62rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".65rem"}}>➕ Ajouter un prospect ({prospects.length})</div>
            <input placeholder="Prénom" value={newP.name} onChange={e=>setNewP(p=>({...p,name:e.target.value}))}
              style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".45rem .7rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".45rem"}}/>
            <select value={newP.statut} onChange={e=>setNewP(p=>({...p,statut:e.target.value}))}
              style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".45rem .7rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".45rem"}}>
              {STATUTS.map(s=><option key={s}>{s}</option>)}
            </select>
            <input placeholder="Note (optionnel)" value={newP.note} onChange={e=>setNewP(p=>({...p,note:e.target.value}))}
              style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".45rem .7rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".65rem"}}/>
            <button onClick={()=>{
              if(!newP.name.trim())return;
              const next=[{...newP,id:Date.now(),date:new Date().toLocaleDateString("fr-FR")},...prospects];
              saveProspects(next);setNewP({name:"",statut:"Nouveau",note:""});
            }} style={{width:"100%",background:C.brun,color:C.blanc,border:"none",borderRadius:8,padding:".55rem",fontSize:".8rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>
              Ajouter le prospect
            </button>
          </div>

          <div style={{fontSize:".62rem",color:C.gris,marginBottom:".5rem"}}>{prospects.length} prospect{prospects.length>1?"s":""}</div>
          {prospects.map(p=>(
            <div key={p.id} style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:10,padding:".7rem .9rem",marginBottom:".45rem",display:"flex",gap:".65rem",alignItems:"flex-start"}}>
              <div style={{flex:1}}>
                <div style={{display:"flex",gap:".5rem",alignItems:"center",marginBottom:".2rem"}}>
                  <div style={{fontSize:".82rem",fontWeight:600,color:C.brun}}>{p.name}</div>
                  <select value={p.statut} onChange={e=>{
                    const next=prospects.map(x=>x.id===p.id?{...x,statut:e.target.value}:x);
                    saveProspects(next);
                  }} style={{fontSize:".6rem",fontWeight:700,padding:".1rem .4rem",borderRadius:20,border:`1px solid ${statusColor[p.statut]||C.pale}`,background:(statusColor[p.statut]||C.gris)+"20",color:statusColor[p.statut]||C.gris,fontFamily:"inherit",cursor:"pointer",outline:"none"}}>
                    {STATUTS.map(s=><option key={s}>{s}</option>)}
                  </select>
                </div>
                {p.note&&<div style={{fontSize:".7rem",color:C.gris,fontStyle:"italic"}}>{p.note}</div>}
                <div style={{fontSize:".6rem",color:C.pale,marginTop:".15rem"}}>{p.date}</div>
              </div>
              <button onClick={()=>saveProspects(prospects.filter(x=>x.id!==p.id))}
                style={{background:"none",border:"none",color:C.pale,cursor:"pointer",fontSize:".8rem",flexShrink:0,padding:".2rem"}}>✕</button>
            </div>
          ))}
          {prospects.length===0&&<div style={{textAlign:"center",padding:"2rem",color:C.gris,fontSize:".78rem"}}>Aucun prospect pour l'instant.<br/>Ajoute ta 1ʳᵉ personne ci-dessus.</div>}
        </div>
      )}

      {/* CLIENTS */}
      {dtab==="clients"&&<ClientsTab clients={clients} save={saveClients}/>}
      {dtab==="objperso"&&<ObjPersoTab obj={objPerso} save={saveObjPerso}/>}
      {dtab==="membres"&&(uid==="melissa"||uid==="melissa-da-silveira"||isChefDash)&&<MembresTab uid={uid}/>}
      {dtab==="monequipe"&&uid!=="melissa"&&<MonEquipeTab uid={uid}/>}

      {/* DISTRIBUTEURS */}
      {dtab==="distributeurs"&&<DistributeursTab distributeurs={distributeurs} save={saveDistributeurs}/>}

      {/* POSTS */}
      {dtab==="posts"&&(
        <div>
          <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:"1rem"}}>
            <div style={{fontSize:".62rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".65rem"}}>➕ Planifier un contenu</div>
            <div style={{display:"flex",gap:".5rem",marginBottom:".45rem"}}>
              {["Post","Story","Reel","Live"].map(t=>(
                <button key={t} onClick={()=>setNewPost(p=>({...p,type:t}))}
                  style={{flex:1,padding:".4rem",fontSize:".7rem",fontWeight:600,borderRadius:8,border:`1px solid ${newPost.type===t?C.rose:C.pale}`,background:newPost.type===t?C.rose:C.blanc,color:newPost.type===t?C.blanc:C.gris,cursor:"pointer",fontFamily:"inherit",transition:"all .2s"}}>
                  {t}
                </button>
              ))}
            </div>
            <input placeholder="Sujet / hook (ex: routine visage à 25€)" value={newPost.sujet} onChange={e=>setNewPost(p=>({...p,sujet:e.target.value}))}
              style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".45rem .7rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".65rem"}}/>
            <button onClick={()=>{
              if(!newPost.sujet.trim())return;
              const next=[{...newPost,id:Date.now(),date:new Date().toLocaleDateString("fr-FR"),fait:false},...posts];
              savePosts(next);setNewPost(p=>({...p,sujet:""}));
            }} style={{width:"100%",background:C.brun,color:C.blanc,border:"none",borderRadius:8,padding:".55rem",fontSize:".8rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>
              Ajouter au planning
            </button>
          </div>

          <div style={{display:"flex",justifyContent:"space-between",fontSize:".62rem",color:C.gris,marginBottom:".5rem"}}>
            <span>{posts.length} contenu{posts.length>1?"s":""} planifié{posts.length>1?"s":""}</span>
            <span style={{color:C.vert}}>{posts.filter(p=>p.fait).length} publié{posts.filter(p=>p.fait).length>1?"s":""}</span>
          </div>
          {posts.map(p=>(
            <div key={p.id} style={{background:p.fait?C.pale+"60":C.blanc,border:`1px solid ${p.fait?C.rose:C.pale}`,borderRadius:10,padding:".65rem .9rem",marginBottom:".4rem",display:"flex",gap:".6rem",alignItems:"center"}}>
              <div onClick={()=>savePosts(posts.map(x=>x.id===p.id?{...x,fait:!x.fait}:x))}
                style={{width:18,height:18,borderRadius:4,border:`2px solid ${p.fait?C.rose:C.pale}`,background:p.fait?C.rose:"transparent",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",transition:"all .15s"}}>
                {p.fait&&<span style={{fontSize:".55rem",color:"white",fontWeight:700}}>✓</span>}
              </div>
              <div style={{flex:1}}>
                <div style={{display:"flex",gap:".4rem",alignItems:"center"}}>
                  <span style={{fontSize:".58rem",fontWeight:700,background:C.rose+"20",color:C.rose,padding:".1rem .35rem",borderRadius:10}}>{p.type}</span>
                  <div style={{fontSize:".77rem",fontWeight:600,color:p.fait?C.gris:C.brun,textDecoration:p.fait?"line-through":"none"}}>{p.sujet}</div>
                </div>
                <div style={{fontSize:".6rem",color:C.pale,marginTop:".1rem"}}>{p.date}</div>
              </div>
              <button onClick={()=>savePosts(posts.filter(x=>x.id!==p.id))}
                style={{background:"none",border:"none",color:C.pale,cursor:"pointer",fontSize:".8rem",flexShrink:0,padding:".2rem"}}>✕</button>
            </div>
          ))}
          {posts.length===0&&<div style={{textAlign:"center",padding:"2rem",color:C.gris,fontSize:".78rem"}}>Aucun contenu planifié.<br/>Ajoute ton prochain post ci-dessus.</div>}
        </div>
      )}

      {/* STATS */}
      {dtab==="stats"&&(
        <div>
          <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:"1rem"}}>
            <div style={{fontSize:".62rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".65rem"}}>🎯 Mon objectif du mois</div>
            <div style={{display:"flex",alignItems:"center",gap:".7rem"}}>
              <input type="number" min="1" value={stats.objectif} onChange={e=>saveStats({...stats,objectif:e.target.value})}
                style={{width:55,fontFamily:"Georgia,serif",fontSize:"1.8rem",fontWeight:600,color:C.brun,border:`1px solid ${C.pale}`,borderRadius:8,textAlign:"center",outline:"none",background:C.creme,padding:".2rem"}}/>
              <div style={{fontSize:".78rem",color:C.gris}}>nouvelle{+stats.objectif>1?"s":""} recrue{+stats.objectif>1?"s":""} ce mois</div>
            </div>
          </div>

          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".55rem",marginBottom:"1rem"}}>
            {[
              ["messages","Messages envoyés",C.lilas],
              ["reponses","Réponses reçues",C.or],
              ["presentations","Présentations",C.rose],
              ["ventes","Ventes",C.vert],
              ["recrues","Nouvelles recrues",C.brun],
            ].map(([k,l,col])=>(
              <div key={k} style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:".7rem",textAlign:"center",gridColumn:k==="recrues"?"1 / -1":"auto"}}>
                <input type="number" min="0" value={stats[k]||""} placeholder="0" onChange={e=>saveStats({...stats,[k]:e.target.value})}
                  style={{width:60,fontFamily:"Georgia,serif",fontSize:"1.8rem",fontWeight:600,color:col,border:"none",background:"none",textAlign:"center",outline:"none"}}/>
                <div style={{fontSize:".62rem",color:C.gris,marginTop:".15rem"}}>{l}</div>
              </div>
            ))}
          </div>

          <div style={{background:`linear-gradient(135deg,rgba(196,154,138,.1),rgba(168,155,181,.07))`,border:`1px solid ${C.pale}`,borderRadius:10,padding:".85rem 1rem",marginBottom:"1rem",fontSize:".74rem",color:C.texte,lineHeight:1.65}}>
            📐 <strong>Ratio cible :</strong> 10 messages → 5 réponses → 3 présentations → 1 recrue.<br/>
            Volume insuffisant → plus de contacts. Réponses mais pas de recrues → retravailler le pitch.
          </div>

          {/* Progress bar objectif */}
          {stats.recrues&&stats.objectif&&(
            <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem"}}>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:".7rem",color:C.gris,marginBottom:".4rem"}}>
                <span>Progression vers l'objectif</span>
                <span style={{fontWeight:700,color:+stats.recrues>=+stats.objectif?C.vert:C.rose}}>{stats.recrues} / {stats.objectif}</span>
              </div>
              <div style={{height:8,background:C.pale,borderRadius:10,overflow:"hidden"}}>
                <div style={{height:"100%",background:+stats.recrues>=+stats.objectif?C.vert:C.rose,width:Math.min(100,Math.round(+stats.recrues/+stats.objectif*100))+"%",borderRadius:10,transition:"width .4s"}}/>
              </div>
              {+stats.recrues>=+stats.objectif&&<div style={{textAlign:"center",fontSize:".75rem",color:C.vert,fontWeight:700,marginTop:".5rem"}}>🎉 Objectif atteint !</div>}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── SUIVI CLIENTS ─────────────────────────────────────────────────────────────
const INP = (props) => <input {...props} style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".78rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".45rem",...props.style}}/>;

function ClientsTab({clients,save}){
  const[sel,setSel]=useState(null);
  const[form,setForm]=useState({nom:"",prenom:"",tel:"",email:"",ddn:"",adresse:"",notes:""});
  const[cmdForm,setCmdForm]=useState({produits:"",montant:"",date:new Date().toISOString().slice(0,10)});
  const[rappelForm,setRappelForm]=useState({texte:"",date:"",fait:false});
  const[showAdd,setShowAdd]=useState(false);
  const[showCmd,setShowCmd]=useState(false);
  const[showRappel,setShowRappel]=useState(false);
  const[search,setSearch]=useState("");

  const today=new Date();
  const daysDiff=(d)=>Math.floor((today-new Date(d))/(1000*60*60*24));

  const addClient=()=>{
    if(!form.nom.trim()&&!form.prenom.trim())return;
    const c={...form,id:Date.now(),commandes:[],notes:form.notes};
    save([...clients,c]);
    setSel(c.id);setForm({nom:"",prenom:"",tel:"",email:"",ddn:"",adresse:"",notes:""});setShowAdd(false);
  };

  const addCmd=(cid)=>{
    if(!cmdForm.produits.trim())return;
    const cmd={id:Date.now(),date:cmdForm.date,produits:cmdForm.produits,montant:cmdForm.montant,suivi7:false,suivi21:false};
    save(clients.map(c=>c.id===cid?{...c,commandes:[...(c.commandes||[]),cmd]}:c));
    setCmdForm({produits:"",montant:"",date:new Date().toISOString().slice(0,10)});setShowCmd(false);
  };

  const addRappel=(cid)=>{
    if(!rappelForm.texte.trim()||!rappelForm.date)return;
    const r={id:Date.now(),texte:rappelForm.texte.trim(),date:rappelForm.date,fait:false};
    save(clients.map(c=>c.id===cid?{...c,rappels:[...(c.rappels||[]),r]}:c));
    setRappelForm({texte:"",date:"",fait:false});setShowRappel(false);
  };

  const toggleRappel=(cid,rid)=>{
    save(clients.map(c=>c.id===cid?{...c,rappels:(c.rappels||[]).map(r=>r.id===rid?{...r,fait:!r.fait}:r)}:c));
  };

  const delRappel=(cid,rid)=>{
    save(clients.map(c=>c.id===cid?{...c,rappels:(c.rappels||[]).filter(r=>r.id!==rid)}:c));
  };

  const toggleSuivi=(cid,cmdId,type)=>{
    save(clients.map(c=>c.id===cid?{...c,commandes:(c.commandes||[]).map(cm=>cm.id===cmdId?{...cm,[type]:!cm[type]}:cm)}:c));
  };

  const updateNotes=(cid,v)=>save(clients.map(c=>c.id===cid?{...c,notes:v}:c));
  const delClient=(id)=>{save(clients.filter(c=>c.id!==id));if(sel===id)setSel(null);};

  // Alertes
  const alerts=clients.filter(c=>{
    if(!c.commandes||c.commandes.length===0)return false;
    const last=c.commandes.sort((a,b)=>new Date(b.date)-new Date(a.date))[0];
    return daysDiff(last.date)>=60;
  });

  const filtered=clients.filter(c=>{
    const q=search.toLowerCase();
    return !q||(c.nom+c.prenom+c.tel+c.email).toLowerCase().includes(q);
  });

  const active=clients.find(c=>c.id===sel);

  return(
    <div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
        Suivi <em style={{fontStyle:"italic",color:C.rose}}>Clients</em>
      </div>
      <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
        {clients.length} client{clients.length>1?"s":""} · Coordonnées, commandes, suivis et rappels.
      </p>

      {/* Alertes 2 mois */}
      {alerts.length>0&&(
        <div style={{background:"#FFF3E0",border:"1px solid #E6A817",borderRadius:10,padding:".75rem 1rem",marginBottom:"1rem",fontSize:".75rem",color:"#8B5E00"}}>
          ⚠️ <strong>{alerts.length} client{alerts.length>1?"s":""} sans commande depuis 2 mois :</strong> {alerts.map(c=>`${c.prenom} ${c.nom}`).join(", ")}
        </div>
      )}

      {/* Barre actions */}
      <div style={{display:"flex",gap:".5rem",marginBottom:"1rem"}}>
        <input placeholder="🔍 Rechercher..." value={search} onChange={e=>setSearch(e.target.value)}
          style={{flex:1,border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .7rem",fontSize:".78rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}}/>
        <button onClick={()=>setShowAdd(p=>!p)}
          style={{background:C.brun,color:C.blanc,border:"none",borderRadius:8,padding:".42rem .85rem",fontSize:".75rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer",flexShrink:0}}>
          ➕ Client
        </button>
      </div>

      {/* Formulaire ajout */}
      {showAdd&&(
        <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:"1rem"}}>
          <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".6rem"}}>Nouveau client</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".4rem"}}>
            <INP placeholder="Prénom" value={form.prenom} onChange={e=>setForm(p=>({...p,prenom:e.target.value}))}/>
            <INP placeholder="Nom" value={form.nom} onChange={e=>setForm(p=>({...p,nom:e.target.value}))}/>
          </div>
          <INP placeholder="Téléphone / WhatsApp" value={form.tel} onChange={e=>setForm(p=>({...p,tel:e.target.value}))}/>
          <INP placeholder="Email" value={form.email} onChange={e=>setForm(p=>({...p,email:e.target.value}))}/>
          <INP type="date" placeholder="Date de naissance" value={form.ddn} onChange={e=>setForm(p=>({...p,ddn:e.target.value}))} style={{marginBottom:".45rem"}}/>
          <INP placeholder="Adresse (optionnel)" value={form.adresse} onChange={e=>setForm(p=>({...p,adresse:e.target.value}))}/>
          <textarea placeholder="Notes" value={form.notes} onChange={e=>setForm(p=>({...p,notes:e.target.value}))}
            style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".78rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",resize:"vertical",minHeight:60,marginBottom:".65rem"}}/>
          <div style={{display:"flex",gap:".5rem"}}>
            <button onClick={addClient} style={{flex:1,background:C.brun,color:C.blanc,border:"none",borderRadius:8,padding:".52rem",fontSize:".78rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>Ajouter</button>
            <button onClick={()=>setShowAdd(false)} style={{flex:1,background:C.pale,color:C.gris,border:"none",borderRadius:8,padding:".52rem",fontSize:".78rem",fontFamily:"inherit",cursor:"pointer"}}>Annuler</button>
          </div>
        </div>
      )}

      {/* Liste clients */}
      <div style={{display:"flex",flexWrap:"wrap",gap:".4rem",marginBottom:"1rem"}}>
        {filtered.map(c=>{
          const isActive=sel===c.id;
          const lastCmd=c.commandes&&c.commandes.length>0?c.commandes.sort((a,b)=>new Date(b.date)-new Date(a.date))[0]:null;
          const overdue=lastCmd&&daysDiff(lastCmd.date)>=60;
          return(
            <div key={c.id} onClick={()=>setSel(isActive?null:c.id)}
              style={{background:isActive?C.brun:C.blanc,border:`2px solid ${overdue?"#E6A817":isActive?C.rose:C.pale}`,borderRadius:10,padding:".42rem .75rem",cursor:"pointer",flexShrink:0,transition:"all .2s"}}>
              <div style={{fontSize:".78rem",fontWeight:600,color:isActive?C.blanc:C.brun}}>{c.prenom} {c.nom}</div>
              <div style={{fontSize:".58rem",color:isActive?C.pale:C.gris}}>{c.commandes?.length||0} cmd{c.commandes?.length>1?"s":""}{overdue?" ⚠️":""}</div>
            </div>
          );
        })}
        {filtered.length===0&&<div style={{fontSize:".76rem",color:C.gris,padding:".5rem"}}>Aucun client trouvé.</div>}
      </div>

      {/* Fiche client */}
      {active&&(
        <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:14,overflow:"hidden"}}>
          {/* Header */}
          <div style={{background:C.brun,padding:"1rem 1.1rem",display:"flex",alignItems:"center",gap:".8rem"}}>
            <div style={{width:40,height:40,borderRadius:"50%",background:C.rose,color:"white",fontFamily:"Georgia,serif",fontSize:"1.1rem",fontWeight:600,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
              {(active.prenom[0]||active.nom[0]||"?").toUpperCase()}
            </div>
            <div style={{flex:1}}>
              <div style={{fontFamily:"Georgia,serif",fontSize:"1rem",fontWeight:600,color:C.blanc}}>{active.prenom} {active.nom}</div>
              <div style={{fontSize:".62rem",color:C.pale,opacity:.8}}>{active.tel} {active.email&&`· ${active.email}`}</div>
              {active.ddn&&<div style={{fontSize:".6rem",color:C.or}}>🎂 {new Date(active.ddn).toLocaleDateString("fr-FR")}</div>}
            </div>
            <button onClick={()=>delClient(active.id)} style={{background:"rgba(255,255,255,.1)",border:"none",borderRadius:6,padding:".3rem .5rem",color:C.pale,cursor:"pointer",fontSize:".7rem",fontFamily:"inherit"}}>✕</button>
          </div>

          <div style={{padding:"1rem"}}>
            {/* Commandes */}
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:".6rem"}}>
              <div style={{fontSize:".62rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose}}>📦 Commandes ({active.commandes?.length||0})</div>
              <button onClick={()=>setShowCmd(p=>!p)} style={{background:C.brun,color:C.blanc,border:"none",borderRadius:6,padding:".2rem .55rem",fontSize:".65rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>+ Commande</button>
            </div>

            {showCmd&&(
              <div style={{background:C.creme,borderRadius:9,padding:".75rem",marginBottom:".75rem",border:`1px solid ${C.pale}`}}>
                <INP placeholder="Produits commandés" value={cmdForm.produits} onChange={e=>setCmdForm(p=>({...p,produits:e.target.value}))}/>
                <div style={{display:"flex",gap:".4rem"}}>
                  <INP placeholder="Montant (€)" value={cmdForm.montant} onChange={e=>setCmdForm(p=>({...p,montant:e.target.value}))} style={{flex:1}}/>
                  <INP type="date" value={cmdForm.date} onChange={e=>setCmdForm(p=>({...p,date:e.target.value}))} style={{flex:1}}/>
                </div>
                <div style={{display:"flex",gap:".4rem",marginTop:".1rem"}}>
                  <button onClick={()=>addCmd(active.id)} style={{flex:1,background:C.brun,color:C.blanc,border:"none",borderRadius:7,padding:".45rem",fontSize:".75rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>Enregistrer</button>
                  <button onClick={()=>setShowCmd(false)} style={{flex:1,background:C.pale,color:C.gris,border:"none",borderRadius:7,padding:".45rem",fontSize:".75rem",fontFamily:"inherit",cursor:"pointer"}}>Annuler</button>
                </div>
              </div>
            )}

            {active.commandes&&active.commandes.length>0?(
              [...active.commandes].sort((a,b)=>new Date(b.date)-new Date(a.date)).map(cmd=>{
                const d=daysDiff(cmd.date);
                const need7=d>=7&&d<21&&!cmd.suivi7;
                const need21=d>=21&&!cmd.suivi21;
                return(
                  <div key={cmd.id} style={{background:C.creme,borderRadius:9,padding:".7rem .85rem",marginBottom:".45rem",border:`1px solid ${(need7||need21)?"#E6A817":C.pale}`}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:".35rem"}}>
                      <div>
                        <div style={{fontSize:".78rem",fontWeight:600,color:C.brun}}>{cmd.produits}</div>
                        <div style={{fontSize:".62rem",color:C.gris}}>{new Date(cmd.date).toLocaleDateString("fr-FR")}{cmd.montant&&` · ${cmd.montant}€`} · J+{d}</div>
                      </div>
                    </div>
                    <div style={{display:"flex",gap:".5rem",flexWrap:"wrap"}}>
                      {[["suivi7","✅ Suivi J+7",7,14],["suivi21","✅ Suivi J+21",21,999]].map(([key,label,min,max])=>{
                        const due=d>=min&&d<max;
                        const done=cmd[key];
                        return(
                          <div key={key} onClick={()=>toggleSuivi(active.id,cmd.id,key)}
                            style={{display:"flex",alignItems:"center",gap:".3rem",background:done?C.vert+"20":due?"#FFF3E0":C.pale+"60",borderRadius:6,padding:".2rem .5rem",cursor:"pointer",border:`1px solid ${done?C.vert:due?"#E6A817":C.pale}`,fontSize:".65rem",color:done?C.vert:due?"#8B5E00":C.gris}}>
                            <div style={{width:12,height:12,borderRadius:3,border:`1.5px solid ${done?C.vert:due?"#E6A817":C.gris}`,background:done?C.vert:"transparent",display:"flex",alignItems:"center",justifyContent:"center"}}>
                              {done&&<span style={{fontSize:".45rem",color:"white",fontWeight:700}}>✓</span>}
                            </div>
                            {label}{due&&!done?" 🔔":""}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })
            ):<div style={{fontSize:".74rem",color:C.gris,fontStyle:"italic",marginBottom:".75rem"}}>Aucune commande enregistrée.</div>}

            {/* Notes */}
            <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".4rem",marginTop:".5rem"}}>📝 Notes</div>
            <textarea value={active.notes||""} onChange={e=>updateNotes(active.id,e.target.value)}
              placeholder="Préférences, allergies, produits favoris, historique..."
              style={{width:"100%",minHeight:80,border:`1px solid ${C.pale}`,borderRadius:8,padding:".6rem",fontFamily:"inherit",fontSize:".77rem",color:C.texte,background:C.creme,resize:"vertical",outline:"none",lineHeight:1.6}}/>

            {/* Rappels personnalisés */}
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:".5rem",marginTop:".75rem"}}>
              <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.lilas}}>🔔 Rappels personnalisés</div>
              <button onClick={()=>setShowRappel(p=>!p)} style={{background:C.lilas,color:"white",border:"none",borderRadius:6,padding:".2rem .55rem",fontSize:".65rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>+ Rappel</button>
            </div>
            {showRappel&&(
              <div style={{background:C.creme,borderRadius:9,padding:".75rem",marginBottom:".65rem",border:`1px solid ${C.pale}`}}>
                <input placeholder="Ex: Rappeler pour renouvellement crème" value={rappelForm.texte} onChange={e=>setRappelForm(p=>({...p,texte:e.target.value}))}
                  style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".78rem",fontFamily:"inherit",color:C.texte,background:C.blanc,outline:"none",marginBottom:".4rem"}}/>
                <input type="date" value={rappelForm.date} onChange={e=>setRappelForm(p=>({...p,date:e.target.value}))}
                  style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".78rem",fontFamily:"inherit",color:C.texte,background:C.blanc,outline:"none",marginBottom:".5rem"}}/>
                <div style={{display:"flex",gap:".4rem"}}>
                  <button onClick={()=>addRappel(active.id)} style={{flex:1,background:C.brun,color:C.blanc,border:"none",borderRadius:7,padding:".45rem",fontSize:".75rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>Ajouter</button>
                  <button onClick={()=>setShowRappel(false)} style={{flex:1,background:C.pale,color:C.gris,border:"none",borderRadius:7,padding:".45rem",fontSize:".75rem",fontFamily:"inherit",cursor:"pointer"}}>Annuler</button>
                </div>
              </div>
            )}
            {(active.rappels||[]).length===0&&!showRappel&&<div style={{fontSize:".72rem",color:C.gris,fontStyle:"italic",marginBottom:".5rem"}}>Aucun rappel programmé.</div>}
            {(active.rappels||[]).sort((a,b)=>new Date(a.date)-new Date(b.date)).map(r=>{
              const isToday=r.date===new Date().toISOString().slice(0,10);
              const isPast=new Date(r.date)<new Date()&&!isToday;
              return(
                <div key={r.id} style={{display:"flex",gap:".55rem",alignItems:"flex-start",padding:".45rem .65rem",borderRadius:8,marginBottom:".3rem",background:r.fait?C.pale+"60":isToday?"#FFF3E0":C.blanc,border:`1px solid ${isToday?"#E6A817":r.fait?C.pale:C.pale}`}}>
                  <div onClick={()=>toggleRappel(active.id,r.id)} style={{width:18,height:18,borderRadius:4,border:`2px solid ${r.fait?C.vert:C.lilas}`,background:r.fait?C.vert:"transparent",flexShrink:0,marginTop:2,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",transition:"all .15s"}}>
                    {r.fait&&<span style={{fontSize:".55rem",color:"white",fontWeight:700}}>✓</span>}
                  </div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:".76rem",color:r.fait?C.gris:C.brun,textDecoration:r.fait?"line-through":"none"}}>{r.texte}</div>
                    <div style={{fontSize:".62rem",color:isToday?"#8B5E00":isPast?"#B04040":C.gris,fontWeight:isToday?700:400}}>
                      {isToday?"🔔 Aujourd'hui !":isPast?"⚠️ Passé — ":""}{new Date(r.date).toLocaleDateString("fr-FR")}
                    </div>
                  </div>
                  <button onClick={()=>delRappel(active.id,r.id)} style={{background:"none",border:"none",color:C.pale,cursor:"pointer",fontSize:".7rem",padding:".1rem",flexShrink:0}}>✕</button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ── SUIVI DISTRIBUTEURS ───────────────────────────────────────────────────────
const PALIERS=["2%","4%","6%","8%","10%","12%","14%","17%","SR","Structural","Business","SR Business"];
const PALIER_COLORS={"2%":C.gris,"4%":C.gris,"6%":C.lilas,"8%":C.lilas,"10%":C.rose,"12%":C.rose,"14%":C.or,"17%":C.or,"SR":C.brun2,"Structural":"#6B5B8A","Business":"#4A7A5C","SR Business":C.brun};

function DistributeursTab({distributeurs,save}){
  const[sel,setSel]=useState(null);
  const[form,setForm]=useState({prenom:"",nom:"",tel:"",email:"",dateEnreg:"",notes:""});
  const[showAdd,setShowAdd]=useState(false);
  const[search,setSearch]=useState("");

  const add=()=>{
    if(!form.prenom.trim())return;
    const d={...form,id:Date.now(),palier:"2%",notes:form.notes};
    save([...distributeurs,d]);
    setSel(d.id);setForm({prenom:"",nom:"",tel:"",email:"",dateEnreg:"",notes:""});setShowAdd(false);
  };

  const updatePalier=(id,p)=>save(distributeurs.map(d=>d.id===id?{...d,palier:p}:d));
  const updateNotes=(id,v)=>save(distributeurs.map(d=>d.id===id?{...d,notes:v}:d));
  const del=(id)=>{save(distributeurs.filter(d=>d.id!==id));if(sel===id)setSel(null);};

  const filtered=distributeurs.filter(d=>{
    const q=search.toLowerCase();
    return !q||(d.prenom+d.nom+d.tel).toLowerCase().includes(q);
  });

  const active=distributeurs.find(d=>d.id===sel);

  return(
    <div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
        Suivi <em style={{fontStyle:"italic",color:C.rose}}>Distributeurs</em>
      </div>
      <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
        {distributeurs.length} distributeur{distributeurs.length>1?"s":""} · Progression dans le plan de rémunération.
      </p>

      <div style={{display:"flex",gap:".5rem",marginBottom:"1rem"}}>
        <input placeholder="🔍 Rechercher..." value={search} onChange={e=>setSearch(e.target.value)}
          style={{flex:1,border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .7rem",fontSize:".78rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}}/>
        <button onClick={()=>setShowAdd(p=>!p)}
          style={{background:C.brun,color:C.blanc,border:"none",borderRadius:8,padding:".42rem .85rem",fontSize:".75rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer",flexShrink:0}}>
          ➕ Distributeur
        </button>
      </div>

      {showAdd&&(
        <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:"1rem"}}>
          <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".6rem"}}>Nouveau distributeur</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:".4rem"}}>
            <INP placeholder="Prénom" value={form.prenom} onChange={e=>setForm(p=>({...p,prenom:e.target.value}))}/>
            <INP placeholder="Nom" value={form.nom} onChange={e=>setForm(p=>({...p,nom:e.target.value}))}/>
          </div>
          <INP placeholder="Téléphone / WhatsApp" value={form.tel} onChange={e=>setForm(p=>({...p,tel:e.target.value}))}/>
          <INP placeholder="Email" value={form.email} onChange={e=>setForm(p=>({...p,email:e.target.value}))}/>
          <INP type="date" placeholder="Date d'enregistrement" value={form.dateEnreg} onChange={e=>setForm(p=>({...p,dateEnreg:e.target.value}))}/>
          <div style={{display:"flex",gap:".4rem",marginTop:".1rem"}}>
            <button onClick={add} style={{flex:1,background:C.brun,color:C.blanc,border:"none",borderRadius:8,padding:".5rem",fontSize:".78rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>Ajouter</button>
            <button onClick={()=>setShowAdd(false)} style={{flex:1,background:C.pale,color:C.gris,border:"none",borderRadius:8,padding:".5rem",fontSize:".78rem",fontFamily:"inherit",cursor:"pointer"}}>Annuler</button>
          </div>
        </div>
      )}

      {/* Liste */}
      <div style={{display:"flex",flexWrap:"wrap",gap:".4rem",marginBottom:"1rem"}}>
        {filtered.map(d=>{
          const isActive=sel===d.id;
          const palierIdx=PALIERS.indexOf(d.palier||"2%");
          return(
            <div key={d.id} onClick={()=>setSel(isActive?null:d.id)}
              style={{background:isActive?C.brun:C.blanc,border:`2px solid ${isActive?C.rose:C.pale}`,borderRadius:10,padding:".42rem .75rem",cursor:"pointer",flexShrink:0,transition:"all .2s"}}>
              <div style={{fontSize:".78rem",fontWeight:600,color:isActive?C.blanc:C.brun}}>{d.prenom} {d.nom}</div>
              <div style={{fontSize:".58rem",color:isActive?C.pale:C.gris}}>{d.palier||"2%"} · {palierIdx+1}/{PALIERS.length}</div>
            </div>
          );
        })}
        {filtered.length===0&&<div style={{fontSize:".76rem",color:C.gris,padding:".5rem"}}>Aucun distributeur trouvé.</div>}
      </div>

      {/* Fiche distributeur */}
      {active&&(
        <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:14,overflow:"hidden"}}>
          <div style={{background:C.brun,padding:"1rem 1.1rem",display:"flex",alignItems:"center",gap:".8rem"}}>
            <div style={{width:40,height:40,borderRadius:"50%",background:C.or,color:C.brun,fontFamily:"Georgia,serif",fontSize:"1.1rem",fontWeight:600,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
              {(active.prenom[0]||"?").toUpperCase()}
            </div>
            <div style={{flex:1}}>
              <div style={{fontFamily:"Georgia,serif",fontSize:"1rem",fontWeight:600,color:C.blanc}}>{active.prenom} {active.nom}</div>
              <div style={{fontSize:".62rem",color:C.pale,opacity:.8}}>{active.tel}{active.email&&` · ${active.email}`}</div>
              {active.dateEnreg&&<div style={{fontSize:".6rem",color:C.or}}>📅 Enregistrée le {new Date(active.dateEnreg).toLocaleDateString("fr-FR")}</div>}
            </div>
            <button onClick={()=>del(active.id)} style={{background:"rgba(255,255,255,.1)",border:"none",borderRadius:6,padding:".3rem .5rem",color:C.pale,cursor:"pointer",fontSize:".7rem",fontFamily:"inherit"}}>✕</button>
          </div>

          <div style={{padding:"1rem"}}>
            {/* Plan de rémunération */}
            <div style={{fontSize:".62rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".6rem"}}>💰 Plan de rémunération</div>
            <div style={{display:"flex",flexWrap:"wrap",gap:".35rem",marginBottom:"1rem"}}>
              {PALIERS.map((p,i)=>{
                const current=active.palier===p;
                const passed=PALIERS.indexOf(active.palier||"2%")>i;
                const col=PALIER_COLORS[p]||C.gris;
                return(
                  <div key={p} onClick={()=>updatePalier(active.id,p)}
                    style={{padding:".28rem .65rem",borderRadius:20,fontSize:".68rem",fontWeight:600,cursor:"pointer",border:`2px solid ${current?col:passed?col+"60":C.pale}`,background:current?col:passed?col+"15":"transparent",color:current?"white":passed?col:C.gris,transition:"all .2s",flexShrink:0}}>
                    {passed&&!current?"✓ ":""}{p}
                  </div>
                );
              })}
            </div>

            {/* Barre progression */}
            <div style={{marginBottom:"1rem"}}>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:".62rem",color:C.gris,marginBottom:".25rem"}}>
                <span>Progression</span>
                <span style={{fontWeight:700,color:C.brun}}>{PALIERS.indexOf(active.palier||"2%")+1}/{PALIERS.length}</span>
              </div>
              <div style={{height:6,background:C.pale,borderRadius:10,overflow:"hidden"}}>
                <div style={{height:"100%",background:C.or,width:(((PALIERS.indexOf(active.palier||"2%")+1)/PALIERS.length)*100)+"%",borderRadius:10,transition:"width .4s"}}/>
              </div>
            </div>

            {/* Notes */}
            <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".4rem"}}>📝 Notes</div>
            <textarea value={active.notes||""} onChange={e=>updateNotes(active.id,e.target.value)}
              placeholder="Objectifs, blocages, points de suivi, formations suivies..."
              style={{width:"100%",minHeight:90,border:`1px solid ${C.pale}`,borderRadius:8,padding:".6rem",fontFamily:"inherit",fontSize:".77rem",color:C.texte,background:C.creme,resize:"vertical",outline:"none",lineHeight:1.6}}/>
          </div>
        </div>
      )}
    </div>
  );
}

// ── COMMUNAUTÉ ────────────────────────────────────────────────────────────────
const MELISSA = "melissa";

function CommunauteTab({uid, userName}){
  const[posts,setPosts]=useState([]);
  const[infos,setInfos]=useState([]);
  const[loading,setLoading]=useState(true);
  const[ctab,setCtab]=useState("tous");
  const[newText,setNewText]=useState("");
  const[newType,setNewType]=useState("victoire");
  const[newInfo,setNewInfo]=useState({titre:"",texte:"",important:false});
  const[showAddInfo,setShowAddInfo]=useState(false);
  const[posting,setPosting]=useState(false);
  const isMelissa=userName.toLowerCase().replace(/\s+/g,"-")===MELISSA||userName.toLowerCase()===MELISSA;

  const loadPosts=async()=>{
    try{
      const ref=doc(db,"communaute","posts");
      const snap=await getDoc(ref);
      if(snap.exists()){
        const data=snap.data();
        const arr=Object.values(data).sort((a,b)=>b.ts-a.ts);
        setPosts(arr);
      }
    }catch{}
    try{
      const ref2=doc(db,"communaute","infos");
      const snap2=await getDoc(ref2);
      if(snap2.exists()){
        const data2=snap2.data();
        setInfos(Object.values(data2).sort((a,b)=>b.ts-a.ts));
      }
    }catch{}
    setLoading(false);
  };

  useEffect(()=>{loadPosts();},[]);

  const savePosts=async(arr)=>{
    const obj={};
    arr.forEach(p=>{obj[p.id]=p;});
    try{
      const ref=doc(db,"communaute","posts");
      await setDoc(ref,obj);
    }catch{}
  };

  const addPost=async()=>{
    if(!newText.trim())return;
    setPosting(true);
    const p={
      id:`p${Date.now()}`,
      author:userName,
      type:newType,
      text:newText.trim(),
      ts:Date.now(),
      likes:[],
    };
    const next=[p,...posts];
    setPosts(next);
    await savePosts(next);
    setNewText("");
    setPosting(false);
  };

  const toggleLike=async(pid)=>{
    const next=posts.map(p=>{
      if(p.id!==pid)return p;
      const liked=p.likes.includes(uid);
      return{...p,likes:liked?p.likes.filter(l=>l!==uid):[...p.likes,uid]};
    });
    setPosts(next);
    await savePosts(next);
  };

  const delPost=async(pid)=>{
    const next=posts.filter(p=>p.id!==pid);
    setPosts(next);
    await savePosts(next);
  };

  const saveInfos=async(arr)=>{
    const obj={};arr.forEach(i=>{obj[i.id]=i;});
    try{await setDoc(doc(db,"communaute","infos"),obj);}catch{}
  };

  const addInfo=async()=>{
    if(!newInfo.titre.trim()||!newInfo.texte.trim())return;
    const i={id:`inf${Date.now()}`,titre:newInfo.titre.trim(),texte:newInfo.texte.trim(),important:newInfo.important,ts:Date.now()};
    const next=[i,...infos];
    setInfos(next);await saveInfos(next);
    setNewInfo({titre:"",texte:"",important:false});setShowAddInfo(false);
  };

  const delInfo=async(id)=>{
    const next=infos.filter(i=>i.id!==id);
    setInfos(next);await saveInfos(next);
  };

  const TYPE_CONFIG={
    annonce:{icon:"📢",label:"Annonce",color:C.brun,bg:C.brun+"15"},
    victoire:{icon:"🏆",label:"Victoire",color:C.or,bg:C.or+"20"},
    question:{icon:"❓",label:"Question",color:C.lilas,bg:C.lilas+"20"},
    temoignage:{icon:"💬",label:"Témoignage",color:C.rose,bg:C.rose+"20"},
    conseil:{icon:"💡",label:"Conseil",color:C.vert,bg:C.vert+"20"},
  };

  const CTABS=[
    {id:"tous",label:"Tous"},
    {id:"infos",label:"📌 Infos importantes"},
    {id:"annonce",label:"📢 Annonces"},
    {id:"victoire",label:"🏆 Victoires"},
    {id:"question",label:"❓ Questions"},
    {id:"temoignage",label:"💬 Témoignages"},
  ];

  const filtered=ctab==="tous"?posts:posts.filter(p=>p.type===ctab);
  const annonces=posts.filter(p=>p.type==="annonce");

  const timeAgo=(ts)=>{
    const d=Math.floor((Date.now()-ts)/1000);
    if(d<60)return "à l'instant";
    if(d<3600)return `il y a ${Math.floor(d/60)} min`;
    if(d<86400)return `il y a ${Math.floor(d/3600)}h`;
    return `il y a ${Math.floor(d/86400)}j`;
  };

  return(
    <div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
        Espace <em style={{fontStyle:"italic",color:C.rose}}>Communauté</em>
      </div>
      <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
        Partage tes victoires, pose tes questions, lis les annonces de Melissa.
      </p>

      {/* Annonces épinglées */}
      {annonces.length>0&&ctab==="tous"&&(
        <div style={{marginBottom:"1rem"}}>
          <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.brun,marginBottom:".4rem"}}>📢 Annonces de Melissa</div>
          {annonces.slice(0,3).map(p=>(
            <div key={p.id} style={{background:C.brun,borderRadius:12,padding:".85rem 1rem",marginBottom:".45rem",border:`1px solid ${C.or}40`}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:".35rem"}}>
                <div style={{display:"flex",gap:".4rem",alignItems:"center"}}>
                  <span style={{fontSize:".7rem"}}>📢</span>
                  <span style={{fontSize:".72rem",fontWeight:700,color:C.or}}>Melissa</span>
                </div>
                <span style={{fontSize:".6rem",color:C.pale,opacity:.6}}>{timeAgo(p.ts)}</span>
              </div>
              <p style={{fontSize:".78rem",color:C.blanc,lineHeight:1.65,margin:0}}>{p.text}</p>
            </div>
          ))}
        </div>
      )}

      {/* Formulaire nouveau post — masqué sur onglet infos */}
      {ctab!=="infos"&&(
      <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:"1rem"}}>
        <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".6rem"}}>
          ✍️ Partager avec l'équipe
        </div>

        {/* Type de post */}
        <div style={{display:"flex",gap:".3rem",flexWrap:"wrap",marginBottom:".6rem"}}>
          {Object.entries(TYPE_CONFIG)
            .filter(([k])=>isMelissa||k!=="annonce")
            .map(([k,v])=>(
            <button key={k} onClick={()=>setNewType(k)}
              style={{padding:".25rem .6rem",fontSize:".65rem",fontWeight:600,borderRadius:20,border:`1px solid ${newType===k?v.color:C.pale}`,background:newType===k?v.color:C.blanc,color:newType===k?"white":C.gris,cursor:"pointer",fontFamily:"inherit",transition:"all .2s"}}>
              {v.icon} {v.label}
            </button>
          ))}
        </div>

        <textarea
          placeholder={
            newType==="victoire"?"🏆 Partage ta victoire du moment...":
            newType==="question"?"❓ Pose ta question à l'équipe...":
            newType==="annonce"?"📢 Écris ton annonce pour l'équipe...":
            newType==="temoignage"?"💬 Partage ton témoignage...":
            "💡 Partage ton conseil..."
          }
          value={newText}
          onChange={e=>setNewText(e.target.value)}
          style={{width:"100%",minHeight:80,border:`1px solid ${C.pale}`,borderRadius:8,padding:".6rem",fontFamily:"inherit",fontSize:".78rem",color:C.texte,background:C.creme,resize:"vertical",outline:"none",lineHeight:1.6,marginBottom:".6rem"}}
        />
        <button onClick={addPost} disabled={!newText.trim()||posting}
          style={{width:"100%",background:newText.trim()?C.brun:C.pale,color:newText.trim()?C.blanc:C.gris,border:"none",borderRadius:8,padding:".55rem",fontSize:".8rem",fontWeight:600,fontFamily:"inherit",cursor:newText.trim()?"pointer":"default",transition:"all .2s"}}>
          {posting?"Publication...":"Publier →"}
        </button>
      </div>
      )}

      {/* ── ONGLET INFOS IMPORTANTES ── */}
      {ctab==="infos"&&(
        <div>
          {isMelissa&&(
            <div style={{marginBottom:"1rem"}}>
              <button onClick={()=>setShowAddInfo(p=>!p)}
                style={{width:"100%",background:C.brun,color:C.blanc,border:"none",borderRadius:10,padding:".6rem",fontSize:".8rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>
                📌 Ajouter une info importante
              </button>
              {showAddInfo&&(
                <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginTop:".6rem"}}>
                  <input placeholder="Titre (ex: Deadline période, Nouveau produit...)" value={newInfo.titre} onChange={e=>setNewInfo(p=>({...p,titre:e.target.value}))}
                    style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".45rem .7rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".5rem"}}/>
                  <textarea placeholder="Détails de l'info..." value={newInfo.texte} onChange={e=>setNewInfo(p=>({...p,texte:e.target.value}))}
                    style={{width:"100%",minHeight:80,border:`1px solid ${C.pale}`,borderRadius:8,padding:".5rem .7rem",fontFamily:"inherit",fontSize:".78rem",color:C.texte,background:C.creme,resize:"vertical",outline:"none",lineHeight:1.6,marginBottom:".5rem"}}/>
                  <div style={{display:"flex",alignItems:"center",gap:".6rem",marginBottom:".65rem"}}>
                    <div onClick={()=>setNewInfo(p=>({...p,important:!p.important}))}
                      style={{width:18,height:18,borderRadius:4,border:`2px solid ${"#C44B1A"}`,background:newInfo.important?"#C44B1A":"transparent",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                      {newInfo.important&&<span style={{fontSize:".55rem",color:"white",fontWeight:700}}>✓</span>}
                    </div>
                    <span style={{fontSize:".75rem",color:C.texte}}>Marquer comme urgent 🔴</span>
                  </div>
                  <div style={{display:"flex",gap:".4rem"}}>
                    <button onClick={addInfo} style={{flex:1,background:C.brun,color:C.blanc,border:"none",borderRadius:8,padding:".5rem",fontSize:".78rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>Publier</button>
                    <button onClick={()=>setShowAddInfo(false)} style={{flex:1,background:C.pale,color:C.gris,border:"none",borderRadius:8,padding:".5rem",fontSize:".78rem",fontFamily:"inherit",cursor:"pointer"}}>Annuler</button>
                  </div>
                </div>
              )}
            </div>
          )}

          {infos.length===0&&(
            <div style={{textAlign:"center",padding:"2.5rem 1rem",color:C.gris}}>
              <div style={{fontSize:"2rem",marginBottom:".6rem"}}>📌</div>
              <div style={{fontSize:".78rem"}}>Aucune info importante pour l'instant.<br/>{isMelissa?"Ajoute la première ci-dessus.":"Melissa publiera les infos importantes ici."}</div>
            </div>
          )}

          {infos.map(info=>(
            <div key={info.id} style={{background:info.important?"#FFF3E0":C.blanc,border:`2px solid ${info.important?"#C44B1A":C.pale}`,borderRadius:12,padding:".9rem 1rem",marginBottom:".6rem"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:".45rem"}}>
                <div style={{display:"flex",gap:".5rem",alignItems:"center",flex:1}}>
                  {info.important&&<span style={{fontSize:".7rem",background:"#C44B1A",color:"white",padding:".1rem .4rem",borderRadius:20,fontWeight:700,flexShrink:0}}>🔴 URGENT</span>}
                  <div style={{fontFamily:"Georgia,serif",fontSize:".92rem",fontWeight:600,color:C.brun}}>{info.titre}</div>
                </div>
                {isMelissa&&<button onClick={()=>delInfo(info.id)} style={{background:"none",border:"none",color:C.pale,cursor:"pointer",fontSize:".75rem",padding:".2rem",fontFamily:"inherit",flexShrink:0}}>✕</button>}
              </div>
              <p style={{fontSize:".78rem",color:C.texte,lineHeight:1.7,margin:"0 0 .4rem"}}>{info.texte}</p>
              <div style={{fontSize:".62rem",color:C.gris}}>{timeAgo(info.ts)}</div>
            </div>
          ))}
        </div>
      )}
      {/* Filtres */}
      <div style={{display:"flex",gap:".3rem",overflowX:"auto",marginBottom:"1rem",paddingBottom:".3rem"}}>
        {CTABS.map(t=>(
          <button key={t.id} onClick={()=>setCtab(t.id)}
            style={{flex:"none",padding:".38rem .75rem",fontSize:".65rem",fontWeight:600,borderRadius:20,border:`1px solid ${ctab===t.id?C.rose:C.pale}`,background:ctab===t.id?C.rose:C.blanc,color:ctab===t.id?C.blanc:C.gris,cursor:"pointer",fontFamily:"inherit",transition:"all .2s",whiteSpace:"nowrap"}}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Liste des posts */}
      {loading&&<div style={{textAlign:"center",padding:"2rem",color:C.gris,fontSize:".78rem"}}>Chargement...</div>}

      {!loading&&filtered.length===0&&(
        <div style={{textAlign:"center",padding:"2rem",color:C.gris}}>
          <div style={{fontSize:"1.8rem",marginBottom:".5rem"}}>🌟</div>
          <div style={{fontSize:".78rem"}}>Aucun post pour l'instant.<br/>Sois la première à partager !</div>
        </div>
      )}

      {filtered.filter(p=>p.type!=="annonce"||ctab==="annonce"||ctab==="tous"&&false).map(p=>{
        const cfg=TYPE_CONFIG[p.type]||TYPE_CONFIG.victoire;
        const liked=p.likes.includes(uid);
        const isOwner=p.author.toLowerCase().replace(/\s+/g,"-")===uid||isMelissa;
        const authorIsMelissa=p.author.toLowerCase().replace(/\s+/g,"-")===MELISSA||p.author.toLowerCase()===MELISSA;
        if(p.type==="annonce"&&ctab==="tous")return null;
        return(
          <div key={p.id} style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:".85rem 1rem",marginBottom:".55rem",transition:"all .2s"}}>
            {/* Header post */}
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:".45rem"}}>
              <div style={{display:"flex",gap:".5rem",alignItems:"center"}}>
                <div style={{width:30,height:30,borderRadius:"50%",background:authorIsMelissa?C.brun:cfg.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:".85rem",flexShrink:0}}>
                  {authorIsMelissa?"👑":p.author[0].toUpperCase()}
                </div>
                <div>
                  <div style={{fontSize:".78rem",fontWeight:600,color:C.brun}}>
                    {p.author}{authorIsMelissa&&<span style={{fontSize:".6rem",color:C.or,marginLeft:".3rem"}}>✦ Melissa</span>}
                  </div>
                  <div style={{display:"flex",gap:".35rem",alignItems:"center"}}>
                    <span style={{background:cfg.bg,color:cfg.color,fontSize:".55rem",fontWeight:700,padding:".1rem .4rem",borderRadius:20}}>{cfg.icon} {cfg.label}</span>
                    <span style={{fontSize:".6rem",color:C.gris}}>{timeAgo(p.ts)}</span>
                  </div>
                </div>
              </div>
              {isOwner&&(
                <button onClick={()=>delPost(p.id)}
                  style={{background:"none",border:"none",color:C.pale,cursor:"pointer",fontSize:".75rem",padding:".2rem",fontFamily:"inherit"}}>✕</button>
              )}
            </div>

            {/* Texte */}
            <p style={{fontSize:".78rem",color:C.texte,lineHeight:1.65,margin:"0 0 .6rem"}}>{p.text}</p>

            {/* Likes */}
            <div style={{display:"flex",alignItems:"center",gap:".5rem"}}>
              <button onClick={()=>toggleLike(p.id)}
                style={{display:"flex",alignItems:"center",gap:".3rem",background:liked?C.rose+"20":"none",border:`1px solid ${liked?C.rose:C.pale}`,borderRadius:20,padding:".22rem .65rem",cursor:"pointer",fontFamily:"inherit",transition:"all .2s"}}>
                <span style={{fontSize:".8rem"}}>{liked?"❤️":"🤍"}</span>
                <span style={{fontSize:".68rem",fontWeight:600,color:liked?C.rose:C.gris}}>{p.likes.length}</span>
              </button>
              {p.likes.length>0&&(
                <span style={{fontSize:".62rem",color:C.gris,fontStyle:"italic"}}>
                  {p.likes.length===1?"1 personne aime ça":`${p.likes.length} personnes aiment ça`}
                </span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── SCRIPTS ───────────────────────────────────────────────────────────────────
const SCRIPTS_DATA=[
  {cat:"💬 Premier contact",scripts:[
    {title:"Contact WhatsApp — Produits",text:"Coucou [Prénom] 😊 Je pensais à toi ! Je travaille avec une marque de beauté et bien-être qui m'a bluffée. Je me demandais si tu aurais 5 min pour jeter un œil ? Pas d'obligation, juste partager quelque chose qui m'a vraiment plu 🙏"},
    {title:"Contact WhatsApp — Opportunité",text:"Coucou [Prénom] ! J'espère que tu vas bien 🙂 Je développe quelque chose qui m'a permis de gagner un revenu complémentaire depuis chez moi. Ça m'a fait penser à toi — tu serais ouverte à en discuter 5 min ?"},
    {title:"Réponse à une story",text:"Coucou ! J'ai vu ta story sur [sujet] — ça m'a donné envie de te contacter 😊 Je travaille avec une marque que tu pourrais vraiment aimer. Tu veux que je t'envoie quelques infos ?"},
  ]},
  {cat:"🔄 Relance",scripts:[
    {title:"Relance douce",text:"Coucou [Prénom] ! Pas de pression du tout 🙂 Je voulais juste prendre de tes nouvelles. Tu avais eu le temps de regarder ce que je t'avais envoyé ?"},
    {title:"Relance après silence",text:"Coucou [Prénom] ! Ça fait un moment 😊 Je pense souvent à toi. Si tu es toujours curieuse de ce que je fais, je serais ravie d'en parler. Et si tu n'es pas intéressée, c'est ok aussi — dis-le moi simplement !"},
    {title:"Relance après un 'non'",text:"Pas de souci du tout [Prénom] ! Je comprends totalement. Est-ce que tu connais quelqu'un dans ton entourage qui cherche un revenu complémentaire ? Je suis preneuse de toute recommandation 🙏"},
  ]},
  {cat:"🎯 Présentation opportunité",scripts:[
    {title:"Pitch express 30 secondes",text:"En gros — je distribue des produits beauté et bien-être Mihi. Je gagne entre 20 et 30% sur chaque vente, et je touche des commissions sur l'équipe que je construis. Je travaille depuis mon téléphone, à mes heures. Ce n'est pas un miracle — c'est du vrai travail. Mais ça m'a permis de [ton résultat]. Tu veux en savoir plus ?"},
    {title:"Présentation complète — intro",text:"Je vais t'expliquer ce que je fais en 3 points. 1️⃣ Je vends des produits Mihi — beauté, bien-être, perte de poids. 2️⃣ Je gagne une marge de 20 à 30% sur chaque vente. 3️⃣ Je développe une équipe et je touche des commissions sur leur activité. Ce qui me plaît c'est que ça s'adapte à ma vie — pas l'inverse."},
    {title:"Réponse à 'c'est du MLM ?'",text:"Je comprends la méfiance — j'avais les mêmes questions 😊 Oui c'est de la vente directe. La différence avec les arnaques : il y a de vrais produits qu'on vend à de vraies clientes, avec une vraie marge. Je ne gagne pas d'argent en recrutant — je gagne en vendant et en formant une équipe qui vend. Tu veux que je te montre les chiffres concrets ?"},
  ]},
  {cat:"🛍️ Vente produits",scripts:[
    {title:"Présenter les parfums",text:"Tu sais ce que je réponds quand on me demande combien coûte mon parfum ? 😏 Moins de 20€. Et non c'est pas une arnaque — c'est Mihi, une marque que je distribue. La qualité est vraiment là. Tu veux que je t'en envoie quelques références ?"},
    {title:"Présenter les soins visage",text:"Je testais une nouvelle crème ce matin et j'ai pensé à toi 😊 La gamme soin visage que je distribue a des résultats hallucinants — et à des prix vraiment accessibles. Si tu veux, je peux te faire une sélection selon ton type de peau ?"},
    {title:"Inviter à commander",text:"Si tu veux essayer, le plus simple c'est de passer par ma boutique personnelle. Je t'envoie le lien ? Et si tu as des questions sur les produits, je suis là pour t'orienter 🙂"},
  ]},
  {cat:"👑 Recrutement équipe",scripts:[
    {title:"Approche douce recrutement",text:"Coucou [Prénom] ! Je développe mon équipe Blazing Dynasty et en te voyant, je me suis dit que tu pourrais vraiment avoir ta place ici. Je ne te demande pas de dire oui — juste d'écouter 10 min. Qu'est-ce que tu en penses ?"},
    {title:"Après une présentation",text:"Merci d'avoir pris le temps ce soir 🧡 Je suis là si tu as des questions. Pas de pression — prends le temps qu'il te faut. Si ça peut t'aider à décider, je peux te mettre en contact avec une de mes filles qui a démarré dans la même situation que toi."},
    {title:"Gérer l'objection 'je n'ai pas le temps'",text:"Je comprends totalement — moi aussi j'avais l'impression de ne pas avoir le temps au départ 😊 Ce qui m'a surprise c'est que ça prend vraiment le temps qu'on lui donne. Certaines filles de mon équipe commencent avec 30 min par jour. On peut en parler si tu veux ?"},
    {title:"Gérer l'objection 'je ne suis pas vendeuse'",text:"Moi non plus je ne me considérais pas comme vendeuse ! 😅 Ce que je fais c'est surtout partager ce que j'aime avec les gens autour de moi. Les ventes viennent naturellement après. Est-ce que tu partages déjà des produits que tu aimes avec tes amies ? Alors tu sais déjà faire 😊"},
  ]},
  {cat:"📱 Stories & contenu",scripts:[
    {title:"CTA mot-clé commentaire",text:"Tu veux savoir quel est ce produit qui me fait des compliments à chaque fois ? Écris PRODUIT en commentaire et je t'envoie tout en privé 😊"},
    {title:"CTA pour l'opportunité",text:"Tu cherches un revenu complémentaire qui s'adapte à ta vie ? Écris ÉQUIPE en commentaire — je te réponds en privé 🖤"},
    {title:"Intro storytelling",text:"Il y a [X mois], je ne savais pas quoi faire. Aujourd'hui [ton résultat]. Ce n'est pas un miracle — c'est ce que j'ai construit, étape par étape. Je vous raconte ça ce soir en story 👇"},
  ]},
];

function ScriptsTab(){
  const[open,setOpen]=useState({});
  return(
    <div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
        Bibliothèque <em style={{fontStyle:"italic",color:C.rose}}>Scripts</em>
      </div>
      <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
        Scripts prêts à utiliser. Adapte toujours à ta voix — copie et personnalise.
      </p>
      {SCRIPTS_DATA.map(cat=>(
        <div key={cat.cat} style={{marginBottom:"1rem"}}>
          <div style={{fontSize:".65rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.brun,marginBottom:".5rem",padding:".25rem .7rem",background:C.pale,borderRadius:20,display:"inline-block"}}>{cat.cat}</div>
          {cat.scripts.map(s=>{
            const isOpen=open[s.title];
            return(
              <div key={s.title} style={{background:C.blanc,border:`1px solid ${isOpen?C.rose:C.pale}`,borderRadius:12,marginBottom:".45rem",overflow:"hidden"}}>
                <div onClick={()=>setOpen(p=>({...p,[s.title]:!p[s.title]}))}
                  style={{padding:".7rem 1rem",display:"flex",justifyContent:"space-between",alignItems:"center",cursor:"pointer",userSelect:"none"}}>
                  <div style={{fontSize:".8rem",fontWeight:600,color:C.brun}}>{s.title}</div>
                  <div style={{display:"flex",gap:".5rem",alignItems:"center"}}>
                    <CopyBtn text={s.text}/>
                    <span style={{color:C.rose,fontSize:".65rem",transform:isOpen?"rotate(180deg)":"none",transition:"transform .2s"}}>▼</span>
                  </div>
                </div>
                {isOpen&&(
                  <div style={{borderTop:`1px solid ${C.pale}`,padding:".7rem 1rem .85rem",background:C.creme}}>
                    <p style={{fontSize:".78rem",color:C.texte,lineHeight:1.75,margin:0,fontStyle:"italic"}}>{s.text}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

// ── OBJECTIFS ÉQUIPE ──────────────────────────────────────────────────────────
function ObjectifsTab({uid,userName,isMelissa}){
  const[obj,setObj]=useState({ventesObj:"",ventesReal:"",recruesObj:"",recruesReal:"",caObj:"",caReal:"",msg:"",updatedBy:"",updatedAt:0});
  const[loaded,setLoaded]=useState(false);
  const[saving,setSaving]=useState(false);

  useEffect(()=>{
    (async()=>{
      try{
        const ref=doc(db,"equipe","objectifs");
        const snap=await getDoc(ref);
        if(snap.exists())setObj(snap.data());
      }catch{}
      setLoaded(true);
    })();
  },[]);

  const save=async(next)=>{
    setSaving(true);
    try{
      const ref=doc(db,"equipe","objectifs");
      await setDoc(ref,{...next,updatedBy:userName,updatedAt:Date.now()});
      setObj({...next,updatedBy:userName,updatedAt:Date.now()});
    }catch{}
    setSaving(false);
  };

  const pct=(r,o)=>{
    if(!o||!r)return 0;
    return Math.min(100,Math.round(+r/+o*100));
  };

  const KPIs=[
    {key:"ventes",icon:"🛍️",label:"Ventes ce mois",color:C.rose},
    {key:"recrues",icon:"👥",label:"Nouvelles recrues",color:C.lilas},
    {key:"ca",icon:"💰",label:"CA équipe (€)",color:C.or},
  ];

  if(!loaded)return <div style={{textAlign:"center",padding:"2rem",color:C.gris,fontSize:".8rem"}}>Chargement...</div>;

  return(
    <div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
        Objectifs <em style={{fontStyle:"italic",color:C.rose}}>Équipe</em>
      </div>
      <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
        Chiffres partagés avec toute l'équipe. {isMelissa?"Tu peux modifier les objectifs et résultats.":"Mis à jour par Melissa."}
      </p>

      {obj.updatedAt>0&&(
        <div style={{fontSize:".63rem",color:C.gris,marginBottom:"1rem",textAlign:"right"}}>
          Mis à jour par {obj.updatedBy} · {new Date(obj.updatedAt).toLocaleDateString("fr-FR")}
        </div>
      )}

      {/* Message Melissa */}
      {obj.msg&&(
        <div style={{background:C.brun,borderRadius:12,padding:".85rem 1rem",marginBottom:"1rem"}}>
          <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.or,marginBottom:".35rem"}}>👑 Message de Melissa</div>
          <p style={{fontSize:".78rem",color:C.blanc,lineHeight:1.65,margin:0}}>{obj.msg}</p>
        </div>
      )}

      {/* KPIs */}
      {KPIs.map(({key,icon,label,color})=>{
        const p=pct(obj[key+"Real"],obj[key+"Obj"]);
        return(
          <div key={key} style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:".65rem"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:".5rem"}}>
              <div style={{fontSize:".8rem",fontWeight:600,color:C.brun}}>{icon} {label}</div>
              <div style={{fontFamily:"Georgia,serif",fontSize:"1.3rem",fontWeight:600,color:p>=100?C.vert:color}}>{p}%</div>
            </div>
            <div style={{height:8,background:C.pale,borderRadius:10,overflow:"hidden",marginBottom:".5rem"}}>
              <div style={{height:"100%",background:p>=100?C.vert:color,width:p+"%",borderRadius:10,transition:"width .4s"}}/>
            </div>
            <div style={{display:"flex",justifyContent:"space-between",fontSize:".68rem",color:C.gris}}>
              <span>Réalisé : <strong style={{color:C.brun}}>{obj[key+"Real"]||"—"}</strong></span>
              <span>Objectif : <strong style={{color:C.brun}}>{obj[key+"Obj"]||"—"}</strong></span>
            </div>
            {isMelissa&&(
              <div style={{display:"flex",gap:".4rem",marginTop:".6rem"}}>
                <input placeholder="Réalisé" value={obj[key+"Real"]||""} onChange={e=>setObj(p=>({...p,[key+"Real"]:e.target.value}))}
                  style={{flex:1,border:`1px solid ${C.pale}`,borderRadius:7,padding:".35rem .6rem",fontSize:".75rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}}/>
                <input placeholder="Objectif" value={obj[key+"Obj"]||""} onChange={e=>setObj(p=>({...p,[key+"Obj"]:e.target.value}))}
                  style={{flex:1,border:`1px solid ${C.pale}`,borderRadius:7,padding:".35rem .6rem",fontSize:".75rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}}/>
              </div>
            )}
          </div>
        );
      })}

      {isMelissa&&(
        <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:"1rem"}}>
          <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".5rem"}}>📝 Message pour l'équipe</div>
          <textarea value={obj.msg||""} onChange={e=>setObj(p=>({...p,msg:e.target.value}))}
            placeholder="Écris un message de motivation pour ton équipe..."
            style={{width:"100%",minHeight:80,border:`1px solid ${C.pale}`,borderRadius:8,padding:".6rem",fontFamily:"inherit",fontSize:".78rem",color:C.texte,background:C.creme,resize:"vertical",outline:"none",lineHeight:1.6,marginBottom:".6rem"}}/>
          <button onClick={()=>save(obj)} disabled={saving}
            style={{width:"100%",background:C.brun,color:C.blanc,border:"none",borderRadius:8,padding:".55rem",fontSize:".8rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>
            {saving?"Sauvegarde...":"Mettre à jour pour l'équipe →"}
          </button>
        </div>
      )}
    </div>
  );
}

// ── CALENDRIER ────────────────────────────────────────────────────────────────
function CalendrierTab({uid,userName,isMelissa}){
  const[events,setEvents]=useState([]);
  const[loaded,setLoaded]=useState(false);
  const[showAdd,setShowAdd]=useState(false);
  const[form,setForm]=useState({title:"",date:"",time:"",type:"zoom",link:"",notes:""});
  const[saving,setSaving]=useState(false);

  const EVENT_TYPES={
    zoom:{icon:"🎥",label:"Zoom formation",color:C.brun},
    vente:{icon:"🛍️",label:"Événement vente",color:C.rose},
    recrutement:{icon:"👥",label:"Présentation recrutement",color:C.lilas},
    deadline:{icon:"⏰",label:"Deadline / Échéance",color:"#C44B1A"},
    other:{icon:"📌",label:"Autre",color:C.gris},
  };

  useEffect(()=>{
    (async()=>{
      try{
        const ref=doc(db,"equipe","calendrier");
        const snap=await getDoc(ref);
        if(snap.exists()){
          const data=snap.data();
          const arr=Object.values(data).sort((a,b)=>a.dateTs-b.dateTs);
          setEvents(arr);
        }
      }catch{}
      setLoaded(true);
    })();
  },[]);

  const saveEvents=async(arr)=>{
    const obj={};
    arr.forEach(e=>{obj[e.id]=e;});
    try{
      const ref=doc(db,"equipe","calendrier");
      await setDoc(ref,obj);
    }catch{}
  };

  const addEvent=async()=>{
    if(!form.title.trim()||!form.date)return;
    setSaving(true);
    const e={
      id:`ev${Date.now()}`,
      ...form,
      dateTs:new Date(form.date+(form.time?`T${form.time}`:"")).getTime(),
      createdBy:userName,
    };
    const next=[...events,e].sort((a,b)=>a.dateTs-b.dateTs);
    setEvents(next);
    await saveEvents(next);
    setForm({title:"",date:"",time:"",type:"zoom",link:"",notes:""});
    setShowAdd(false);
    setSaving(false);
  };

  const delEvent=async(id)=>{
    const next=events.filter(e=>e.id!==id);
    setEvents(next);
    await saveEvents(next);
  };

  const today=new Date();
  today.setHours(0,0,0,0);
  const upcoming=events.filter(e=>new Date(e.dateTs)>=today);
  const past=events.filter(e=>new Date(e.dateTs)<today);

  const EventCard=({e,canDel})=>{
    const cfg=EVENT_TYPES[e.type]||EVENT_TYPES.other;
    const d=new Date(e.dateTs);
    const isPast=d<today;
    return(
      <div style={{background:isPast?C.pale+"40":C.blanc,border:`1px solid ${isPast?C.pale:cfg.color+"40"}`,borderRadius:12,padding:".8rem 1rem",marginBottom:".5rem",opacity:isPast?.7:1}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:".35rem"}}>
          <div style={{display:"flex",gap:".5rem",alignItems:"center",flex:1}}>
            <span style={{fontSize:"1.1rem",flexShrink:0}}>{cfg.icon}</span>
            <div style={{flex:1}}>
              <div style={{fontSize:".82rem",fontWeight:600,color:C.brun}}>{e.title}</div>
              <div style={{display:"flex",gap:".4rem",alignItems:"center",marginTop:".15rem",flexWrap:"wrap"}}>
                <span style={{background:cfg.color+"20",color:cfg.color,fontSize:".58rem",fontWeight:700,padding:".1rem .4rem",borderRadius:20}}>{cfg.label}</span>
                <span style={{fontSize:".65rem",color:C.gris}}>
                  {d.toLocaleDateString("fr-FR",{weekday:"short",day:"numeric",month:"short"})}
                  {e.time&&` à ${e.time}`}
                </span>
              </div>
            </div>
          </div>
          {canDel&&(
            <button onClick={()=>delEvent(e.id)} style={{background:"none",border:"none",color:C.pale,cursor:"pointer",fontSize:".75rem",padding:".2rem",fontFamily:"inherit",flexShrink:0}}>✕</button>
          )}
        </div>
        {e.notes&&<p style={{fontSize:".73rem",color:C.gris,lineHeight:1.55,margin:".3rem 0 0",fontStyle:"italic"}}>{e.notes}</p>}
        {e.link&&<a href={e.link} target="_blank" rel="noopener noreferrer"
          style={{display:"inline-flex",alignItems:"center",gap:".3rem",background:cfg.color,color:"white",borderRadius:7,padding:".25rem .7rem",fontSize:".68rem",fontWeight:600,textDecoration:"none",marginTop:".45rem"}}>
          🔗 Rejoindre
        </a>}
      </div>
    );
  };

  if(!loaded)return <div style={{textAlign:"center",padding:"2rem",color:C.gris,fontSize:".8rem"}}>Chargement...</div>;

  return(
    <div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
        Calendrier <em style={{fontStyle:"italic",color:C.rose}}>Équipe</em>
      </div>
      <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
        Événements partagés avec toute l'équipe. {isMelissa?"Tu peux ajouter et supprimer des événements.":"Mis à jour par Melissa."}
      </p>

      {isMelissa&&(
        <button onClick={()=>setShowAdd(p=>!p)}
          style={{width:"100%",background:C.brun,color:C.blanc,border:"none",borderRadius:10,padding:".6rem",fontSize:".8rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer",marginBottom:"1rem"}}>
          ➕ Ajouter un événement
        </button>
      )}

      {showAdd&&(
        <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:"1rem"}}>
          <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".6rem"}}>Nouvel événement</div>
          <input placeholder="Titre" value={form.title} onChange={e=>setForm(p=>({...p,title:e.target.value}))}
            style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".45rem"}}/>
          <div style={{display:"flex",gap:".4rem",marginBottom:".45rem"}}>
            <input type="date" value={form.date} onChange={e=>setForm(p=>({...p,date:e.target.value}))}
              style={{flex:1,border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".78rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}}/>
            <input type="time" value={form.time} onChange={e=>setForm(p=>({...p,time:e.target.value}))}
              style={{flex:1,border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".78rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}}/>
          </div>
          <select value={form.type} onChange={e=>setForm(p=>({...p,type:e.target.value}))}
            style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".78rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".45rem"}}>
            {Object.entries(EVENT_TYPES).map(([k,v])=><option key={k} value={k}>{v.icon} {v.label}</option>)}
          </select>
          <input placeholder="Lien Zoom (optionnel)" value={form.link} onChange={e=>setForm(p=>({...p,link:e.target.value}))}
            style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".45rem"}}/>
          <input placeholder="Notes (optionnel)" value={form.notes} onChange={e=>setForm(p=>({...p,notes:e.target.value}))}
            style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".6rem"}}/>
          <div style={{display:"flex",gap:".4rem"}}>
            <button onClick={addEvent} disabled={saving||!form.title.trim()||!form.date}
              style={{flex:1,background:C.brun,color:C.blanc,border:"none",borderRadius:8,padding:".5rem",fontSize:".78rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>
              {saving?"...":"Ajouter"}
            </button>
            <button onClick={()=>setShowAdd(false)}
              style={{flex:1,background:C.pale,color:C.gris,border:"none",borderRadius:8,padding:".5rem",fontSize:".78rem",fontFamily:"inherit",cursor:"pointer"}}>
              Annuler
            </button>
          </div>
        </div>
      )}

      {/* Événements à venir */}
      <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.brun,marginBottom:".5rem"}}>
        📅 À venir ({upcoming.length})
      </div>
      {upcoming.length===0&&(
        <div style={{textAlign:"center",padding:"1.5rem",color:C.gris,fontSize:".76rem",marginBottom:"1rem"}}>
          Aucun événement prévu.{isMelissa?" Ajoute le prochain Zoom !":""}
        </div>
      )}
      {upcoming.map(e=><EventCard key={e.id} e={e} canDel={isMelissa}/>)}

      {/* Événements passés */}
      {past.length>0&&(
        <>
          <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.gris,margin:"1rem 0 .5rem"}}>
            Passés ({past.length})
          </div>
          {past.slice(-3).reverse().map(e=><EventCard key={e.id} e={e} canDel={isMelissa}/>)}
        </>
      )}
    </div>
  );
}

// ── OBJECTIFS POPUP ───────────────────────────────────────────────────────────
// ── PÉRIODE MIHI ─────────────────────────────────────────────────────────────
// Période de 21 jours, commence un mercredi
// Référence : période en cours se termine dans 6j 12h à partir d'aujourd'hui (11/06/2026)
function getPeriodeInfo(){
  const now = new Date();
  // Référence : prochain mercredi de fin = 11/06/2026 + 6j12h = 18/06/2026 à 12h00
  const refEnd = new Date("2026-06-18T12:00:00");
  
  // Calculer le nombre de périodes écoulées depuis refEnd
  const PERIOD_MS = 21 * 24 * 60 * 60 * 1000;
  let periodEnd = new Date(refEnd);
  
  // Avancer ou reculer jusqu'à la prochaine fin de période
  while(periodEnd <= now) periodEnd = new Date(periodEnd.getTime() + PERIOD_MS);
  while(periodEnd - now > PERIOD_MS) periodEnd = new Date(periodEnd.getTime() - PERIOD_MS);
  
  const periodStart = new Date(periodEnd.getTime() - PERIOD_MS);
  const msLeft = periodEnd - now;
  
  const daysLeft = Math.floor(msLeft / (1000*60*60*24));
  const hoursLeft = Math.floor((msLeft % (1000*60*60*24)) / (1000*60*60));
  const pctElapsed = Math.round((1 - msLeft/PERIOD_MS)*100);
  
  // Numéro de période (depuis refEnd)
  const periodNum = Math.floor((now - new Date("2024-01-03")) / PERIOD_MS) + 1;
  
  return { daysLeft, hoursLeft, pctElapsed, periodEnd, periodStart, periodNum };
}

function PeriodeTimer(){
  const[info,setInfo]=useState(getPeriodeInfo());
  useEffect(()=>{
    const t=setInterval(()=>setInfo(getPeriodeInfo()),60000);
    return()=>clearInterval(t);
  },[]);
  
  const urgent = info.daysLeft < 3;
  
  return(
    <div style={{background:urgent?"#FFF3E0":C.creme,border:`1px solid ${urgent?"#E6A817":C.pale}`,borderRadius:10,padding:".65rem .85rem",marginBottom:".75rem"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:".35rem"}}>
        <div style={{fontSize:".65rem",fontWeight:700,color:urgent?"#8B5E00":C.brun}}>
          ⏱️ Période en cours
        </div>
        <div style={{fontSize:".65rem",fontWeight:700,color:urgent?"#C44B1A":C.rose}}>
          {info.daysLeft}j {info.hoursLeft}h restants{urgent?" ⚠️":""}
        </div>
      </div>
      <div style={{height:6,background:C.pale,borderRadius:10,overflow:"hidden",marginBottom:".3rem"}}>
        <div style={{height:"100%",background:urgent?"#E6A817":C.rose,width:info.pctElapsed+"%",borderRadius:10,transition:"width .5s"}}/>
      </div>
      <div style={{display:"flex",justifyContent:"space-between",fontSize:".58rem",color:C.gris}}>
        <span>Début {info.periodStart.toLocaleDateString("fr-FR",{day:"numeric",month:"short"})}</span>
        <span>{info.pctElapsed}% écoulé</span>
        <span>Fin {info.periodEnd.toLocaleDateString("fr-FR",{day:"numeric",month:"short"})}</span>
      </div>
    </div>
  );
}

function ObjectifsPopup({uid}){
  const[obj,setObj]=useState(null);
  const[perso,setPerso]=useState(null);
  const[ptab,setPtab]=useState("perso");

  useEffect(()=>{
    (async()=>{
      try{
        const snap=await getDoc(doc(db,"equipe","objectifs"));
        if(snap.exists())setObj(snap.data());
      }catch{}
      if(uid){
        try{
          const snap2=await getDoc(doc(db,"users",uid));
          if(snap2.exists()&&snap2.data()["db-obj-perso"])
            setPerso(JSON.parse(snap2.data()["db-obj-perso"]));
        }catch{}
      }
    })();
  },[uid]);

  const pct=(r,o)=>{if(!o||!r)return 0;return Math.min(100,Math.round(+r/+o*100));};

  return(
    <div>
      {/* Timer période */}
      <div style={{padding:"1rem 1rem 0"}}><PeriodeTimer/></div>

      {/* Mini tabs */}
      <div style={{display:"flex",borderBottom:`1px solid ${C.pale}`}}>
        {[{id:"perso",label:"🎯 Mes objectifs"},{id:"equipe",label:"👥 Équipe"}].map(t=>(
          <button key={t.id} onClick={()=>setPtab(t.id)}
            style={{flex:1,padding:".5rem",fontSize:".65rem",fontWeight:600,border:"none",borderBottom:`2px solid ${ptab===t.id?C.rose:"transparent"}`,background:"none",color:ptab===t.id?C.brun:C.gris,cursor:"pointer",fontFamily:"inherit"}}>
            {t.label}
          </button>
        ))}
      </div>

      <div style={{padding:"1rem"}}>
        {/* MES OBJECTIFS */}
        {ptab==="perso"&&(
          !perso
          ? <div style={{textAlign:"center",padding:"1rem",fontSize:".74rem",color:C.gris}}>
              Définis tes objectifs dans<br/><strong>Tableau de bord → Mes objectifs</strong>
            </div>
          : <>
            {[
              {label:"💰 Mon CA",val:perso.ca,obj:perso.caObj,unit:"€",color:C.rose},
            ].map(({label,val,obj,unit,color})=>(
              <div key={label} style={{marginBottom:".65rem"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:".25rem"}}>
                  <div style={{fontSize:".74rem",fontWeight:600,color:C.brun}}>{label}</div>
                  <div style={{display:"flex",gap:".3rem",alignItems:"center"}}>
                    <span style={{fontFamily:"Georgia,serif",fontSize:".9rem",fontWeight:600,color:pct(val,obj)>=100?C.vert:color}}>{val||"—"}{unit}</span>
                    <span style={{fontSize:".6rem",color:C.gris}}>/ {obj||"—"}{unit}</span>
                    <span style={{background:color+"20",color:color,fontSize:".58rem",fontWeight:700,padding:".1rem .35rem",borderRadius:20}}>{pct(val,obj)}%</span>
                  </div>
                </div>
                <div style={{height:5,background:C.pale,borderRadius:10,overflow:"hidden"}}>
                  <div style={{height:"100%",background:pct(val,obj)>=100?C.vert:color,width:pct(val,obj)+"%",borderRadius:10,transition:"width .5s"}}/>
                </div>
              </div>
            ))}
            {perso.recruesObj&&perso.recruesObj!=="0"&&(
              <div style={{marginBottom:".65rem"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:".25rem"}}>
                  <div style={{fontSize:".74rem",fontWeight:600,color:C.brun}}>👥 Mes recrues</div>
                  <div style={{display:"flex",gap:".3rem",alignItems:"center"}}>
                    <span style={{fontFamily:"Georgia,serif",fontSize:".9rem",fontWeight:600,color:pct(perso.recruesReal,perso.recruesObj)>=100?C.vert:C.lilas}}>{perso.recruesReal||0}</span>
                    <span style={{fontSize:".6rem",color:C.gris}}>/ {perso.recruesObj}</span>
                    <span style={{background:C.lilas+"20",color:C.lilas,fontSize:".58rem",fontWeight:700,padding:".1rem .35rem",borderRadius:20}}>{pct(perso.recruesReal,perso.recruesObj)}%</span>
                  </div>
                </div>
                <div style={{height:5,background:C.pale,borderRadius:10,overflow:"hidden"}}>
                  <div style={{height:"100%",background:pct(perso.recruesReal,perso.recruesObj)>=100?C.vert:C.lilas,width:pct(perso.recruesReal,perso.recruesObj)+"%",borderRadius:10,transition:"width .5s"}}/>
                </div>
              </div>
            )}
            <div style={{background:C.creme,borderRadius:8,padding:".5rem .75rem",fontSize:".72rem",color:C.brun,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span>🏆 Palier visé</span>
              <strong style={{color:C.or}}>{perso.palier||"2%"}</strong>
            </div>
          </>
        )}

        {/* ÉQUIPE */}
        {ptab==="equipe"&&(
          !obj
          ? <div style={{textAlign:"center",padding:"1rem",fontSize:".75rem",color:C.gris}}>Chargement...</div>
          : <>
            {obj.msg&&<div style={{background:C.creme,borderRadius:8,padding:".5rem .75rem",marginBottom:".65rem",fontSize:".72rem",color:C.brun,lineHeight:1.5,fontStyle:"italic",borderLeft:`3px solid ${C.or}`}}>"{obj.msg}"</div>}
            {[{key:"ventes",icon:"🛍️",label:"Ventes",color:C.rose},{key:"recrues",icon:"👥",label:"Recrues",color:C.lilas},{key:"ca",icon:"💰",label:"CA (€)",color:C.or}].map(({key,icon,label,color})=>{
              const p=pct(obj[key+"Real"],obj[key+"Obj"]);
              return(
                <div key={key} style={{marginBottom:".65rem"}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:".25rem"}}>
                    <div style={{fontSize:".74rem",fontWeight:600,color:C.brun}}>{icon} {label}</div>
                    <div style={{display:"flex",gap:".3rem",alignItems:"center"}}>
                      <span style={{fontFamily:"Georgia,serif",fontSize:".9rem",fontWeight:600,color:p>=100?C.vert:color}}>{obj[key+"Real"]||"—"}</span>
                      <span style={{fontSize:".6rem",color:C.gris}}>/ {obj[key+"Obj"]||"—"}</span>
                      <span style={{background:color+"20",color:color,fontSize:".58rem",fontWeight:700,padding:".1rem .35rem",borderRadius:20}}>{p}%</span>
                    </div>
                  </div>
                  <div style={{height:5,background:C.pale,borderRadius:10,overflow:"hidden"}}>
                    <div style={{height:"100%",background:p>=100?C.vert:color,width:p+"%",borderRadius:10,transition:"width .5s"}}/>
                  </div>
                </div>
              );
            })}
          </>
        )}
      </div>
    </div>
  );
}

// ── OBJECTIFS PERSONNELS ──────────────────────────────────────────────────────
const PALIERS_PERSO=["2%","4%","6%","8%","10%","12%","14%","17%","SR","Business"];

function ObjPersoTab({obj,save}){
  const pctCA=()=>{
    if(!obj.caObj||!obj.ca)return 0;
    return Math.min(100,Math.round(+obj.ca/+obj.caObj*100));
  };
  const pctR=()=>{
    if(!obj.recruesObj||obj.recruesObj==="0"||!obj.recruesReal)return 0;
    return Math.min(100,Math.round(+obj.recruesReal/+obj.recruesObj*100));
  };

  const resetPeriode=()=>{
    save({...obj,ca:"",recruesReal:"0"});
  };

  return(
    <div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
        Mes <em style={{fontStyle:"italic",color:C.rose}}>Objectifs</em>
      </div>
      <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
        Tes objectifs personnels ce mois-ci. Visibles dans le bouton 📊 en bas à droite.
      </p>

      {/* Timer période */}
      <PeriodeTimer/>

      {/* Bouton reset */}
      <div style={{background:"rgba(196,74,26,.08)",border:"1px solid rgba(196,74,26,.2)",borderRadius:10,padding:".65rem 1rem",marginBottom:"1rem",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontSize:".73rem",fontWeight:600,color:C.brun}}>🔄 Nouvelle période</div>
          <div style={{fontSize:".65rem",color:C.gris}}>Remet CA réalisé et recrues à zéro</div>
        </div>
        <button onClick={resetPeriode}
          style={{background:"#C44B1A",color:"white",border:"none",borderRadius:8,padding:".35rem .75rem",fontSize:".72rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>
          Remettre à zéro
        </button>
      </div>

      {/* CA */}
      <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:".75rem"}}>
        <div style={{fontSize:".62rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".6rem"}}>💰 Chiffre d'affaires</div>
        <div style={{display:"flex",gap:".5rem",marginBottom:".6rem"}}>
          <div style={{flex:1}}>
            <div style={{fontSize:".62rem",color:C.gris,marginBottom:".25rem"}}>Mon objectif (€)</div>
            <input type="number" placeholder="Ex: 500" value={obj.caObj||""} onChange={e=>save({...obj,caObj:e.target.value})}
              style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".9rem",fontFamily:"inherit",color:C.brun,background:C.creme,outline:"none",fontWeight:600}}/>
          </div>
          <div style={{flex:1}}>
            <div style={{fontSize:".62rem",color:C.gris,marginBottom:".25rem"}}>Réalisé (€)</div>
            <input type="number" placeholder="Ex: 250" value={obj.ca||""} onChange={e=>save({...obj,ca:e.target.value})}
              style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".9rem",fontFamily:"inherit",color:C.brun,background:C.creme,outline:"none",fontWeight:600}}/>
          </div>
        </div>
        <div style={{display:"flex",justifyContent:"space-between",fontSize:".62rem",color:C.gris,marginBottom:".25rem"}}>
          <span>Progression</span>
          <span style={{fontWeight:700,color:pctCA()>=100?C.vert:C.rose}}>{pctCA()}%</span>
        </div>
        <div style={{height:10,background:C.pale,borderRadius:10,overflow:"hidden"}}>
          <div style={{height:"100%",background:pctCA()>=100?C.vert:C.rose,width:pctCA()+"%",borderRadius:10,transition:"width .4s"}}/>
        </div>
        {pctCA()>=100&&<div style={{textAlign:"center",fontSize:".75rem",color:C.vert,fontWeight:700,marginTop:".4rem"}}>🎉 Objectif CA atteint !</div>}
      </div>

      {/* PALIER */}
      <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:".75rem"}}>
        <div style={{fontSize:".62rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.or,marginBottom:".6rem"}}>🏆 Palier à atteindre</div>
        <div style={{display:"flex",flexWrap:"wrap",gap:".35rem"}}>
          {PALIERS_PERSO.map(p=>{
            const current=obj.palier===p;
            const idx=PALIERS_PERSO.indexOf(p);
            const currentIdx=PALIERS_PERSO.indexOf(obj.palier||"2%");
            const passed=currentIdx>idx;
            return(
              <div key={p} onClick={()=>save({...obj,palier:p})}
                style={{padding:".3rem .75rem",borderRadius:20,fontSize:".72rem",fontWeight:600,cursor:"pointer",border:`2px solid ${current?C.or:passed?C.or+"50":C.pale}`,background:current?C.or:passed?C.or+"15":"transparent",color:current?C.brun:passed?C.brun2:C.gris,transition:"all .2s"}}>
                {passed&&!current?"✓ ":""}{p}
              </div>
            );
          })}
        </div>
        <div style={{marginTop:".75rem"}}>
          <div style={{display:"flex",justifyContent:"space-between",fontSize:".62rem",color:C.gris,marginBottom:".25rem"}}>
            <span>Progression plan de rémunération</span>
            <span style={{fontWeight:700,color:C.or}}>{PALIERS_PERSO.indexOf(obj.palier||"2%")+1}/{PALIERS_PERSO.length}</span>
          </div>
          <div style={{height:8,background:C.pale,borderRadius:10,overflow:"hidden"}}>
            <div style={{height:"100%",background:C.or,width:(((PALIERS_PERSO.indexOf(obj.palier||"2%")+1)/PALIERS_PERSO.length)*100)+"%",borderRadius:10,transition:"width .4s"}}/>
          </div>
        </div>
      </div>

      {/* RECRUES */}
      <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:".75rem"}}>
        <div style={{fontSize:".62rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.lilas,marginBottom:".6rem"}}>👥 Objectif recrues</div>
        <div style={{display:"flex",gap:".5rem",marginBottom:".6rem"}}>
          <div style={{flex:1}}>
            <div style={{fontSize:".62rem",color:C.gris,marginBottom:".25rem"}}>Objectif (recrues)</div>
            <select value={obj.recruesObj||"0"} onChange={e=>save({...obj,recruesObj:e.target.value})}
              style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".9rem",fontFamily:"inherit",color:C.brun,background:C.creme,outline:"none",fontWeight:600}}>
              {Array.from({length:16},(_,i)=>i).map(n=><option key={n} value={n}>{n}</option>)}
            </select>
          </div>
          <div style={{flex:1}}>
            <div style={{fontSize:".62rem",color:C.gris,marginBottom:".25rem"}}>Recrutées</div>
            <select value={obj.recruesReal||"0"} onChange={e=>save({...obj,recruesReal:e.target.value})}
              style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".9rem",fontFamily:"inherit",color:C.brun,background:C.creme,outline:"none",fontWeight:600}}>
              {Array.from({length:16},(_,i)=>i).map(n=><option key={n} value={n}>{n}</option>)}
            </select>
          </div>
        </div>
        {obj.recruesObj&&obj.recruesObj!=="0"&&(
          <>
            <div style={{display:"flex",justifyContent:"space-between",fontSize:".62rem",color:C.gris,marginBottom:".25rem"}}>
              <span>Progression</span>
              <span style={{fontWeight:700,color:pctR()>=100?C.vert:C.lilas}}>{pctR()}%</span>
            </div>
            <div style={{height:10,background:C.pale,borderRadius:10,overflow:"hidden"}}>
              <div style={{height:"100%",background:pctR()>=100?C.vert:C.lilas,width:pctR()+"%",borderRadius:10,transition:"width .4s"}}/>
            </div>
            {pctR()>=100&&<div style={{textAlign:"center",fontSize:".75rem",color:C.vert,fontWeight:700,marginTop:".4rem"}}>🎉 Objectif recrues atteint !</div>}
          </>
        )}
      </div>
    </div>
  );
}

// ── GESTION MEMBRES (Melissa uniquement) ─────────────────────────────────────
function MembresTab({uid}){
  const isMelissa=uid==="melissa"||uid==="melissa-da-silveira";
  const[membres,setMembres]=useState([]);
  const[chefs,setChefs]=useState([]);
  const[newMembre,setNewMembre]=useState({prenom:"",nom:""});
  const[loading,setLoading]=useState(true);
  const[saving,setSaving]=useState(false);

  useEffect(()=>{
    (async()=>{
      try{
        const snap=await getDoc(doc(db,"acces","membres"));
        if(snap.exists()){
          setMembres(snap.data().liste||[]);
          setChefs(snap.data().chefs||[]);
        }
      }catch{}
      setLoading(false);
    })();
  },[]);

  const saveAll=async(liste,chefsList)=>{
    setSaving(true);
    try{await setDoc(doc(db,"acces","membres"),{liste,chefs:chefsList});}catch{}
    setSaving(false);
  };

  const add=async()=>{
    if(!newMembre.prenom.trim()||!newMembre.nom.trim())return;
    const full=`${newMembre.prenom.trim().toLowerCase()} ${newMembre.nom.trim().toLowerCase()}`;
    if(membres.includes(full))return;
    const next=[...membres,full];
    setMembres(next);
    await saveAll(next,chefs);
    setNewMembre({prenom:"",nom:""});
  };

  const remove=async(m)=>{
    const nextM=membres.filter(x=>x!==m);
    const nextC=chefs.filter(x=>x!==m);
    setMembres(nextM);setChefs(nextC);
    await saveAll(nextM,nextC);
  };

  const toggleChef=async(m)=>{
    const isChef=chefs.includes(m);
    const nextC=isChef?chefs.filter(x=>x!==m):[...chefs,m];
    setChefs(nextC);
    await saveAll(membres,nextC);
  };

  const fmt=(m)=>m.split(" ").map(w=>w.charAt(0).toUpperCase()+w.slice(1)).join(" ");

  if(loading)return <div style={{textAlign:"center",padding:"2rem",color:C.gris,fontSize:".8rem"}}>Chargement...</div>;

  return(
    <div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
        Accès <em style={{fontStyle:"italic",color:C.rose}}>Équipe</em>
      </div>
      <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
        Gère les membres et les chefs d'équipe. Code d'accès : <strong style={{color:C.brun}}>BD-2025-FIRE</strong>
      </p>

      {/* Ajouter */}
      <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:"1rem"}}>
        <div style={{fontSize:".62rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".6rem"}}>➕ Ajouter un membre</div>
        <div style={{display:"flex",gap:".4rem",marginBottom:".5rem"}}>
          <input placeholder="Prénom" value={newMembre.prenom} onChange={e=>setNewMembre(p=>({...p,prenom:e.target.value}))}
            style={{flex:1,border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}}/>
          <input placeholder="Nom" value={newMembre.nom} onChange={e=>setNewMembre(p=>({...p,nom:e.target.value}))}
            onKeyDown={e=>e.key==="Enter"&&add()}
            style={{flex:1,border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}}/>
        </div>
        <button onClick={add} disabled={saving||!newMembre.prenom.trim()||!newMembre.nom.trim()}
          style={{width:"100%",background:C.brun,color:C.blanc,border:"none",borderRadius:8,padding:".52rem",fontSize:".78rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>
          {saving?"Sauvegarde...":"Ajouter"}
        </button>
      </div>

      {/* Liste */}
      <div style={{fontSize:".62rem",color:C.gris,marginBottom:".5rem"}}>
        {membres.length} membre{membres.length>1?"s":""} · {chefs.length} chef{chefs.length>1?"s":""} d'équipe
      </div>
      {membres.map(m=>{
        const isChef=chefs.includes(m);
        return(
          <div key={m} style={{background:C.blanc,border:`1px solid ${isChef?C.or:C.pale}`,borderRadius:10,padding:".65rem 1rem",marginBottom:".4rem",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div style={{display:"flex",gap:".6rem",alignItems:"center"}}>
              <div style={{width:28,height:28,borderRadius:"50%",background:isChef?C.or+"30":C.rose+"20",color:isChef?C.brun2:C.rose,fontSize:".8rem",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                {isChef?"👑":fmt(m)[0]}
              </div>
              <div>
                <div style={{fontSize:".82rem",fontWeight:600,color:C.brun}}>{fmt(m)}</div>
                {isChef&&<div style={{fontSize:".6rem",color:C.or,fontWeight:700}}>Chef d'équipe</div>}
              </div>
            </div>
            <div style={{display:"flex",gap:".4rem"}}>
              <button onClick={()=>toggleChef(m)}
                style={{background:isChef?C.or+"20":"none",border:`1px solid ${isChef?C.or:C.pale}`,borderRadius:6,padding:".2rem .55rem",color:isChef?C.brun2:C.gris,cursor:"pointer",fontSize:".65rem",fontFamily:"inherit",fontWeight:isChef?700:400}}>
                {isChef?"👑 Chef":"→ Chef"}
              </button>
              <button onClick={()=>remove(m)}
                style={{background:"none",border:`1px solid ${C.pale}`,borderRadius:6,padding:".2rem .55rem",color:"#B04040",cursor:"pointer",fontSize:".7rem",fontFamily:"inherit"}}>
                ✕
              </button>
            </div>
          </div>
        );
      })}
      {membres.length===0&&(
        <div style={{textAlign:"center",padding:"1.5rem",color:C.gris,fontSize:".76rem"}}>Aucun membre ajouté.</div>
      )}
      <div style={{background:"rgba(196,74,26,.08)",border:"1px solid rgba(196,74,26,.2)",borderRadius:10,padding:".7rem 1rem",marginTop:"1rem",fontSize:".73rem",color:C.brun,lineHeight:1.6}}>
        💡 Clique sur <strong>"→ Chef"</strong> pour promouvoir une fille chef d'équipe. Elle pourra voir les objectifs des filles qui l'ont choisie à leur inscription.
      </div>
    </div>
  );
}

// ── MON ÉQUIPE (chefs d'équipe) ───────────────────────────────────────────────
function MonEquipeTab({uid}){
  const[equipe,setEquipe]=useState([]);
  const[objData,setObjData]=useState({});
  const[loading,setLoading]=useState(true);
  const[isChef,setIsChef]=useState(false);

  useEffect(()=>{
    (async()=>{
      try{
        // Vérifier si chef d'équipe
        const accesSnap=await getDoc(doc(db,"acces","membres"));
        const chefs=accesSnap.exists()?accesSnap.data().chefs||[]:[];
        const chef=chefs.includes(uid.replace(/-/g," "));
        setIsChef(chef);
        if(!chef){setLoading(false);return;}

        // Charger la liste des membres de son équipe
        const userSnap=await getDoc(doc(db,"users",uid));
        const membreIds=userSnap.exists()&&userSnap.data()["mon-equipe"]?JSON.parse(userSnap.data()["mon-equipe"]):[];

        // Charger les objectifs de chaque membre
        const data={};
        await Promise.all(membreIds.map(async(mid)=>{
          try{
            const snap=await getDoc(doc(db,"users",mid));
            if(snap.exists()&&snap.data()["db-obj-perso"])
              data[mid]=JSON.parse(snap.data()["db-obj-perso"]);
            else data[mid]=null;
          }catch{}
        }));
        setEquipe(membreIds);
        setObjData(data);
      }catch{}
      setLoading(false);
    })();
  },[uid]);

  const fmt=(id)=>id.split("-").map(w=>w.charAt(0).toUpperCase()+w.slice(1)).join(" ");
  const pct=(r,o)=>{if(!o||!r)return 0;return Math.min(100,Math.round(+r/+o*100));};

  if(loading)return <div style={{textAlign:"center",padding:"2rem",color:C.gris,fontSize:".8rem"}}>Chargement...</div>;

  if(!isChef)return(
    <div style={{textAlign:"center",padding:"3rem 1rem",color:C.gris}}>
      <div style={{fontSize:"2rem",marginBottom:".75rem"}}>👑</div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"1rem",color:C.brun,marginBottom:".4rem"}}>Accès chef d'équipe</div>
      <div style={{fontSize:".75rem",lineHeight:1.6}}>Cet espace est réservé aux chefs d'équipe.<br/>Melissa peut te promouvoir depuis son espace.</div>
    </div>
  );

  return(
    <div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
        Mon <em style={{fontStyle:"italic",color:C.rose}}>Équipe</em>
      </div>
      <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
        {equipe.length} membre{equipe.length>1?"s":""} dans ton équipe. Leurs objectifs personnels ce mois-ci.
      </p>

      {equipe.length===0&&(
        <div style={{textAlign:"center",padding:"2rem",color:C.gris,fontSize:".76rem"}}>
          Aucune fille ne t'a encore choisie comme chef d'équipe.<br/>Elles verront ton nom à leur prochaine connexion.
        </div>
      )}

      {equipe.map(mid=>{
        const obj=objData[mid];
        return(
          <div key={mid} style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:".9rem 1rem",marginBottom:".65rem"}}>
            <div style={{display:"flex",gap:".6rem",alignItems:"center",marginBottom:".6rem"}}>
              <div style={{width:34,height:34,borderRadius:"50%",background:C.rose+"20",color:C.rose,fontFamily:"Georgia,serif",fontSize:"1rem",fontWeight:600,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                {fmt(mid)[0]}
              </div>
              <div style={{fontFamily:"Georgia,serif",fontSize:".95rem",fontWeight:600,color:C.brun}}>{fmt(mid)}</div>
            </div>

            {!obj?(
              <div style={{fontSize:".73rem",color:C.gris,fontStyle:"italic"}}>Objectifs pas encore définis.</div>
            ):(
              <>
                {[
                  {label:"💰 CA",val:obj.ca,goal:obj.caObj,unit:"€",color:C.rose},
                  {label:"👥 Recrues",val:obj.recruesReal,goal:obj.recruesObj,unit:"",color:C.lilas},
                ].map(({label,val,goal,unit,color})=>(
                  <div key={label} style={{marginBottom:".5rem"}}>
                    <div style={{display:"flex",justifyContent:"space-between",fontSize:".72rem",color:C.texte,marginBottom:".2rem"}}>
                      <span style={{fontWeight:600}}>{label}</span>
                      <span style={{color:pct(val,goal)>=100?C.vert:color,fontWeight:700}}>{val||"—"}{unit} / {goal||"—"}{unit} · {pct(val,goal)}%</span>
                    </div>
                    <div style={{height:5,background:C.pale,borderRadius:10,overflow:"hidden"}}>
                      <div style={{height:"100%",background:pct(val,goal)>=100?C.vert:color,width:pct(val,goal)+"%",borderRadius:10,transition:"width .4s"}}/>
                    </div>
                  </div>
                ))}
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:".35rem",fontSize:".7rem",color:C.gris}}>
                  <span>Palier visé</span>
                  <span style={{fontWeight:700,color:C.or}}>{obj.palier||"2%"}</span>
                </div>
              </>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── ADMIN TAB (Melissa uniquement) ───────────────────────────────────────────
function AdminTab(){
  const[sections,setSections]=useState([]);
  const[loading,setLoading]=useState(true);
  const[showAdd,setShowAdd]=useState(false);
  const[form,setForm]=useState({onglet:"demarrage",titre:"",description:"",url:"",type:"video",actif:true});
  const[saving,setSaving]=useState(false);

  const ONGLETS=[
    {id:"demarrage",label:"📚 Démarrage"},
    {id:"vente",label:"🎯 Vente"},
    {id:"recrutement",label:"👥 Recrutement"},
    {id:"contenu",label:"📱 Contenu"},
    {id:"devperso",label:"🧠 Dév. Personnel"},
    {id:"outils",label:"🛠️ Outils"},
    {id:"formaproduits",label:"🧴 Formation Produits"},
  ];

  const TYPES=[
    {id:"video",label:"▶ Vidéo Zoom"},
    {id:"youtube",label:"▶ YouTube"},
    {id:"drive",label:"📄 Drive"},
    {id:"doc",label:"📝 Google Doc"},
    {id:"info",label:"💡 Info texte"},
  ];

  useEffect(()=>{
    (async()=>{
      try{
        const snap=await getDoc(doc(db,"admin","contenus"));
        if(snap.exists()) setSections(snap.data().items||[]);
      }catch{}
      setLoading(false);
    })();
  },[]);

  const saveItems=async(items)=>{
    setSaving(true);
    try{await setDoc(doc(db,"admin","contenus"),{items});}catch{}
    setSaving(false);
  };

  const add=async()=>{
    if(!form.titre.trim())return;
    const item={id:`adm${Date.now()}`,...form};
    const next=[...sections,item];
    setSections(next);
    await saveItems(next);
    setForm({onglet:"demarrage",titre:"",description:"",url:"",type:"video",actif:true});
    setShowAdd(false);
  };

  const del=async(id)=>{
    const next=sections.filter(s=>s.id!==id);
    setSections(next);
    await saveItems(next);
  };

  const toggle=async(id)=>{
    const next=sections.map(s=>s.id===id?{...s,actif:!s.actif}:s);
    setSections(next);
    await saveItems(next);
  };

  if(loading)return <div style={{textAlign:"center",padding:"2rem",color:C.gris,fontSize:".8rem"}}>Chargement...</div>;

  return(
    <div>
      <div style={{fontFamily:"Georgia,serif",fontSize:"1.35rem",fontWeight:300,color:C.brun,marginBottom:".2rem"}}>
        Espace <em style={{fontStyle:"italic",color:C.rose}}>Admin</em>
      </div>
      <p style={{fontSize:".74rem",color:C.gris,marginBottom:"1rem",lineHeight:1.65}}>
        Ajoute des formations, vidéos et ressources directement sans toucher au code.
      </p>

      <button onClick={()=>setShowAdd(p=>!p)}
        style={{width:"100%",background:C.brun,color:C.blanc,border:"none",borderRadius:10,padding:".65rem",fontSize:".82rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer",marginBottom:"1rem"}}>
        ➕ Ajouter un contenu
      </button>

      {showAdd&&(
        <div style={{background:C.blanc,border:`1px solid ${C.pale}`,borderRadius:12,padding:"1rem",marginBottom:"1rem"}}>
          <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.rose,marginBottom:".6rem"}}>Nouveau contenu</div>

          <div style={{marginBottom:".45rem"}}>
            <div style={{fontSize:".62rem",color:C.gris,marginBottom:".2rem"}}>Onglet de destination</div>
            <select value={form.onglet} onChange={e=>setForm(p=>({...p,onglet:e.target.value}))}
              style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none"}}>
              {ONGLETS.map(o=><option key={o.id} value={o.id}>{o.label}</option>)}
            </select>
          </div>

          <div style={{marginBottom:".45rem"}}>
            <div style={{fontSize:".62rem",color:C.gris,marginBottom:".2rem"}}>Type de contenu</div>
            <div style={{display:"flex",gap:".3rem",flexWrap:"wrap"}}>
              {TYPES.map(t=>(
                <button key={t.id} onClick={()=>setForm(p=>({...p,type:t.id}))}
                  style={{padding:".25rem .6rem",fontSize:".65rem",fontWeight:600,borderRadius:20,border:`1px solid ${form.type===t.id?C.rose:C.pale}`,background:form.type===t.id?C.rose:C.blanc,color:form.type===t.id?"white":C.gris,cursor:"pointer",fontFamily:"inherit"}}>
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <input placeholder="Titre (ex: Tips de vente — Session 3)" value={form.titre} onChange={e=>setForm(p=>({...p,titre:e.target.value}))}
            style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".45rem"}}/>

          <input placeholder="URL (lien Zoom, YouTube, Drive...)" value={form.url} onChange={e=>setForm(p=>({...p,url:e.target.value}))}
            style={{width:"100%",border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontSize:".8rem",fontFamily:"inherit",color:C.texte,background:C.creme,outline:"none",marginBottom:".45rem"}}/>

          <textarea placeholder="Description courte (optionnel)" value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))}
            style={{width:"100%",minHeight:60,border:`1px solid ${C.pale}`,borderRadius:8,padding:".42rem .65rem",fontFamily:"inherit",fontSize:".78rem",color:C.texte,background:C.creme,resize:"vertical",outline:"none",lineHeight:1.5,marginBottom:".6rem"}}/>

          <div style={{display:"flex",gap:".4rem"}}>
            <button onClick={add} disabled={saving||!form.titre.trim()}
              style={{flex:1,background:C.brun,color:C.blanc,border:"none",borderRadius:8,padding:".52rem",fontSize:".78rem",fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>
              {saving?"Sauvegarde...":"Publier"}
            </button>
            <button onClick={()=>setShowAdd(false)}
              style={{flex:1,background:C.pale,color:C.gris,border:"none",borderRadius:8,padding:".52rem",fontSize:".78rem",fontFamily:"inherit",cursor:"pointer"}}>
              Annuler
            </button>
          </div>
        </div>
      )}

      {/* Liste par onglet */}
      {ONGLETS.map(onglet=>{
        const items=sections.filter(s=>s.onglet===onglet.id);
        if(items.length===0)return null;
        return(
          <div key={onglet.id} style={{marginBottom:"1rem"}}>
            <div style={{fontSize:".6rem",fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:C.brun,marginBottom:".4rem",padding:".2rem .6rem",background:C.pale,borderRadius:20,display:"inline-block"}}>{onglet.label}</div>
            {items.map(item=>(
              <div key={item.id} style={{background:item.actif?C.blanc:C.pale+"60",border:`1px solid ${item.actif?C.pale:"#ddd"}`,borderRadius:10,padding:".7rem .9rem",marginBottom:".4rem",opacity:item.actif?1:.6}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                  <div style={{flex:1}}>
                    <div style={{fontSize:".8rem",fontWeight:600,color:C.brun,marginBottom:".15rem"}}>{item.titre}</div>
                    {item.description&&<div style={{fontSize:".7rem",color:C.gris,marginBottom:".15rem"}}>{item.description}</div>}
                    {item.url&&<div style={{fontSize:".65rem",color:C.lilas,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:200}}>{item.url}</div>}
                  </div>
                  <div style={{display:"flex",gap:".3rem",flexShrink:0,marginLeft:".5rem"}}>
                    <button onClick={()=>toggle(item.id)}
                      style={{background:item.actif?C.vert+"20":"none",border:`1px solid ${item.actif?C.vert:C.pale}`,borderRadius:6,padding:".2rem .5rem",color:item.actif?C.vert:C.gris,cursor:"pointer",fontSize:".65rem",fontFamily:"inherit"}}>
                      {item.actif?"✓ Actif":"Masqué"}
                    </button>
                    <button onClick={()=>del(item.id)}
                      style={{background:"none",border:`1px solid ${C.pale}`,borderRadius:6,padding:".2rem .45rem",color:"#B04040",cursor:"pointer",fontSize:".7rem",fontFamily:"inherit"}}>✕</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        );
      })}

      {sections.length===0&&(
        <div style={{textAlign:"center",padding:"2rem",color:C.gris,fontSize:".76rem"}}>
          Aucun contenu ajouté.<br/>Utilise le bouton ci-dessus pour commencer.
        </div>
      )}

      <div style={{background:"rgba(196,154,138,.1)",border:`1px solid ${C.pale}`,borderRadius:10,padding:".75rem 1rem",marginTop:"1rem",fontSize:".73rem",color:C.brun,lineHeight:1.65}}>
        💡 Les contenus que tu ajoutes ici apparaissent dans les onglets correspondants pour toute l'équipe. Tu peux les masquer temporairement sans les supprimer.
      </div>
    </div>
  );
}

// ── ADMIN CONTENT BLOCK (injecté dans les onglets) ───────────────────────────
function AdminContentBlock({onglet,items}){
  const filtered=items.filter(i=>i.onglet===onglet);
  if(filtered.length===0)return null;

  const typeConfig={
    video:{icon:"▶",color:"#8B1A1A",label:"Zoom"},
    youtube:{icon:"▶",color:"#8B1A1A",label:"YouTube"},
    drive:{icon:"📄",color:"#5C3020",label:"Drive"},
    doc:{icon:"📝",color:"#1a4a8b",label:"Doc"},
    info:{icon:"💡",color:"#5C8A60",label:"Info"},
  };

  return(
    <div style={{marginTop:".5rem"}}>
      <div style={{fontSize:".58rem",fontWeight:700,letterSpacing:".12em",textTransform:"uppercase",color:C.rose,marginBottom:".4rem"}}>✦ Ajouté par Melissa</div>
      {filtered.map(item=>{
        const cfg=typeConfig[item.type]||typeConfig.info;
        return(
          <div key={item.id} style={{background:"rgba(196,154,138,.08)",border:`1px solid ${C.pale}`,borderRadius:10,padding:".65rem .85rem",marginBottom:".4rem"}}>
            <div style={{fontSize:".78rem",fontWeight:600,color:C.brun,marginBottom:item.description?".2rem":item.url?".35rem":0}}>{item.titre}</div>
            {item.description&&<div style={{fontSize:".72rem",color:C.gris,lineHeight:1.5,marginBottom:item.url?".4rem":0}}>{item.description}</div>}
            {item.url&&(
              <a href={item.url} target="_blank" rel="noopener noreferrer"
                style={{display:"flex",alignItems:"center",gap:".5rem",background:cfg.color,borderRadius:8,padding:".45rem .8rem",textDecoration:"none",marginTop:".1rem"}}>
                <span style={{fontSize:".8rem",flexShrink:0}}>{cfg.icon}</span>
                <span style={{fontSize:".72rem",fontWeight:600,color:"white"}}>Ouvrir — {cfg.label}</span>
                <span style={{marginLeft:"auto",color:"rgba(255,255,255,.6)",fontSize:".6rem"}}>→</span>
              </a>
            )}
          </div>
        );
      })}
    </div>
  );
}
